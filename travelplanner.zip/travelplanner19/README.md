# Wanderly – Travel Planner

React + Vite + JavaScript · React Router · lucide-react · Context API · localStorage (no backend)

## Run
    npm install
    npm run dev

## Demo logins
- Traveller: user@travel.com / user123
- Admin:     admin@travel.com / admin123
- Or create your own traveller account with "Create an account" on the login page.

## Features
**Traveller:** Dashboard · Explore (search, category, cost, saved-only) · Destination details · My Trips (create / edit / cancel / archive / restore / delete) · Itinerary planner (day-wise add / edit / delete) · Bookings · Budget & expenses (per-trip budget, category breakdown, CSV export) · Packing lists (progress, one-click essentials) · Travel notes (pin, search) · Profile (edit details, change password) · Settings.

**Admin:** Dashboard · User management (add / edit / activate / deactivate / delete) · Destination management (full add / edit / delete / hide) · Destination categories · Activity categories · Trip overview (filter, remove) · Application settings (app name, allow sign-ups).

**Theme:** Light / Dark / System, plus 5 sidebar colours (Ocean, Lagoon, Sunset, Forest, Plum). Dark mode derives its background, cards and borders from the chosen sidebar colour.

**Data:** everything is stored in the browser (`tp_data`). Settings has Export backup / Import backup / Reset.

## Fixes in this version
- Broken colour values in `styles.css` (sidebar hover, role chip, `--text-2`).
- Dates now use the local timezone (previously UTC could show the wrong day).
- Dark-mode toggle icon now follows the real theme, including "System".
- Users can no longer modify other users' records through shared data operations.

## v4 design notes
- Palette "Lagoon & Saffron": sidebar #0F2A33, accent #0E8A86, highlight #E9A23B (all CSS variables at the top of `src/styles.css`).
- Fonts: Fraunces (headings) + Manrope (interface), loaded from Google Fonts with system fallbacks.
- Pictures are built-in SVG illustrations in `src/assets/scenes.js` (sidebar panel, page banners, login hero) so they always load, even offline.

## v6 changes
- Overall search in the top bar for both roles (live results; travellers: destinations, trips, bookings, itinerary, notes; admins: users, trips, destinations, categories, offers).
- Admin gets a bell notification whenever a traveller creates/edits/cancels/archives/deletes a trip, changes itinerary, bookings, expenses or packing items, updates their profile, or signs up. Open tabs stay in sync.
- Each browser tab keeps its own login (so admin and traveller can be open side by side).
- Dashboard: Quick actions replaced by Trip readiness. Explore: A-Z bar removed. My Trips: Export CSV removed.
- Admin Trip Overview: picture cards plus a details table.
- Every page opens fresh on navigation (filters reset, latest data, scrolled to top).
