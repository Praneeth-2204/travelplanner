import { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { seed, EXTRA_DESTINATIONS, EXTRA_BOOKINGS, CATEGORY_IMAGES, ACTIVITY_IMAGES } from '../data/mockData.js';
import { today, uid, syncBookingExpense, syncAllBookings } from '../utils/helpers.js';
import { buildNotifications } from '../utils/notifications.js';

const Ctx = createContext(null);
export const useApp = () => useContext(Ctx);

const load = (key, fallback) => {
  try {
    const v = localStorage.getItem(key);
    return v ? JSON.parse(v) : fallback;
  } catch {
    return fallback;
  }
};
// Each browser tab keeps its own login, so an admin and a traveller can be open side by side.
const loadSession = () => { try { return JSON.parse(sessionStorage.getItem('tp_session')) || null; } catch { return null; } };
const storeSession = (v) => { try { sessionStorage.setItem('tp_session', JSON.stringify(v)); } catch { /* ignore */ } };
const store = (key, value) => { try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* storage unavailable */ } };

// Older saved data may not have newer collections – fill the gaps from the seed.
const hydrate = (stored) => {
  const base = seed();
  if (!stored || typeof stored !== 'object') return base;
  if ((stored.dataVersion || 1) < 2) {
    const add = (list, extra) => [...list, ...extra.filter((x) => !list.some((y) => y.id === x.id))];
    stored = { ...stored, destinations: add(stored.destinations || [], EXTRA_DESTINATIONS), bookings: add(stored.bookings || [], EXTRA_BOOKINGS), dataVersion: 2 };
  }
  if ((stored.dataVersion || 1) < 3) {
    stored = {
      ...stored,
      categories: (stored.categories || []).map((c) => ({ ...c, image: c.image || CATEGORY_IMAGES[c.id] || '' })),
      activityImages: { ...ACTIVITY_IMAGES, ...(stored.activityImages || {}) },
      dataVersion: 3,
    };
  }
  if ((stored.dataVersion || 1) < 4) stored = { ...syncAllBookings(stored), dataVersion: 4 };
  return { ...base, ...stored, adminAlerts: stored.adminAlerts || [], appSettings: { ...base.appSettings, ...(stored.appSettings || {}) } };
};

const PREFIX = { itinerary: 'I', expenses: 'E', packing: 'P', bookings: 'B', notes: 'N' };
const TRIP_COLLECTIONS = ['itinerary', 'expenses', 'packing', 'bookings'];

// Remove trips and everything attached to them.
const dropTrips = (d, ids) => {
  const gone = new Set(ids);
  const next = { ...d, trips: d.trips.filter((t) => !gone.has(t.id)), notes: d.notes.map((n) => (gone.has(n.tripId) ? { ...n, tripId: '' } : n)) };
  TRIP_COLLECTIONS.forEach((c) => { next[c] = d[c].filter((x) => !gone.has(x.tripId)); });
  return next;
};

export function AppProvider({ children }) {
  const [data, setData] = useState(() => hydrate(load('tp_data', null)));
  const [theme, setTheme] = useState(() => (load('tp_theme', 'light') === 'dark' ? 'dark' : 'light'));
  const [accent, setAccent] = useState(() => (['ocean', 'indigo', 'emerald', 'rose', 'amber', 'violet', 'teal', 'graphite'].includes(load('tp_accent', 'ocean')) ? load('tp_accent', 'ocean') : 'ocean'));
  const [readIds, setReadIds] = useState(() => load('tp_read', []));
  const [sessionId, setSessionId] = useState(loadSession);
  const [systemDark, setSystemDark] = useState(() => window.matchMedia('(prefers-color-scheme: dark)').matches);
  const [ui, setUi] = useState(() => ({ density: 'comfortable', font: 'md', banners: true, ...load('tp_ui', {}) }));
  const [toast, setToast] = useState('');

  const resolvedTheme = theme === 'system' ? (systemDark ? 'dark' : 'light') : theme;

  useEffect(() => store('tp_data', data), [data]);
  useEffect(() => {
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const h = () => setSystemDark(mq.matches);
    mq.addEventListener('change', h);
    return () => mq.removeEventListener('change', h);
  }, []);
  useEffect(() => { document.documentElement.dataset.theme = resolvedTheme; store('tp_theme', theme); }, [resolvedTheme, theme]);
  useEffect(() => { document.documentElement.dataset.accent = accent; store('tp_accent', accent); }, [accent]);
  useEffect(() => { const r = document.documentElement.dataset; r.density = ui.density; r.font = ui.font; store('tp_ui', ui); }, [ui]);
  useEffect(() => store('tp_read', readIds), [readIds]);
  useEffect(() => storeSession(sessionId), [sessionId]);
  // Keep every open tab in step: when another tab saves, load its data here (e.g. a traveller's change reaches the admin).
  useEffect(() => {
    const h = (e) => {
      if (e.key !== 'tp_data' || !e.newValue) return;
      let next; try { next = JSON.parse(e.newValue); } catch { return; }
      setData((d) => (JSON.stringify(d) === e.newValue ? d : hydrate(next)));
    };
    window.addEventListener('storage', h);
    return () => window.removeEventListener('storage', h);
  }, []);
  useEffect(() => { if (!toast) return undefined; const t = setTimeout(() => setToast(''), 2600); return () => clearTimeout(t); }, [toast]);
  useEffect(() => { document.title = `${data.appSettings.appName} · Travel Planner`; }, [data.appSettings.appName]);

  const notify = useCallback((m) => setToast(m), []);
  const user = data.users.find((u) => u.id === sessionId && u.status === 'active') || null;
  const isAdmin = user?.role === 'admin';
  const update = (fn) => setData((d) => fn(d));
  // Activity feed entry. When a traveller made the change, the admin also gets a notification.
  const log = (d, text, to = '/admin/trips', tell = true) => {
    const next = { ...d, activity: [{ id: uid('A'), userId: user?.id, text, time: today() }, ...d.activity].slice(0, 200) };
    if (tell && user?.role === 'user') next.adminAlerts = [{ id: uid('AL'), userId: user.id, text: `${user.name}: ${text}`, at: Date.now(), to }, ...(d.adminAlerts || [])].slice(0, 100);
    return next;
  };
  const ownsTrip = (d, tripId) => d.trips.some((t) => t.id === tripId && t.userId === user?.id);

  /* ---------- auth ---------- */
  const login = (email, password) => {
    const u = data.users.find((x) => x.email === email.trim().toLowerCase() && x.password === password);
    if (!u) return { ok: false, error: 'Invalid email or password.' };
    if (u.status !== 'active') return { ok: false, error: 'This account is inactive. Contact an admin.' };
    setSessionId(u.id);
    return { ok: true, user: u };
  };
  const logout = () => setSessionId(null);
  const register = ({ name, email, password }) => {
    const em = email.trim().toLowerCase();
    if (!data.appSettings.allowRegistration) return { ok: false, error: 'Registration is currently closed.' };
    if (data.users.some((u) => u.email === em)) return { ok: false, error: 'An account with this email already exists.' };
    const base = em.split('@')[0].replace(/[^a-z0-9._]/g, '') || 'traveller';
    let username = base; let n = 1;
    while (data.users.some((u) => u.username === username)) username = base + (++n);
    const u = { id: uid('U'), role: 'user', name: name.trim(), username, email: em, password, status: 'active', currency: 'INR', style: 'Balanced', saved: [], recent: [] };
    setData((d) => ({ ...d, users: [...d.users, u], activity: [{ id: uid('A'), userId: u.id, text: 'Joined the app', time: today() }, ...d.activity], adminAlerts: [{ id: uid('AL'), userId: u.id, text: `New traveller joined: ${u.name}`, at: Date.now(), to: '/admin/users' }, ...(d.adminAlerts || [])].slice(0, 100) }));
    setSessionId(u.id);
    return { ok: true };
  };

  /* ---------- derived ---------- */
  const myTrips = user ? data.trips.filter((t) => t.userId === user.id) : [];
  const myNotifications = buildNotifications(data, user).map((n) => ({ ...n, read: readIds.includes(n.id) }));
  const unreadCount = myNotifications.filter((n) => !n.read).length;

  /* ---------- trips ---------- */
  const saveTrip = (trip) => {
    const id = trip.id || uid('T');
    update((d) => {
      const exists = d.trips.some((t) => t.id === id);
      const record = { ...trip, id, userId: user.id, updatedAt: today(), createdAt: trip.createdAt || today(), statusOverride: trip.statusOverride ?? null };
      const trips = exists ? d.trips.map((t) => (t.id === id && t.userId === user.id ? record : t)) : [record, ...d.trips];
      return log({ ...d, trips }, `${exists ? 'Updated' : 'Created'} trip "${trip.title}"`);
    });
    return id;
  };
  const setTripOverride = (id, value) =>
    update((d) => {
      const t = d.trips.find((x) => x.id === id && x.userId === user.id);
      if (!t) return d;
      const label = value === 'archived' ? 'Archived' : value === 'cancelled' ? 'Cancelled' : 'Restored';
      return log({ ...d, trips: d.trips.map((x) => (x.id === id ? { ...x, statusOverride: value, updatedAt: today() } : x)) }, `${label} trip "${t.title}"`);
    });
  const deleteTrip = (id) =>
    update((d) => {
      const t = d.trips.find((x) => x.id === id && x.userId === user.id);
      return t ? log(dropTrips(d, [id]), `Deleted trip "${t.title}"`) : d;
    });

  /* ---------- itinerary / expenses / packing / bookings / notes ---------- */
  const saveItem = (col, item, label) => {
    const id = item.id || uid(PREFIX[col]);
    update((d) => {
      if (col !== 'notes' && !ownsTrip(d, item.tripId)) return d;
      if (col === 'notes' && item.id && d.notes.find((n) => n.id === item.id)?.userId !== user.id) return d;
      const exists = d[col].some((x) => x.id === id);
      const rec = col === 'notes' ? { ...item, id, userId: user.id, updatedAt: today() } : { ...item, id };
      const list = exists ? d[col].map((x) => (x.id === id ? rec : x)) : [rec, ...d[col]];
      let next = { ...d, [col]: list };
      if (col === 'bookings') next = syncBookingExpense(next, rec); // booking amount flows into Budget & expenses
      return log(next, `${exists ? 'Updated' : 'Added'} ${label}`, '/admin/trips', col !== 'notes');
    });
    return id;
  };
  const removeItem = (col, id, label) =>
    update((d) => {
      const it = d[col].find((x) => x.id === id);
      if (!it) return d;
      if (col === 'notes' ? it.userId !== user.id : !ownsTrip(d, it.tripId)) return d;
      const next = { ...d, [col]: d[col].filter((x) => x.id !== id) };
      if (col === 'bookings') next.expenses = d.expenses.filter((e) => e.bookingId !== id);
      return log(next, `Removed ${label}`, '/admin/trips', col !== 'notes');
    });
  const togglePacked = (id) =>
    update((d) => {
      const p = d.packing.find((x) => x.id === id);
      if (!p || !ownsTrip(d, p.tripId)) return d;
      return { ...d, packing: d.packing.map((x) => (x.id === id ? { ...x, packed: !x.packed } : x)) };
    });
  const setAllPacked = (tripId, packed) =>
    update((d) => (ownsTrip(d, tripId) ? { ...d, packing: d.packing.map((x) => (x.tripId === tripId ? { ...x, packed } : x)) } : d));
  const addPackingBatch = (tripId, items) =>
    update((d) => {
      if (!ownsTrip(d, tripId)) return d;
      const have = new Set(d.packing.filter((p) => p.tripId === tripId).map((p) => p.name.toLowerCase()));
      const fresh = items.filter((i) => !have.has(i.name.toLowerCase())).map((i) => ({ ...i, id: uid('P'), tripId, packed: false }));
      return fresh.length ? log({ ...d, packing: [...fresh, ...d.packing] }, `Added ${fresh.length} packing items`) : d;
    });

  /* ---------- profile / settings ---------- */
  const patchUser = (patch) => update((d) => ({ ...d, users: d.users.map((u) => (u.id === user.id ? { ...u, ...patch } : u)) }));
  const toggleSaved = (destId) => patchUser({ saved: user.saved.includes(destId) ? user.saved.filter((x) => x !== destId) : [...user.saved, destId] });
  const markViewed = (destId) => {
    if (user && user.recent[0] !== destId) patchUser({ recent: [destId, ...user.recent.filter((x) => x !== destId)].slice(0, 4) });
  };
  const updateProfile = (p) => {
    const em = p.email.trim().toLowerCase(); const un = p.username.trim();
    if (data.users.some((u) => u.id !== user.id && u.email === em)) return { ok: false, error: 'That email is already used by another account.' };
    if (data.users.some((u) => u.id !== user.id && u.username === un)) return { ok: false, error: 'That username is already taken.' };
    update((d) => log({ ...d, users: d.users.map((u) => (u.id === user.id ? { ...u, name: p.name.trim(), username: un, email: em, style: p.style, currency: p.currency } : u)) }, 'Updated profile', '/admin/users'));
    return { ok: true };
  };
  const changePassword = (oldP, newP) => {
    if (user.password !== oldP) return { ok: false, error: 'Current password is incorrect.' };
    patchUser({ password: newP });
    return { ok: true };
  };
  const markRead = (id) => setReadIds((r) => (r.includes(id) ? r : [...r, id]));
  const markAllRead = () => setReadIds((r) => [...new Set([...r, ...myNotifications.map((n) => n.id)])]);
  const resetDemo = () => { setData(seed()); setReadIds([]); };
  const importData = (obj) => {
    if (!obj || !Array.isArray(obj.users) || !Array.isArray(obj.trips) || !Array.isArray(obj.destinations)) return { ok: false, error: 'This file is not a valid backup.' };
    const next = hydrate(obj);
    setData(next);
    if (!next.users.some((u) => u.id === sessionId && u.status === 'active')) setSessionId(null);
    return { ok: true };
  };

  /* ---------- admin ---------- */
  const deny = { ok: false, error: 'Only admins can do that.' };
  const saveUser = (u) => {
    if (!isAdmin) return deny;
    const em = u.email.trim().toLowerCase();
    if (data.users.some((x) => x.id !== u.id && x.email === em)) return { ok: false, error: 'That email is already in use.' };
    if (data.users.some((x) => x.id !== u.id && x.username === u.username.trim())) return { ok: false, error: 'That username is already taken.' };
    const id = u.id || uid('U');
    update((d) => {
      const old = d.users.find((x) => x.id === id);
      const self = id === user.id;
      const rec = old
        ? { ...old, ...u, email: em, id, role: self ? old.role : u.role, status: self ? old.status : u.status, password: u.password || old.password }
        : { saved: [], recent: [], currency: 'INR', ...u, email: em, id };
      return log({ ...d, users: old ? d.users.map((x) => (x.id === id ? rec : x)) : [...d.users, rec] }, `${old ? 'Updated' : 'Added'} user ${rec.name}`);
    });
    return { ok: true };
  };
  const deleteUser = (id) => {
    if (!isAdmin) return deny;
    if (id === user.id) return { ok: false, error: 'You cannot delete your own account.' };
    update((d) => {
      const u = d.users.find((x) => x.id === id);
      if (!u) return d;
      const mine = d.trips.filter((t) => t.userId === id).map((t) => t.id);
      const next = dropTrips(d, mine);
      return log({ ...next, users: d.users.filter((x) => x.id !== id), notes: next.notes.filter((n) => n.userId !== id) }, `Deleted user ${u.name}`);
    });
    return { ok: true };
  };
  const saveDestination = (dst) => {
    if (!isAdmin) return deny;
    const id = dst.id || uid('D');
    update((d) => {
      const old = d.destinations.find((x) => x.id === id);
      const rec = { popularity: 0, ...old, ...dst, id };
      return log({ ...d, destinations: old ? d.destinations.map((x) => (x.id === id ? rec : x)) : [rec, ...d.destinations] }, `${old ? 'Updated' : 'Added'} destination ${rec.name}`);
    });
    return { ok: true };
  };
  const deleteDestination = (id) => {
    if (!isAdmin) return deny;
    const used = data.trips.filter((t) => t.destinationIds.includes(id)).length;
    if (used) return { ok: false, error: `Used by ${used} trip${used > 1 ? 's' : ''}. Deactivate it instead of deleting.` };
    update((d) => log({ ...d, destinations: d.destinations.filter((x) => x.id !== id), users: d.users.map((u) => ({ ...u, saved: u.saved.filter((x) => x !== id), recent: u.recent.filter((x) => x !== id) })) }, 'Deleted a destination'));
    return { ok: true };
  };
  const saveCategory = (c) => {
    if (!isAdmin) return deny;
    if (data.categories.some((x) => x.id !== c.id && x.name.toLowerCase() === c.name.trim().toLowerCase())) return { ok: false, error: 'A category with this name already exists.' };
    const id = c.id || uid('C');
    update((d) => {
      const exists = d.categories.some((x) => x.id === id);
      const rec = { id, name: c.name.trim(), color: c.color, image: c.image || '' };
      return log({ ...d, categories: exists ? d.categories.map((x) => (x.id === id ? rec : x)) : [...d.categories, rec] }, `${exists ? 'Updated' : 'Added'} category ${rec.name}`);
    });
    return { ok: true };
  };
  const deleteCategory = (id) => {
    if (!isAdmin) return deny;
    const used = data.destinations.filter((x) => x.categoryId === id).length;
    if (used) return { ok: false, error: `${used} destination${used > 1 ? 's use' : ' uses'} this category. Move them first.` };
    update((d) => log({ ...d, categories: d.categories.filter((x) => x.id !== id) }, 'Deleted a category'));
    return { ok: true };
  };
  const saveActivityCategory = (oldName, name, image = '') => {
    if (!isAdmin) return deny;
    const n = name.trim();
    if (data.activityCategories.some((x) => x.toLowerCase() === n.toLowerCase() && x !== oldName)) return { ok: false, error: 'That activity category already exists.' };
    update((d) => log({
      ...d,
      activityCategories: oldName ? d.activityCategories.map((x) => (x === oldName ? n : x)) : [...d.activityCategories, n],
      itinerary: oldName ? d.itinerary.map((i) => (i.category === oldName ? { ...i, category: n } : i)) : d.itinerary,
      activityImages: (() => { const m = { ...(d.activityImages || {}) }; if (oldName) delete m[oldName]; m[n] = image; return m; })(),
    }, `${oldName ? 'Renamed' : 'Added'} activity category ${n}`));
    return { ok: true };
  };
  const deleteActivityCategory = (name) => {
    if (!isAdmin) return deny;
    const used = data.itinerary.filter((i) => i.category === name).length;
    if (used) return { ok: false, error: `${used} planned activit${used > 1 ? 'ies use' : 'y uses'} this category.` };
    update((d) => { const m = { ...(d.activityImages || {}) }; delete m[name]; return { ...d, activityCategories: d.activityCategories.filter((x) => x !== name), activityImages: m }; });
    return { ok: true };
  };
  const adminDeleteTrip = (id) => {
    if (!isAdmin) return deny;
    update((d) => { const t = d.trips.find((x) => x.id === id); return t ? log(dropTrips(d, [id]), `Removed trip "${t.title}"`) : d; });
    return { ok: true };
  };
  const saveOffer = (o) => {
    if (!isAdmin) return deny;
    const code = o.code.trim().toUpperCase();
    if (data.offers.some((x) => x.id !== o.id && x.code === code)) return { ok: false, error: 'That coupon code already exists.' };
    const id = o.id || uid('O');
    update((d) => { const exists = d.offers.some((x) => x.id === id); const rec = { ...o, id, code }; return log({ ...d, offers: exists ? d.offers.map((x) => (x.id === id ? rec : x)) : [rec, ...d.offers] }, `${exists ? 'Updated' : 'Added'} offer ${code}`); });
    return { ok: true };
  };
  const deleteOffer = (id) => { if (!isAdmin) return deny; update((d) => ({ ...d, offers: d.offers.filter((x) => x.id !== id) })); return { ok: true }; };
  const setAppSettings = (patch) => { if (isAdmin) update((d) => ({ ...d, appSettings: { ...d.appSettings, ...patch } })); };

  return (
    <Ctx.Provider value={{
      data, user, isAdmin, login, logout, register, myTrips, myNotifications, unreadCount, toast, notify,
      saveTrip, setTripOverride, deleteTrip, saveItem, removeItem, togglePacked, setAllPacked, addPackingBatch,
      toggleSaved, markViewed, markRead, markAllRead, patchUser, updateProfile, changePassword,
      theme, setTheme, resolvedTheme, accent, setAccent, resetDemo, importData,
      saveUser, deleteUser, saveDestination, deleteDestination, saveCategory, deleteCategory,
      saveActivityCategory, deleteActivityCategory, adminDeleteTrip, setAppSettings, ui, setUi, saveOffer, deleteOffer,
    }}>
      {children}
    </Ctx.Provider>
  );
}
