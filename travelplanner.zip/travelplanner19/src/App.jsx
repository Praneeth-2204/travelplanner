import { Navigate, Route, Routes } from 'react-router-dom';
import { useApp } from './context/AppContext.jsx';
import Layout from './components/Layout.jsx';
import Login from './pages/Login.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Explore from './pages/Explore.jsx';
import DestinationDetails from './pages/DestinationDetails.jsx';
import MyTrips from './pages/MyTrips.jsx';
import TripDetails from './pages/TripDetails.jsx';
import Itinerary from './pages/Itinerary.jsx';
import Budget from './pages/Budget.jsx';
import Packing from './pages/Packing.jsx';
import Bookings from './pages/Bookings.jsx';
import Notes from './pages/Notes.jsx';
import Profile from './pages/Profile.jsx';
import Settings from './pages/Settings.jsx';
import Bills from './pages/Bills.jsx';
import Offers from './pages/Offers.jsx';
import { AdminOffers, AdminReports } from './pages/AdminExtra.jsx';
import { AdminActivities, AdminCategories, AdminDestinations, AdminTrips, AdminUsers } from './pages/AdminPages.jsx';

function Protected({ roles, children }) {
  const { user } = useApp();
  if (!user) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to="/dashboard" replace />;
  return children;
}
const U = ['user'];
const A = ['admin'];
const guard = (roles, el) => <Protected roles={roles}>{el}</Protected>;

export default function App() {
  const { user } = useApp();
  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/dashboard" replace /> : <Login />} />
      <Route element={<Protected><Layout /></Protected>}>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/explore" element={guard(U, <Explore />)} />
        <Route path="/explore/:id" element={guard(U, <DestinationDetails />)} />
        <Route path="/trips" element={guard(U, <MyTrips />)} />
        <Route path="/trips/:id" element={guard(U, <TripDetails />)} />
        <Route path="/itinerary" element={guard(U, <Itinerary />)} />
        <Route path="/bookings" element={guard(U, <Bookings />)} />
        <Route path="/budget" element={guard(U, <Budget />)} />
        <Route path="/packing" element={guard(U, <Packing />)} />
        <Route path="/bills" element={guard(U, <Bills />)} />
        <Route path="/offers" element={guard(U, <Offers />)} />
        <Route path="/admin/offers" element={guard(A, <AdminOffers />)} />
        <Route path="/admin/reports" element={guard(A, <AdminReports />)} />
        <Route path="/notes" element={guard(U, <Notes />)} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/settings" element={guard(U, <Settings />)} />
        <Route path="/admin/users" element={guard(A, <AdminUsers />)} />
        <Route path="/admin/destinations" element={guard(A, <AdminDestinations />)} />
        <Route path="/admin/categories" element={guard(A, <AdminCategories />)} />
        <Route path="/admin/activities" element={guard(A, <AdminActivities />)} />
        <Route path="/admin/trips" element={guard(A, <AdminTrips />)} />
        <Route path="/admin/settings" element={guard(A, <Settings />)} />
      </Route>
      <Route path="*" element={<Navigate to={user ? '/dashboard' : '/login'} replace />} />
    </Routes>
  );
}
