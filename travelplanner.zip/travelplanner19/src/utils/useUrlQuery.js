import { useEffect, useState } from 'react';
import { useLocation, useSearchParams } from 'react-router-dom';

// A search box state that starts from ?q= in the URL and follows it whenever the
// URL changes (e.g. when the top-bar global search sends you to this page).
export function useUrlQuery(key = 'q') {
  const [params] = useSearchParams();
  const loc = useLocation();
  const fromUrl = params.get(key) || '';
  const [value, setValue] = useState(fromUrl);
  useEffect(() => { setValue(fromUrl); }, [fromUrl, loc.key]);
  return [value, setValue];
}
