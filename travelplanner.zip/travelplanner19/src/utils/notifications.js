import { daysBetween, fmtAgo, fmtMoney, today, tripStatus } from './helpers.js';

// Notifications are derived from the live project data (trips, expenses, packing, itinerary, users).
export function buildNotifications(data, user) {
  if (!user) return [];
  const out = [];
  const t0 = today();
  if (user.role === 'admin') {
    // Changes made by travellers (newest first)
    (data.adminAlerts || []).slice(0, 40).forEach((a) =>
      out.push({ id: `alert-${a.id}`, level: 'info', text: a.text, sub: fmtAgo(a.at), to: a.to || '/admin/trips' }));
    data.users.filter((u) => u.role === 'user' && u.status !== 'active').forEach((u) =>
      out.push({ id: `inactive-${u.id}`, level: 'warn', text: `${u.name} is inactive.`, sub: u.email, to: '/admin/users' }));
    const ongoing = data.trips.filter((t) => tripStatus(t) === 'ongoing').length;
    if (ongoing) out.push({ id: `ongoing-${ongoing}`, level: 'info', text: `${ongoing} trip${ongoing > 1 ? 's are' : ' is'} currently ongoing.`, sub: 'Across all travellers', to: '/admin/trips' });
    return out;
  }
  const trips = data.trips.filter((t) => t.userId === user.id);
  trips.forEach((t) => {
    const st = tripStatus(t);
    if (st === 'cancelled' || st === 'archived') return;
    const exp = data.expenses.filter((e) => e.tripId === t.id);
    const spent = exp.reduce((s, e) => s + e.actual, 0);
    const est = exp.reduce((s, e) => s + e.estimated, 0);
    if (st === 'ongoing') out.push({ id: `live-${t.id}`, level: 'info', text: `"${t.title}" is underway.`, sub: `Returns in ${Math.max(0, daysBetween(t0, t.returnDate))} day(s)`, to: '/trips' });
    if (st === 'upcoming') out.push({ id: `soon-${t.id}-${t.departureDate}`, level: 'info', text: `"${t.title}" starts in ${daysBetween(t0, t.departureDate)} days.`, sub: t.departureDate, to: '/trips' });
    if (spent > t.budget || est > t.budget)
      out.push({ id: `over-${t.id}-${spent}-${est}`, level: 'bad', text: `"${t.title}" is over budget.`, sub: `${fmtMoney(Math.max(spent, est), t.currency)} vs ${fmtMoney(t.budget, t.currency)} planned`, to: '/budget' });
    const items = data.packing.filter((p) => p.tripId === t.id);
    const left = items.filter((p) => !p.packed).length;
    if ((st === 'upcoming' || st === 'ongoing') && left) out.push({ id: `pack-${t.id}-${left}`, level: 'warn', text: `${left} item${left > 1 ? 's' : ''} still to pack for "${t.title}".`, sub: `${items.length - left} of ${items.length} packed`, to: '/packing' });
    (data.bookings || []).filter((b) => b.tripId === t.id && b.status === 'pending').forEach((b) =>
      out.push({ id: `book-${b.id}`, level: 'warn', text: `Booking pending: ${b.title}.`, sub: `For "${t.title}"`, to: '/bookings' }));
  });
  const ids = new Set(trips.map((t) => t.id));
  data.itinerary.filter((i) => ids.has(i.tripId) && i.date === t0).forEach((i) =>
    out.push({ id: `today-${i.id}`, level: 'info', text: `Today: ${i.title} at ${i.start}.`, sub: i.location, to: '/itinerary' }));
  return out;
}
