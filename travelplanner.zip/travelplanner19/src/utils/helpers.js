const pad = (n) => String(n).padStart(2, '0');
const toLocalIso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

// Local-date based (not UTC) so dates never shift by a day in timezones like IST.
export const iso = (offsetDays = 0) => {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return toLocalIso(d);
};
export const today = () => iso(0);

export const uid = (prefix = 'X') => prefix + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

export const fmtMoney = (amount, currency = 'INR') =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency, maximumFractionDigits: 0 }).format(amount || 0);

export const fmtDate = (d, opts = { day: 'numeric', month: 'short', year: 'numeric' }) =>
  d ? new Date(d + 'T00:00:00').toLocaleDateString('en-GB', opts) : '—';

export const daysBetween = (a, b) =>
  Math.round((new Date(b + 'T00:00:00') - new Date(a + 'T00:00:00')) / 86400000);

// Status is calculated from dates; cancelled/archived are kept as manual overrides.
export const tripStatus = (t) => {
  if (t.statusOverride) return t.statusOverride;
  const now = today();
  if (t.returnDate < now) return 'completed';
  if (t.departureDate <= now) return 'ongoing';
  return daysBetween(now, t.departureDate) <= 30 ? 'upcoming' : 'planning';
};

export const greeting = () => {
  const h = new Date().getHours();
  return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
};

export const initials = (n = '') => n.split(' ').filter(Boolean).map((x) => x[0]).join('').slice(0, 2).toUpperCase();
export const cap = (s = '') => s.charAt(0).toUpperCase() + s.slice(1);
export const isEmail = (s) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);

const save = (name, blob) => {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
};
export const downloadCsv = (name, rows) =>
  save(name, new Blob([rows.map((r) => r.map((v) => `"${String(v ?? '').replace(/"/g, '""')}"`).join(',')).join('\n')], { type: 'text/csv' }));
export const downloadJson = (name, obj) => save(name, new Blob([JSON.stringify(obj, null, 2)], { type: 'application/json' }));

/* ---------- trip bill & offers ---------- */
export const offerState = (o, subtotal = 0) => {
  if (!o.active) return { ok: false, why: 'Inactive' };
  if (o.expires && o.expires < today()) return { ok: false, why: 'Expired' };
  if (subtotal < (o.min || 0)) return { ok: false, why: `Needs a bill of ${o.min}+` };
  return { ok: true };
};
export const offerDiscount = (o, subtotal) => {
  if (!o || !offerState(o, subtotal).ok) return 0;
  const raw = o.type === 'percent' ? (subtotal * o.value) / 100 : o.value;
  return Math.round(Math.min(raw, o.max || raw, subtotal));
};
export function buildBill(trip, data, offer) {
  const bk = data.bookings.filter((b) => b.tripId === trip.id && b.status !== 'cancelled');
  const lines = bk.map((b) => ({ id: b.id, kind: b.type, label: b.title, sub: b.provider || '', amount: b.cost }));
  data.expenses.filter((e) => e.tripId === trip.id && e.actual > 0 && !e.bookingId && !bk.some((b) => b.cost === e.actual)).forEach((e) => lines.push({ id: e.id, kind: e.category, label: e.description, sub: 'Expense', amount: e.actual }));
  const subtotal = lines.reduce((s, l) => s + l.amount, 0);
  const fee = Math.round((subtotal * (data.appSettings.serviceFee || 0)) / 100);
  const discount = offerDiscount(offer, subtotal);
  const taxable = subtotal + fee - discount;
  const tax = Math.round((taxable * (data.appSettings.taxRate || 0)) / 100);
  return { lines, subtotal, fee, discount, tax, total: taxable + tax, no: `INV-${trip.id}-${trip.createdAt?.slice(0, 4) || new Date().getFullYear()}` };
}

/* ---------- bookings <-> budget ---------- */
// Which budget category each kind of booking is counted under.
export const BOOKING_CAT = { flight: 'transport', accommodation: 'accommodation', transport: 'transport', activity: 'activities', restaurant: 'food' };
export const BOOKING_LABEL = { flight: 'Flight', accommodation: 'Hotel / Stay', transport: 'Transport', activity: 'Activity', restaurant: 'Restaurant' };

// Adds, updates or removes the budget expense that belongs to one booking.
// Cancelled bookings cost nothing, so their expense is removed.
export const syncBookingExpense = (d, b) => {
  const have = d.expenses.find((e) => e.bookingId === b.id);
  if (b.status === 'cancelled') return have ? { ...d, expenses: d.expenses.filter((e) => e.id !== have.id) } : d;
  const cost = Number(b.cost) || 0;
  const rec = { ...(have || {}), id: have?.id || uid('E'), tripId: b.tripId, bookingId: b.id, category: BOOKING_CAT[b.type] || 'other', description: b.title, date: b.date, estimated: cost, actual: cost };
  return { ...d, expenses: have ? d.expenses.map((e) => (e.id === have.id ? rec : e)) : [rec, ...d.expenses] };
};
// Used once for older saved data: links bookings to matching expenses, creates the missing ones.
export const syncAllBookings = (d) => {
  let next = { ...d, expenses: [...(d.expenses || [])] };
  (d.bookings || []).forEach((b) => {
    if (next.expenses.some((e) => e.bookingId === b.id)) return;
    if (b.status === 'cancelled') return;
    const twin = next.expenses.find((e) => !e.bookingId && e.tripId === b.tripId && Number(e.actual) === Number(b.cost) && Number(b.cost) > 0);
    if (twin) next = { ...next, expenses: next.expenses.map((e) => (e === twin ? { ...e, bookingId: b.id } : e)) };
    else next = syncBookingExpense(next, b);
  });
  return next;
};

export const nightsBetween = (a, b) => Math.max(0, daysBetween(a, b));
export const addDays = (d, n) => { const x = new Date(d + 'T00:00:00'); x.setDate(x.getDate() + n); return toLocalIso(x); };

export const fmtAgo = (ts) => {
  const m = Math.max(0, Math.round((Date.now() - ts) / 60000));
  if (m < 1) return 'Just now';
  if (m < 60) return `${m} min ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h} hr ago`;
  const d = Math.round(h / 24);
  return `${d} day${d > 1 ? 's' : ''} ago`;
};
