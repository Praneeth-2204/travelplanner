// Built-in travel illustrations (SVG). They ship with the app, so pictures always show,
// even offline or when an online photo fails to load.
// Style: layered, softly graded landscapes in the Lagoon & Saffron palette.
const svg = (W, H, body, defs = '') =>
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" preserveAspectRatio="xMidYMid slice"><defs>${defs}</defs>${body}</svg>`;
const grad = (id, stops, vertical = true) =>
  `<linearGradient id="${id}" x1="0" y1="0" x2="${vertical ? 0 : 1}" y2="${vertical ? 1 : 0}">${stops.map(([o, c]) => `<stop offset="${o}" stop-color="${c}"/>`).join('')}</linearGradient>`;
const glow = (id, c) => `<radialGradient id="${id}"><stop offset="0" stop-color="${c}" stop-opacity=".9"/><stop offset="1" stop-color="${c}" stop-opacity="0"/></radialGradient>`;

// Smooth rolling ridge built from a few sine waves (deterministic, no randomness)
const ridge = (W, H, base, amp, color, seed = 1, opacity = 1) => {
  const pts = [];
  for (let x = 0; x <= W; x += 20) {
    const y = base - amp * (0.55 * Math.sin(x / (170 + seed * 23) + seed) + 0.3 * Math.sin(x / (63 + seed * 9) + seed * 2) + 0.15 * Math.sin(x / 31 + seed * 3));
    pts.push(`${x},${y.toFixed(1)}`);
  }
  return `<polygon points="0,${H} ${pts.join(' ')} ${W},${H}" fill="${color}" opacity="${opacity}"/>`;
};
// Sharp peaks for mountains
const peaks = (W, H, base, color, list) =>
  `<path d="M0 ${H} L0 ${base} ${list.map(([x, y]) => `L${x} ${y}`).join(' ')} L${W} ${base} L${W} ${H}Z" fill="${color}"/>`;
const sun = (cx, cy, r, c, g) => `<circle cx="${cx}" cy="${cy}" r="${r * 3.2}" fill="url(#${g})"/><circle cx="${cx}" cy="${cy}" r="${r}" fill="${c}"/>`;
const trail = (x, y, c = '#fff') =>
  `<g transform="translate(${x} ${y}) rotate(-14)"><path d="M-120 3 L0 0" stroke="${c}" stroke-width="1.6" opacity=".35" stroke-linecap="round"/><path d="M-60 3 L0 0" stroke="${c}" stroke-width="2.4" opacity=".5" stroke-linecap="round"/><path d="M0 0 L26 -2.5 L34 -10 L39 -10 L34 -1.5 L42 -1 L45 -5 L48 -5 L46 1 L48 7 L45 7 L42 3 L34 4 L39 12 L34 12 L26 5 L0 3Z" fill="${c}"/></g>`;
const birds = (pts, c = '#0f2a33') => pts.map(([x, y, s = 1]) => `<path d="M${x} ${y} q${6 * s} ${-7 * s} ${12 * s} 0 q${6 * s} ${-7 * s} ${12 * s} 0" stroke="${c}" stroke-width="1.6" fill="none" stroke-linecap="round" opacity=".55"/>`).join('');
const pines = (W, base, count, h, colors, seed = 0) =>
  Array.from({ length: count }, (_, i) => {
    const x = (i * W) / count + ((i * 37 + seed * 11) % 20);
    const hh = h * (0.7 + (((i * 53 + seed * 17) % 40) / 100));
    const w = hh * 0.34;
    return `<path d="M${x} ${base} l${w} ${-hh} ${w} ${hh}z M${x + w * 0.2} ${base - hh * 0.3} l${w * 0.8} ${-hh * 0.6} ${w * 0.8} ${hh * 0.6}z" fill="${colors[i % colors.length]}"/>`;
  }).join('');
const stars = (W, H, n) => Array.from({ length: n }, (_, i) => `<circle cx="${(i * 197 + 40) % W}" cy="${(i * 83 + 20) % (H * 0.5)}" r="${(i % 3) * 0.4 + 0.6}" fill="#fff" opacity="${0.35 + (i % 4) * 0.12}"/>`).join('');
const skyline = (W, H, base, color, lit, seed = 0) => {
  let x = -10, out = '', wins = '';
  let i = 0;
  while (x < W) {
    const w = 38 + ((i * 29 + seed * 7) % 46);
    const h = 70 + ((i * 47 + seed * 13) % 150);
    out += `<rect x="${x}" y="${base - h}" width="${w}" height="${h + (H - base)}" fill="${color}"/>`;
    for (let wy = base - h + 12; wy < base - 8; wy += 16) for (let wx = x + 7; wx < x + w - 8; wx += 12) if ((wx * 7 + wy * 3 + i) % 5 < 2) wins += `<rect x="${wx}" y="${wy}" width="4" height="6" fill="${lit}" opacity=".8"/>`;
    x += w + 4; i++;
  }
  return out + wins;
};

// Each scene is a function of (W, H) so the same artwork serves wide banners and the tall sidebar panel.
const SCENES = {
  beach: (W, H) => svg(W, H,
    `<rect width="${W}" height="${H}" fill="url(#s)"/>${sun(W * 0.76, H * 0.36, H * 0.1, '#fbd28a', 'g')}${birds([[W * 0.2, H * 0.2], [W * 0.27, H * 0.15, 0.8], [W * 0.5, H * 0.24, 0.7]])}${trail(W * 0.44, H * 0.2)}` +
    `${ridge(W, H, H * 0.58, H * 0.05, '#7cc5c0', 3, .8)}<rect y="${H * 0.6}" width="${W}" height="${H * 0.4}" fill="url(#sea)"/>` +
    `${[0.66, 0.72, 0.79].map((p, i) => `<path d="M0 ${H * p} Q ${W * 0.12} ${H * p - 6} ${W * 0.25} ${H * p} T ${W * 0.5} ${H * p} T ${W * 0.75} ${H * p} T ${W} ${H * p}" stroke="#fff" stroke-width="1.4" fill="none" opacity="${0.35 - i * 0.08}"/>`).join('')}` +
    `<path d="M0 ${H * 0.9} Q ${W * 0.3} ${H * 0.8} ${W * 0.62} ${H * 0.88} T ${W} ${H * 0.84} V${H} H0Z" fill="#f1d9b0"/><path d="M0 ${H * 0.96} Q ${W * 0.3} ${H * 0.9} ${W * 0.62} ${H * 0.95} T ${W} ${H * 0.93} V${H} H0Z" fill="#e6c595"/>`,
    grad('s', [[0, '#9ed8dc'], [0.55, '#f5e6c8'], [1, '#fbd9a0']]) + grad('sea', [[0, '#2aa6a6'], [1, '#0d5f6b']]) + glow('g', '#fbd28a')),
  mountain: (W, H) => svg(W, H,
    `<rect width="${W}" height="${H}" fill="url(#s)"/>${sun(W * 0.2, H * 0.3, H * 0.07, '#fff3d6', 'g')}${trail(W * 0.62, H * 0.18)}${birds([[W * 0.45, H * 0.28, 0.8], [W * 0.5, H * 0.24]])}` +
    peaks(W, H, H * 0.7, '#a9c4d0', [[W * 0.1, H * 0.42], [W * 0.2, H * 0.58], [W * 0.32, H * 0.32], [W * 0.46, H * 0.62], [W * 0.6, H * 0.4], [W * 0.78, H * 0.6], [W * 0.9, H * 0.45]]) +
    peaks(W, H, H * 0.76, '#6f97a8', [[W * 0.06, H * 0.58], [W * 0.18, H * 0.7], [W * 0.38, H * 0.4], [W * 0.52, H * 0.7], [W * 0.7, H * 0.48], [W * 0.86, H * 0.72], [W * 0.96, H * 0.6]]) +
    `<path d="M${W * 0.38} ${H * 0.4} l-26 34 14 -6 12 14 12 -16 16 8z" fill="#fff" opacity=".9"/><path d="M${W * 0.7} ${H * 0.48} l-22 28 12 -5 10 12 10 -13 12 6z" fill="#fff" opacity=".85"/>` +
    `${ridge(W, H, H * 0.84, H * 0.05, '#2f6a6a', 2)}${pines(W, H * 0.9, Math.round(W / 42), H * 0.16, ['#14463f', '#1b5a50'])}<rect y="${H * 0.9}" width="${W}" height="${H * 0.1}" fill="#0f3a3a"/>`,
    grad('s', [[0, '#c8dfe9'], [0.6, '#f6ead6'], [1, '#f9d7a8']]) + glow('g', '#fff3d6')),
  city: (W, H) => svg(W, H,
    `<rect width="${W}" height="${H}" fill="url(#s)"/>${stars(W, H, 28)}${sun(W * 0.22, H * 0.52, H * 0.07, '#ffe3b0', 'g')}${trail(W * 0.64, H * 0.22)}` +
    `${skyline(W, H, H * 0.8, '#2b4a5c', '#f6c57a', 2).replace(/fill="#2b4a5c"/g, 'fill="#2b4a5c" opacity=".7"')}${skyline(W, H, H * 0.92, '#102832', '#f6c57a', 5)}<rect y="${H * 0.92}" width="${W}" height="${H * 0.08}" fill="#0b1d25"/>`,
    grad('s', [[0, '#16323f'], [0.55, '#35607a'], [1, '#f0a85a']]) + glow('g', '#ffd9a0')),
  sunset: (W, H) => svg(W, H,
    `<rect width="${W}" height="${H}" fill="url(#s)"/>${sun(W * 0.5, H * 0.58, H * 0.12, '#ffe7ae', 'g')}${trail(W * 0.22, H * 0.3)}${birds([[W * 0.72, H * 0.26], [W * 0.78, H * 0.21, 0.8]], '#3b2230')}` +
    `<rect y="${H * 0.62}" width="${W}" height="${H * 0.38}" fill="url(#sea)"/><rect x="${W * 0.44}" y="${H * 0.62}" width="${W * 0.12}" height="${H * 0.3}" fill="url(#refl)" opacity=".7"/>` +
    `${ridge(W, H, H * 0.66, H * 0.07, '#5b3a52', 4)}${ridge(W, H, H * 0.82, H * 0.06, '#3a2540', 5)}${ridge(W, H, H * 0.94, H * 0.04, '#241830', 6)}`,
    grad('s', [[0, '#3b4a78'], [0.45, '#e2736b'], [1, '#fbc27a']]) + grad('sea', [[0, '#d98a6a'], [1, '#4a3258']]) + grad('refl', [[0, '#ffe7ae'], [1, '#ffe7ae00']]) + glow('g', '#ffd9a0')),
  forest: (W, H) => svg(W, H,
    `<rect width="${W}" height="${H}" fill="url(#s)"/>${sun(W * 0.78, H * 0.28, H * 0.07, '#fff5cf', 'g')}${trail(W * 0.3, H * 0.24)}${birds([[W * 0.55, H * 0.2], [W * 0.6, H * 0.25, 0.8]])}` +
    `${ridge(W, H, H * 0.55, H * 0.08, '#a8d3bf', 1)}${ridge(W, H, H * 0.68, H * 0.07, '#79b59c', 2)}${pines(W, H * 0.8, Math.round(W / 36), H * 0.2, ['#2f7a63', '#3a8a70'], 1)}${pines(W, H * 0.92, Math.round(W / 30), H * 0.26, ['#1c5a4b', '#23675a'], 3)}<rect y="${H * 0.92}" width="${W}" height="${H * 0.08}" fill="#123f37"/>`,
    grad('s', [[0, '#cfe9de'], [0.7, '#f7f1d6'], [1, '#fbe6b4']]) + glow('g', '#fff5cf')),
};

export const SCENE_NAMES = Object.keys(SCENES);
const cache = {};
const encode = (s) => `data:image/svg+xml;utf8,${encodeURIComponent(s)}`;
export const scene = (name = 'beach') => {
  const k = SCENES[name] ? name : 'beach';
  return (cache[k] ||= encode(SCENES[k](1200, 400)));
};
// Tall version for the sidebar picture panel
export const sideScene = (name = 'mountain') => {
  const k = SCENES[name] ? name : 'mountain';
  return (cache['side' + k] ||= encode(SCENES[k](300, 360)));
};

// Full-height artwork for the sidebar background (portrait, 360x1000). Rich dusk colours; the whole sidebar is the picture.
const SB_W = 360, SB_H = 1000;
const sbPeaks = (base, color, list) => `<path d="M0 ${SB_H} L0 ${base} ${list.map(([x, y]) => `L${x} ${y}`).join(' ')} L${SB_W} ${base} L${SB_W} ${SB_H}Z" fill="${color}"/>`;
const SIDEBAR = {
  dusk: () => svg(SB_W, SB_H,
    `<rect width="${SB_W}" height="${SB_H}" fill="url(#s)"/>${stars(SB_W, SB_H * 1.2, 46)}` +
    `<circle cx="270" cy="${SB_H * 0.74}" r="230" fill="url(#g)"/><circle cx="270" cy="${SB_H * 0.74}" r="46" fill="#ffe2a8"/>` +
    `<circle cx="290" cy="90" r="22" fill="#fff6dc" opacity=".92"/><circle cx="290" cy="90" r="70" fill="url(#m)"/>` +
    `${trail(300, 185)}${birds([[215, 300, 0.9], [245, 282, 0.7]], '#cfe9e6')}` +
    `${ridge(SB_W, SB_H, SB_H * 0.8, 40, '#3f8f93', 3, 0.85)}` +
    sbPeaks(SB_H * 0.86, '#25636d', [[40, SB_H * 0.78], [100, SB_H * 0.84], [175, SB_H * 0.72], [250, SB_H * 0.85], [320, SB_H * 0.77]]) +
    `<path d="M175 ${SB_H * 0.72} l-18 26 10 -4 8 10 8 -11 10 5z" fill="#eaf6f4" opacity=".9"/>` +
    sbPeaks(SB_H * 0.92, '#16464f', [[0, SB_H * 0.88], [70, SB_H * 0.83], [140, SB_H * 0.9], [220, SB_H * 0.82], [300, SB_H * 0.9], [360, SB_H * 0.86]]) +
    `${pines(SB_W, SB_H * 0.95, 14, 90, ['#0d3338', '#10393e'], 2)}${pines(SB_W, SB_H, 12, 120, ['#08262a', '#0a2c30'], 5)}`,
    grad('s', [[0, '#0c2430'], [0.3, '#175057'], [0.55, '#2f7d80'], [0.7, '#9d8a63'], [0.78, '#f0b25e'], [1, '#2b6a70']]) + glow('g', '#f6c46e') + glow('m', '#cfe9e6')),
  city: () => svg(SB_W, SB_H,
    `<rect width="${SB_W}" height="${SB_H}" fill="url(#s)"/>${stars(SB_W, SB_H * 1.1, 52)}` +
    `<circle cx="290" cy="95" r="20" fill="#fff3d0" opacity=".92"/><circle cx="290" cy="95" r="64" fill="url(#m)"/>${trail(300, 190)}` +
    `<circle cx="230" cy="${SB_H * 0.76}" r="220" fill="url(#g)"/>` +
    `${skyline(SB_W, SB_H, SB_H * 0.78, '#2c4a73', '#f8cf86', 3).replace(/<rect([^>]*)fill="#2c4a73"/g, '<rect$1fill="#2c4a73" opacity=".75"')}` +
    `${skyline(SB_W, SB_H, SB_H * 0.88, '#16294a', '#f8cf86', 6)}${skyline(SB_W, SB_H, SB_H * 1.0, '#0c1a30', '#f8cf86', 9)}`,
    grad('s', [[0, '#0b1a2e'], [0.35, '#1d3a63'], [0.6, '#4a5f8f'], [0.74, '#e0925a'], [0.82, '#f2b45e'], [1, '#14263f']]) + glow('g', '#f6b866') + glow('m', '#dbe8ff')),
};
export const sidebarArt = (name = 'dusk') => {
  const k = SIDEBAR[name] ? name : 'dusk';
  return (cache['sbart' + k] ||= encode(SIDEBAR[k]()));
};
// Large portrait version for the login hero
export const heroScene = (name = 'sunset') => {
  const k = SCENES[name] ? name : 'sunset';
  return (cache['hero' + k] ||= encode(SCENES[k](900, 1000)));
};
// Pick a stable scene for any string (trip id, destination id, etc.)
export const sceneFor = (key = '') => {
  let h = 0;
  for (const ch of String(key)) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return SCENE_NAMES[h % SCENE_NAMES.length];
};
// CSS background: the real photo on top, the built-in illustration underneath as a fallback.
export const photo = (url, key, overlay = '') => `${overlay ? overlay + ', ' : ''}${url ? `url("${url}"), ` : ''}url("${scene(sceneFor(key))}")`;
export const onImgError = (key) => (e) => { e.currentTarget.onerror = null; e.currentTarget.src = scene(sceneFor(key)); };
