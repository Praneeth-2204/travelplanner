import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BadgePercent, Briefcase, CalendarDays, MapPin, NotebookPen, Search, Tags, Ticket, Users, X } from 'lucide-react';
import { useApp } from '../context/AppContext.jsx';

const enc = encodeURIComponent;
const has = (s, ...fields) => fields.some((f) => String(f || '').toLowerCase().includes(s));
const MAX = 4;

// Overall search for the top bar. Travellers search destinations, their trips, bookings,
// itinerary and notes. Admins search users, destinations, trips, categories and offers.
export default function GlobalSearch() {
  const { data, user } = useApp();
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(false);
  const [hi, setHi] = useState(0);
  const nav = useNavigate();
  const ref = useRef(null);
  const admin = user.role === 'admin';
  const s = q.trim().toLowerCase();

  const groups = useMemo(() => {
    if (!s) return [];
    const destName = (id) => data.destinations.find((d) => d.id === id)?.name;
    const out = [];
    const add = (label, icon, items) => { if (items.length) out.push({ label, icon, items: items.slice(0, MAX) }); };
    if (admin) {
      add('Users', Users, data.users.filter((u) => has(s, u.name, u.email, u.username))
        .map((u) => ({ key: u.id, title: u.name, sub: `${u.email} · ${u.role}`, to: `/admin/users?q=${enc(u.name)}` })));
      add('Destinations', MapPin, data.destinations.filter((d) => has(s, d.name, d.city, d.country, d.region))
        .map((d) => ({ key: d.id, title: d.name, sub: `${d.city}, ${d.country}`, to: `/admin/destinations?q=${enc(d.name)}` })));
      add('Trips', Briefcase, data.trips.map((t) => ({ t, who: data.users.find((u) => u.id === t.userId)?.name || '' })).filter(({ t, who }) => has(s, t.title, who))
        .map(({ t, who }) => ({ key: t.id, title: t.title, sub: `by ${who}`, to: `/admin/trips?q=${enc(t.title)}` })));
      add('Categories', Tags, [...data.categories.filter((c) => has(s, c.name)).map((c) => ({ key: c.id, title: c.name, sub: 'Destination category', to: '/admin/categories' })),
        ...data.activityCategories.filter((c) => has(s, c)).map((c) => ({ key: `a-${c}`, title: c, sub: 'Activity category', to: '/admin/activities' }))]);
      add('Offers', BadgePercent, data.offers.filter((o) => has(s, o.code, o.title, o.desc))
        .map((o) => ({ key: o.id, title: o.code, sub: o.title, to: '/admin/offers' })));
    } else {
      const mine = data.trips.filter((t) => t.userId === user.id);
      const ids = new Set(mine.map((t) => t.id));
      const tripName = (id) => mine.find((t) => t.id === id)?.title || '';
      add('Destinations', MapPin, data.destinations.filter((d) => d.status === 'active' && has(s, d.name, d.city, d.country, d.region))
        .map((d) => ({ key: d.id, title: d.name, sub: `${d.city}, ${d.country}`, to: `/explore/${d.id}` })));
      add('My trips', Briefcase, mine.filter((t) => has(s, t.title, ...t.destinationIds.map(destName)))
        .map((t) => ({ key: t.id, title: t.title, sub: t.destinationIds.map(destName).filter(Boolean).join(' · '), to: `/trips?q=${enc(t.title)}` })));
      add('Bookings', Ticket, data.bookings.filter((b) => ids.has(b.tripId) && has(s, b.title, b.provider))
        .map((b) => ({ key: b.id, title: b.title, sub: tripName(b.tripId), to: '/bookings' })));
      add('Itinerary', CalendarDays, data.itinerary.filter((i) => ids.has(i.tripId) && has(s, i.title, i.location))
        .map((i) => ({ key: i.id, title: i.title, sub: `${tripName(i.tripId)} · ${i.location}`, to: '/itinerary' })));
      add('Notes', NotebookPen, data.notes.filter((n) => n.userId === user.id && has(s, n.title, n.body))
        .map((n) => ({ key: n.id, title: n.title, sub: 'Travel note', to: '/notes' })));
    }
    return out;
  }, [s, data, user, admin]);

  const flat = groups.flatMap((g) => g.items);
  useEffect(() => { setHi(0); }, [s]);
  useEffect(() => {
    const h = (e) => { ref.current && !ref.current.contains(e.target) && setOpen(false); };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);

  const go = (to) => { setOpen(false); setQ(''); nav(to); };
  const submit = (e) => {
    e.preventDefault();
    if (!s) return;
    if (flat[hi]) return go(flat[hi].to);
    if (!admin) go(`/explore?q=${enc(q.trim())}`);
  };
  const onKey = (e) => {
    if (e.key === 'Escape') setOpen(false);
    else if (e.key === 'ArrowDown' && flat.length) { e.preventDefault(); setOpen(true); setHi((h) => (h + 1) % flat.length); }
    else if (e.key === 'ArrowUp' && flat.length) { e.preventDefault(); setHi((h) => (h - 1 + flat.length) % flat.length); }
  };

  let n = -1;
  return (
    <div className="gsearch-wrap" ref={ref}>
      <form className="gsearch" onSubmit={submit} role="search">
        <Search size={16} />
        <input value={q} onChange={(e) => { setQ(e.target.value); setOpen(true); }} onFocus={() => setOpen(true)} onKeyDown={onKey}
          placeholder={admin ? 'Search users, trips, destinations…' : 'Search destinations, trips, bookings…'} aria-label="Global search" />
        {q && <button type="button" className="gs-clear" onClick={() => { setQ(''); setOpen(false); }} aria-label="Clear search"><X size={14} /></button>}
      </form>
      {open && s && (
        <div className="gsearch-pop">
          {groups.length ? groups.map((g) => (
            <div key={g.label} className="gs-group">
              <h4><g.icon size={13} /> {g.label}</h4>
              {g.items.map((it) => {
                n += 1; const idx = n;
                return (
                  <button key={it.key} type="button" className={`gs-item ${idx === hi ? 'on' : ''}`} onMouseEnter={() => setHi(idx)} onClick={() => go(it.to)}>
                    <b>{it.title}</b><small>{it.sub}</small>
                  </button>
                );
              })}
            </div>
          )) : <p className="gs-none">No matches for “{q.trim()}”.</p>}
        </div>
      )}
    </div>
  );
}
