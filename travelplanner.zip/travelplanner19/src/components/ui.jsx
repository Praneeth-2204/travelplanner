import { useEffect, useRef } from 'react';
import { ImagePlus, Pencil as PencilIcon, Trash2 as TrashIcon, X } from 'lucide-react';

export const PageHead = ({ title, sub, children }) => (
  <div className="page-head">
    <div><h2>{title}</h2>{sub && <p className="muted">{sub}</p>}</div>
    {children && <div className="actions" style={{ margin: 0 }}>{children}</div>}
  </div>
);

export const Empty = ({ icon: Icon, title = 'Nothing here yet', text, children }) => (
  <div className="empty">
    {Icon && <div className="empty-icon"><Icon size={28} /></div>}
    <h2>{title}</h2>{text && <p>{text}</p>}{children}
  </div>
);

// cols: [{ h: 'Header', r: (row) => node }]
export function DataTable({ cols, rows, empty }) {
  if (!rows.length) return empty;
  return (
    <div className="card tbl-wrap">
      <table className="tbl">
        <thead><tr>{cols.map((c) => <th key={c.h}>{c.h}</th>)}</tr></thead>
        <tbody>{rows.map((r, i) => <tr key={r.id || i}>{cols.map((c) => <td key={c.h}>{c.r(r)}</td>)}</tr>)}</tbody>
      </table>
    </div>
  );
}

export function Modal({ title, onClose, onSubmit, submitLabel = 'Save', children, danger, wide }) {
  useEffect(() => {
    const h = (e) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', h);
    return () => document.removeEventListener('keydown', h);
  }, [onClose]);
  return (
    <div className="modal-wrap" role="dialog" aria-modal="true" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <form className="modal" style={wide ? { maxWidth: 720 } : undefined} onSubmit={(e) => { e.preventDefault(); onSubmit(); }} noValidate>
        <header><h2>{title}</h2><button type="button" className="icon-btn" onClick={onClose} aria-label="Close"><X size={18} /></button></header>
        <div className="modal-body">{children}</div>
        <footer>
          <button type="button" className="btn" onClick={onClose}>Cancel</button>
          <button className={`btn ${danger ? 'danger' : 'primary'}`} type="submit">{submitLabel}</button>
        </footer>
      </form>
    </div>
  );
}

export const Confirm = ({ title, text, confirmLabel = 'Delete', onConfirm, onClose }) => (
  <Modal title={title} onClose={onClose} submitLabel={confirmLabel} danger onSubmit={() => { onConfirm(); onClose(); }}><p style={{ marginBottom: 14 }}>{text}</p></Modal>
);

export const Field = ({ label, error, children }) => (
  <label className="field"><span>{label}</span>{children}{error && <small className="err">{error}</small>}</label>
);

export const IconActions = ({ onEdit, onDelete, label = '' }) => (
  <span className="row-actions">
    {onEdit && <button className="icon-btn sm" onClick={onEdit} aria-label={`Edit ${label}`} title="Edit"><PencilIcon /></button>}
    {onDelete && <button className="icon-btn sm danger" onClick={onDelete} aria-label={`Delete ${label}`} title="Delete"><TrashIcon /></button>}
  </span>
);

export const TripSelect = ({ trips, value, onChange, all = true }) => (
  <select value={value} onChange={(e) => onChange(e.target.value)} aria-label="Trip">
    {all && <option value="all">All trips</option>}
    {trips.map((t) => <option key={t.id} value={t.id}>{t.title}</option>)}
  </select>
);

// Shrinks an uploaded photo so it fits comfortably in LocalStorage.
const shrink = (file) => new Promise((resolve, reject) => {
  const r = new FileReader();
  r.onerror = () => reject(new Error('Could not read that file.'));
  r.onload = () => {
    const im = new Image();
    im.onerror = () => reject(new Error('That file is not a valid image.'));
    im.onload = () => {
      const k = Math.min(1, 800 / Math.max(im.width, im.height));
      const c = document.createElement('canvas');
      c.width = Math.round(im.width * k); c.height = Math.round(im.height * k);
      c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
      resolve(c.toDataURL('image/jpeg', 0.8));
    };
    im.src = r.result;
  };
  r.readAsDataURL(file);
});

export function ImagePicker({ value, onChange, onError, fallback }) {
  const ref = useRef(null);
  const pick = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    try { onChange(await shrink(file)); } catch (x) { onError?.(x.message); }
  };
  const isData = (value || '').startsWith('data:');
  return (
    <div className="field">
      <span>Picture</span>
      <div className="img-picker">
        <div className="img-prev" style={{ backgroundImage: `url("${value || fallback || ''}")` }}>{!value && !fallback && <ImagePlus size={22} />}</div>
        <div className="img-side">
          <input value={isData ? '' : value || ''} placeholder={isData ? 'Uploaded photo' : 'Paste an image link (https://…)'} onChange={(e) => onChange(e.target.value)} />
          <div className="row-actions" style={{ gap: 8 }}>
            <button type="button" className="btn sm" onClick={() => ref.current.click()}><ImagePlus size={14} /> Upload photo</button>
            {value && <button type="button" className="btn sm" onClick={() => onChange('')}>Remove</button>}
          </div>
          <input ref={ref} type="file" accept="image/*" hidden onChange={pick} />
        </div>
      </div>
    </div>
  );
}
