import { LayoutDashboard, Compass, Briefcase, CalendarDays, Ticket, Wallet, Luggage, NotebookPen, Bell, UserRound, Settings, Users, MapPin, Tags, ListChecks, BarChart3, Receipt, BadgePercent, TrendingUp } from 'lucide-react';

const user = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/explore', label: 'Explore Destinations', icon: Compass },
  { to: '/trips', label: 'My Trips', icon: Briefcase },
  { to: '/itinerary', label: 'Itinerary Planner', icon: CalendarDays },
  { to: '/bookings', label: 'Bookings', icon: Ticket },
  { to: '/budget', label: 'Budget & Expenses', icon: Wallet },
  { to: '/packing', label: 'Packing Lists', icon: Luggage },
  { to: '/bills', label: 'Trip Bill', icon: Receipt },
  { to: '/offers', label: 'Offers & Deals', icon: BadgePercent },
  { to: '/notes', label: 'Travel Notes', icon: NotebookPen },
  { to: '/profile', label: 'My Profile', icon: UserRound },
  { to: '/settings', label: 'Settings', icon: Settings },
];
const admin = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/admin/users', label: 'User Management', icon: Users },
  { to: '/admin/destinations', label: 'Destination Management', icon: MapPin },
  { to: '/admin/categories', label: 'Destination Categories', icon: Tags },
  { to: '/admin/activities', label: 'Activity Categories', icon: ListChecks },
  { to: '/admin/trips', label: 'Trip Overview', icon: BarChart3 },
  { to: '/admin/offers', label: 'Offers & Coupons', icon: BadgePercent },
  { to: '/admin/reports', label: 'Revenue Reports', icon: TrendingUp },
  { to: '/admin/settings', label: 'Application Settings', icon: Settings },
  { to: '/profile', label: 'My Profile', icon: UserRound },
];
export const navFor = (role) => (role === 'admin' ? admin : user);
