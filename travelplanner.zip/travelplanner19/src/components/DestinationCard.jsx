import { Link } from 'react-router-dom';
import { Clock, Heart, MapPin } from 'lucide-react';
import { useApp } from '../context/AppContext.jsx';
import { fmtMoney } from '../utils/helpers.js';
import { photo } from '../assets/scenes.js';

export default function DestinationCard({ d }) {
  const { data, user, toggleSaved } = useApp();
  const cat = data.categories.find((c) => c.id === d.categoryId);
  const saved = user.saved.includes(d.id);
  return (
    <article className="dcard">
      <Link to={`/explore/${d.id}`} className="dcard-img" style={{ backgroundImage: photo(d.image, d.id) }} aria-label={d.name}>
        {cat && <span className="chip" style={{ background: cat.color }}>{cat.name}</span>}
      </Link>
      <button className={`heart ${saved ? 'on' : ''}`} onClick={() => toggleSaved(d.id)} aria-label={saved ? 'Remove from saved' : 'Save destination'}>
        <Heart size={17} fill={saved ? 'currentColor' : 'none'} />
      </button>
      <div className="dcard-body">
        <h3><Link to={`/explore/${d.id}`}>{d.name}</Link></h3>
        <p className="loc"><MapPin size={13} /> {d.city}, {d.country}</p>
        <p className="desc">{d.description}</p>
        <div className="dcard-foot">
          <span><Clock size={13} /> {d.bestTime.split(',')[0]}</span>
          <strong>{fmtMoney(d.dailyCost, d.currency)}<small>/day</small></strong>
        </div>
      </div>
    </article>
  );
}
