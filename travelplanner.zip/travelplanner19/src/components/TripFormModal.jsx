import { useState } from 'react';
import { X } from 'lucide-react';
import { useApp } from '../context/AppContext.jsx';
import { daysBetween, iso } from '../utils/helpers.js';

const TYPES = ['solo', 'family', 'friends', 'business', 'adventure'];
const CURRENCIES = ['INR', 'USD', 'EUR', 'JPY', 'CHF', 'GBP'];

export default function TripFormModal({ trip, presetDestination, onClose, onSave }) {
  const { data, user } = useApp();
  const [f, setF] = useState(() => trip || {
    title: '', description: '', destinationIds: presetDestination ? [presetDestination] : [], departureDate: iso(30), returnDate: iso(35),
    travellers: 2, type: 'friends', budget: '', currency: user.currency, preferences: '',
  });
  const [err, setErr] = useState({});
  const set = (k, v) => setF((p) => ({ ...p, [k]: v }));
  const toggleDest = (id) => set('destinationIds', f.destinationIds.includes(id) ? f.destinationIds.filter((x) => x !== id) : [...f.destinationIds, id]);

  const submit = (e) => {
    e.preventDefault();
    const x = {};
    if (!f.title.trim()) x.title = 'Give your trip a title.';
    if (!f.destinationIds.length) x.destinationIds = 'Pick at least one destination.';
    if (!f.departureDate) x.departureDate = 'Required.';
    if (!f.returnDate) x.returnDate = 'Required.';
    if (f.departureDate && f.returnDate && daysBetween(f.departureDate, f.returnDate) < 0) x.returnDate = 'Return date cannot be before departure.';
    const n = Number(f.travellers);
    if (!Number.isInteger(n) || n < 1 || n > 50) x.travellers = 'Enter 1–50 travellers.';
    if (!(Number(f.budget) > 0)) x.budget = 'Enter a budget greater than 0.';
    setErr(x);
    if (Object.keys(x).length) return;
    const first = data.destinations.find((d) => d.id === f.destinationIds[0]);
    onSave({ ...f, title: f.title.trim(), travellers: n, budget: Number(f.budget), image: first?.image || f.image });
  };

  const Err = ({ k }) => (err[k] ? <small className="err">{err[k]}</small> : null);

  return (
    <div className="modal-wrap" role="dialog" aria-modal="true" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <form className="modal" onSubmit={submit} noValidate>
        <header><h2>{trip ? 'Edit trip' : 'Plan a new trip'}</h2><button type="button" className="icon-btn" onClick={onClose} aria-label="Close"><X size={18} /></button></header>
        <div className="modal-body">
          <label className="field"><span>Trip title *</span><input value={f.title} onChange={(e) => set('title', e.target.value)} placeholder="e.g. Summer in Bali" /><Err k="title" /></label>
          <label className="field"><span>Description</span><textarea rows={2} value={f.description} onChange={(e) => set('description', e.target.value)} /></label>
          <div className="field"><span>Destinations *</span>
            <div className="chips">{data.destinations.filter((d) => d.status === 'active').map((d) => (
              <button type="button" key={d.id} className={`fchip ${f.destinationIds.includes(d.id) ? 'on' : ''}`} onClick={() => toggleDest(d.id)}>{d.name}</button>
            ))}</div><Err k="destinationIds" /></div>
          <div className="row2">
            <label className="field"><span>Departure *</span><input type="date" value={f.departureDate} onChange={(e) => set('departureDate', e.target.value)} /><Err k="departureDate" /></label>
            <label className="field"><span>Return *</span><input type="date" min={f.departureDate} value={f.returnDate} onChange={(e) => set('returnDate', e.target.value)} /><Err k="returnDate" /></label>
          </div>
          <div className="row3">
            <label className="field"><span>Travellers *</span><input type="number" min="1" max="50" value={f.travellers} onChange={(e) => set('travellers', e.target.value)} /><Err k="travellers" /></label>
            <label className="field"><span>Trip type</span><select value={f.type} onChange={(e) => set('type', e.target.value)}>{TYPES.map((t) => <option key={t} value={t}>{t[0].toUpperCase() + t.slice(1)}</option>)}</select></label>
            <label className="field"><span>Currency</span><select value={f.currency} onChange={(e) => set('currency', e.target.value)}>{CURRENCIES.map((c) => <option key={c}>{c}</option>)}</select></label>
          </div>
          <label className="field"><span>Total budget ({f.currency}) *</span><input type="number" min="0" value={f.budget} onChange={(e) => set('budget', e.target.value)} placeholder="e.g. 50000" /><Err k="budget" /></label>
          <label className="field"><span>Travel preferences</span><input value={f.preferences} onChange={(e) => set('preferences', e.target.value)} placeholder="Beach stay, vegetarian food, slow pace…" /></label>
        </div>
        <footer><button type="button" className="btn" onClick={onClose}>Cancel</button><button className="btn primary" type="submit">{trip ? 'Save changes' : 'Create trip'}</button></footer>
      </form>
    </div>
  );
}
