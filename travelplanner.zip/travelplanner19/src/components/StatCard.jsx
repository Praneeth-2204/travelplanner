export default function StatCard({ icon: Icon, label, value, hint, tone = 'blue' }) {
  return (
    <div className="stat">
      <span className={`stat-icon ${tone}`}><Icon size={20} /></span>
      <div><small>{label}</small><strong>{value}</strong>{hint && <em>{hint}</em>}</div>
    </div>
  );
}
