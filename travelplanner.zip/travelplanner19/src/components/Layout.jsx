import { useEffect, useRef, useState } from 'react';
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { Bell, ChevronRight, LogOut, Menu, Moon, Plane, Sun, UserRound } from 'lucide-react';
import { useApp } from '../context/AppContext.jsx';
import { navFor } from './nav.js';
import GlobalSearch from './GlobalSearch.jsx';
import { initials } from '../utils/helpers.js';
import { scene, sidebarArt } from '../assets/scenes.js';

const BANNERS = {
  '/explore': ['beach', 'Where will you wake up next?'],
  '/trips': ['mountain', 'Every journey begins with a plan'],
  '/itinerary': ['sunset', 'Make every day count'],
  '/bookings': ['city', 'Tickets, stays and rides — sorted'],
  '/budget': ['beach', 'Travel more, stress less'],
  '/packing': ['forest', 'Pack light, travel far'],
  '/notes': ['sunset', 'Little details, big memories'],
  '/bills': ['city', 'Your trip, itemised'],
  '/offers': ['beach', 'Deals made for travellers'],
  '/admin/offers': ['sunset', 'Create deals travellers love'],
  '/admin/reports': ['city', 'Revenue across the platform'],
  '/profile': ['mountain', 'Your travel profile'],
  '/settings': ['forest', 'Make it yours'],
  '/admin/users': ['city', 'Our community of travellers'],
  '/admin/destinations': ['beach', 'Curate the world’s best places'],
  '/admin/categories': ['forest', 'Group places by the way people travel'],
  '/admin/activities': ['sunset', 'Things to do, everywhere'],
  '/admin/trips': ['mountain', 'Trips happening across the platform'],
  '/admin/settings': ['forest', 'Make it yours'],
};


export default function Layout() {
  const { ui, user, logout, unreadCount, myNotifications, markRead, markAllRead, setTheme, resolvedTheme, data, toast } = useApp();
  const [bell, setBell] = useState(false);
  const bellRef = useRef(null);
  const dark = resolvedTheme === 'dark';
  const appName = data.appSettings.appName;
  const [open, setOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(() => { try { return localStorage.getItem('tp_side') === '1'; } catch { return false; } });
  const [menu, setMenu] = useState(false);
  const loc = useLocation();
  const nav = useNavigate();
  const items = navFor(user.role);
  const menuRef = useRef(null);

  const toggleSide = () => {
    if (window.matchMedia('(max-width: 900px)').matches) return setOpen((o) => !o);
    setCollapsed((c) => { try { localStorage.setItem('tp_side', c ? '0' : '1'); } catch { /* ignore */ } return !c; });
  };
  useEffect(() => { setOpen(false); setMenu(false); setBell(false); window.scrollTo(0, 0); }, [loc.pathname]);
  useEffect(() => {
    const h = (e) => { menuRef.current && !menuRef.current.contains(e.target) && setMenu(false); bellRef.current && !bellRef.current.contains(e.target) && setBell(false); };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);

  // Page title + breadcrumbs derived from the current route
  const current = items.find((i) => loc.pathname === i.to || loc.pathname.startsWith(i.to + '/'));
  const dest = loc.pathname.startsWith('/explore/') ? data.destinations.find((d) => d.id === loc.pathname.split('/')[2]) : null;
  const title = dest ? dest.name : current?.label || appName;
  const crumbs = [{ label: 'Home', to: '/dashboard' }, ...(current && current.to !== '/dashboard' ? [{ label: current.label, to: current.to }] : []), ...(dest ? [{ label: dest.name }] : [])];

  const banner = ui.banners ? BANNERS[loc.pathname] : null;

  return (
    <div className={`shell ${collapsed ? 'collapsed' : ''}`}>
      {open && <div className="scrim" onClick={() => setOpen(false)} />}
      <aside className={`sidebar ${open ? 'open' : ''}`} style={{ '--side-img': `url("${sidebarArt('dusk')}")` }}>
        <div className="brand">
          <span className="brand-mark"><Plane size={18} /></span>
          <span>{appName}</span>
        </div>
        <div className="nav-label">{user.role === 'admin' ? 'Administration' : 'Plan your travel'}</div>
        <nav>
          {items.map(({ to, label, icon: Icon }) => (
            <NavLink key={to} to={to} title={label} className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
              <Icon size={18} /> <span>{label}</span>
            </NavLink>
          ))}
        </nav>
        <div className="side-foot">
          <Link to="/profile" className="side-user" title={user.name}><span className="avatar">{initials(user.name)}</span><span><b>{user.name}</b><small>{user.email}</small></span></Link>
          <button className="nav-item" title="Log out" onClick={() => { logout(); nav('/login'); }}><LogOut size={18} /> <span>Log out</span></button>
        </div>
      </aside>

      <div className="main">
        <header className="topbar">
          <button className="icon-btn menu-toggle" onClick={toggleSide} aria-label="Toggle sidebar" title="Toggle sidebar"><Menu size={20} /></button>
          <div className="titles">
            <nav className="crumbs" aria-label="Breadcrumb">
              {crumbs.map((c, i) => (
                <span key={c.label}>
                  {c.to && i < crumbs.length - 1 ? <Link to={c.to}>{c.label}</Link> : <b>{c.label}</b>}
                  {i < crumbs.length - 1 && <ChevronRight size={12} />}
                </span>
              ))}
            </nav>
            <h1>{title}</h1>
          </div>
          <GlobalSearch />
          <button className="icon-btn" onClick={() => setTheme(dark ? 'light' : 'dark')} aria-label="Toggle dark mode" title="Toggle light/dark">{dark ? <Sun size={18} /> : <Moon size={18} />}</button>
          <div className="notif-wrap" ref={bellRef}>
            <button className="icon-btn bell" onClick={() => setBell(!bell)} aria-label="Notifications">
              <Bell size={19} />{unreadCount > 0 && <span className="badge">{unreadCount}</span>}
            </button>
            {bell && (
              <div className="notif">
                <header><b>Notifications</b>{unreadCount > 0 && <button className="link" onClick={markAllRead}>Mark all read</button>}</header>
                {myNotifications.length ? (
                  <ul>{myNotifications.map((n) => (
                    <li key={n.id} className={`${n.read ? '' : 'unread'} ${n.level}`}>
                      <Link to={n.to} onClick={() => markRead(n.id)}><i className="dot" /><div><b>{n.text}</b><small>{n.sub}</small></div></Link>
                    </li>
                  ))}</ul>
                ) : <p className="none">You're all caught up.</p>}
              </div>
            )}
          </div>
          <div className="profile" ref={menuRef}>
            <button className="avatar-btn" onClick={() => setMenu(!menu)} aria-label="Profile menu">
              <span className="avatar">{initials(user.name)}</span>
              <span className="who"><b>{user.name}</b><small>{user.role}</small></span>
            </button>
            {menu && (
              <div className="menu">
                <Link to="/profile"><UserRound size={15} /> My profile</Link>
                <button onClick={() => { logout(); nav('/login'); }}><LogOut size={15} /> Log out</button>
              </div>
            )}
          </div>
        </header>
        <main className="content">
          {banner && (
            <div className="banner" style={{ backgroundImage: `linear-gradient(90deg, color-mix(in srgb, var(--sb) 84%, transparent), transparent 75%), url("${scene(banner[0])}")` }}>
              <small>{appName}</small><h2>{banner[1]}</h2>
            </div>
          )}
          {/* keyed by route so every page opens fresh (filters reset, latest data, scrolled to top) */}
          <div key={loc.pathname} className="page-enter"><Outlet /></div>
        </main>
        {toast && <div className="toast" role="status">{toast}</div>}
      </div>
    </div>
  );
}
