import { useState } from 'react';
import { BadgePercent, Check, Download, Plane, Printer, Receipt, Tag, X } from 'lucide-react';
import { useApp } from '../context/AppContext.jsx';
import { Empty, PageHead, TripSelect } from '../components/ui.jsx';
import { buildBill, downloadCsv, fmtDate, fmtMoney, offerDiscount, offerState, cap } from '../utils/helpers.js';

export default function Bills() {
  const { data, myTrips, user, saveTrip, notify } = useApp();
  const [tripId, setTripId] = useState(myTrips[0]?.id || '');
  const [code, setCode] = useState('');
  const trip = myTrips.find((t) => t.id === tripId) || myTrips[0];
  if (!trip) return <><PageHead title="Trip bill" sub="Your itemised bill." /><Empty icon={Receipt} title="No trips yet" text="Create a trip and add bookings to generate a bill." /></>;

  const offer = data.offers.find((o) => o.code === trip.offerCode);
  const bill = buildBill(trip, data, offer);
  const cur = trip.currency;
  const m = (n) => fmtMoney(n, cur);
  const apply = (c) => {
    const o = data.offers.find((x) => x.code === c.trim().toUpperCase());
    if (!o) return notify('Invalid coupon code');
    const st = offerState(o, bill.subtotal);
    if (!st.ok) return notify(`${o.code}: ${st.why}`);
    saveTrip({ ...trip, offerCode: o.code }); setCode(''); notify(`${o.code} applied — you saved ${m(offerDiscount(o, bill.subtotal))}`);
  };
  const remove = () => { saveTrip({ ...trip, offerCode: '' }); notify('Coupon removed'); };
  const csv = () => downloadCsv(`${bill.no}.csv`, [['Item', 'Type', 'Provider', 'Amount'], ...bill.lines.map((l) => [l.label, l.kind, l.sub, l.amount]), [], ['Subtotal', '', '', bill.subtotal], ['Service fee', '', '', bill.fee], ['Discount', '', '', -bill.discount], [`GST ${data.appSettings.taxRate}%`, '', '', bill.tax], ['Total', '', '', bill.total]]);
  const open = data.offers.filter((o) => o.active && (!o.expires || o.expires >= new Date().toISOString().slice(0, 10)));

  return (
    <>
      <PageHead title="Trip bill" sub="A clean, itemised bill with your best offers applied.">
        <TripSelect trips={myTrips} value={trip.id} onChange={setTripId} all={false} />
        <button className="btn" onClick={csv}><Download size={15} /> CSV</button>
        <button className="btn primary" onClick={() => window.print()}><Printer size={15} /> Print / PDF</button>
      </PageHead>
      <div className="bill-grid">
        <article className="invoice card">
          <header className="inv-head">
            <div><span className="brand-mark"><Plane size={18} /></span><b>{data.appSettings.appName}</b><small>{data.appSettings.supportEmail}</small></div>
            <div className="inv-meta"><h3>INVOICE</h3><small>{bill.no}</small><small>Date: {fmtDate(new Date().toISOString().slice(0, 10))}</small></div>
          </header>
          <div className="inv-to"><small>Billed to</small><b>{user.name}</b><span>{user.email}</span></div>
          <div className="inv-trip"><b>{trip.title}</b><span>{fmtDate(trip.departureDate)} – {fmtDate(trip.returnDate)} · {trip.travellers} traveller{trip.travellers > 1 ? 's' : ''}</span></div>
          {bill.lines.length ? (
            <table className="tbl inv-tbl"><thead><tr><th>Item</th><th>Type</th><th className="r">Amount</th></tr></thead>
              <tbody>{bill.lines.map((l) => <tr key={l.id}><td><b>{l.label}</b><br /><small className="muted">{l.sub}</small></td><td><span className="tag">{cap(l.kind)}</span></td><td className="r">{m(l.amount)}</td></tr>)}</tbody></table>
          ) : <p className="muted" style={{ padding: 20 }}>No bookings or expenses on this trip yet. Add some to generate the bill.</p>}
          <dl className="totals">
            <div><dt>Subtotal</dt><dd>{m(bill.subtotal)}</dd></div>
            <div><dt>Service fee ({data.appSettings.serviceFee}%)</dt><dd>{m(bill.fee)}</dd></div>
            {offer && bill.discount > 0 && <div className="save"><dt><Tag size={13} /> Offer {offer.code}</dt><dd>− {m(bill.discount)}</dd></div>}
            <div><dt>GST ({data.appSettings.taxRate}%)</dt><dd>{m(bill.tax)}</dd></div>
            <div className="grand"><dt>Total payable</dt><dd>{m(bill.total)}</dd></div>
          </dl>
          {bill.discount > 0 && <p className="saved-pill"><Check size={14} /> You saved {m(bill.discount)} on this trip!</p>}
          <footer className="inv-foot">Thank you for travelling with {data.appSettings.appName}. Prices shown in {cur}.</footer>
        </article>

        <aside className="stack no-print">
          <section className="card"><h3><BadgePercent size={17} /> Apply a coupon</h3>
            {offer ? <div className="applied"><span><b>{offer.code}</b><small>{offer.title}</small></span><button className="icon-btn sm" onClick={remove} aria-label="Remove coupon"><X /></button></div>
              : <form className="coupon" onSubmit={(e) => { e.preventDefault(); apply(code); }}><input value={code} onChange={(e) => setCode(e.target.value)} placeholder="Enter code" /><button className="btn primary sm">Apply</button></form>}
          </section>
          <section className="card"><h3>Offers for you</h3>
            {open.map((o) => { const st = offerState(o, bill.subtotal); return (
              <div key={o.id} className={`offer-mini ${st.ok ? '' : 'off'}`}>
                <div><b>{o.code}</b><small>{o.desc}</small>{!st.ok && <small className="err">{st.why}</small>}</div>
                <button className="btn sm" disabled={!st.ok || trip.offerCode === o.code} onClick={() => apply(o.code)}>{trip.offerCode === o.code ? 'Applied' : `Save ${m(offerDiscount(o, bill.subtotal))}`}</button>
              </div>); })}
          </section>
        </aside>
      </div>
    </>
  );
}
