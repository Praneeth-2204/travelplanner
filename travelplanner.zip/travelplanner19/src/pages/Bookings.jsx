import { useMemo, useState } from 'react';
import { BedDouble, Bus, CalendarCheck, Plane, Plus, Search, Star, Ticket, Utensils, X } from 'lucide-react';
import { useApp } from '../context/AppContext.jsx';
import { Confirm, DataTable, Empty, Field, IconActions, Modal, PageHead, TripSelect } from '../components/ui.jsx';
import { addDays, BOOKING_LABEL, cap, fmtDate, fmtMoney, nightsBetween, today } from '../utils/helpers.js';

const TYPES = { flight: Plane, accommodation: BedDouble, transport: Bus, activity: Ticket, restaurant: Utensils };
const STATUS = ['confirmed', 'pending', 'cancelled'];
const SORTS = { date: 'Date (earliest first)', dateDesc: 'Date (latest first)', costDesc: 'Cost (high to low)', costAsc: 'Cost (low to high)' };

export default function Bookings() {
  const { data, myTrips, saveItem, removeItem, notify } = useApp();
  const [tripId, setTripId] = useState('all');
  const [status, setStatus] = useState('all');
  const [type, setType] = useState('all');
  const [q, setQ] = useState('');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [sort, setSort] = useState('date');
  const [modal, setModal] = useState(null);
  const [del, setDel] = useState(null);
  const [f, setF] = useState({});
  const [err, setErr] = useState({});

  const trip = (id) => myTrips.find((t) => t.id === id);
  const ids = new Set(myTrips.map((t) => t.id));
  const mine = data.bookings.filter((b) => ids.has(b.tripId) && (tripId === 'all' || b.tripId === tripId));

  // Every filter works together: trip, type, status, search text and a date range.
  const rows = useMemo(() => {
    const text = q.trim().toLowerCase();
    const list = mine
      .filter((b) => status === 'all' || b.status === status)
      .filter((b) => type === 'all' || b.type === type)
      .filter((b) => !text || `${b.title} ${b.provider} ${b.city || ''} ${b.reference || ''}`.toLowerCase().includes(text))
      .filter((b) => (!from || b.date >= from) && (!to || b.date <= to));
    const by = { date: (a, b) => a.date.localeCompare(b.date), dateDesc: (a, b) => b.date.localeCompare(a.date), costDesc: (a, b) => b.cost - a.cost, costAsc: (a, b) => a.cost - b.cost };
    return list.sort(by[sort]);
  }, [mine, status, type, q, from, to, sort]);

  const count = (s) => mine.filter((b) => b.status === s).length;
  const typeCount = (t) => mine.filter((b) => (t === 'all' ? true : b.type === t)).length;
  const filtersOn = type !== 'all' || q || from || to || sort !== 'date';
  const clearFilters = () => { setType('all'); setQ(''); setFrom(''); setTo(''); setSort('date'); };

  // Totals of what is shown (cancelled bookings are not counted as money spent).
  const currencies = new Set(rows.map((r) => trip(r.tripId)?.currency));
  const oneCurrency = currencies.size === 1 ? [...currencies][0] : null;
  const total = rows.filter((r) => r.status !== 'cancelled').reduce((s, r) => s + Number(r.cost || 0), 0);

  const blank = () => ({ tripId: tripId !== 'all' ? tripId : myTrips[0]?.id || '', type: type !== 'all' ? type : 'flight', provider: '', date: today(), cost: '', status: 'confirmed', city: '', stars: 3, rooms: 1, checkIn: today(), checkOut: addDays(today(), 1), pricePerNight: '', reference: '' });
  const open = (item) => {
    setErr({});
    if (!item) setF(blank());
    else if (item.type === 'accommodation') {
      const checkIn = item.checkIn || item.date; const checkOut = item.checkOut || addDays(checkIn, 1);
      setF({ city: '', stars: 3, rooms: 1, ...item, checkIn, checkOut, pricePerNight: item.pricePerNight ?? item.cost });
    } else setF({ ...item });
    setModal(item ? 'edit' : 'new');
  };
  const set = (k, v) => setF((p) => ({ ...p, [k]: v }));

  // For hotels the total is worked out from nights x rooms x price per night.
  const isHotel = f.type === 'accommodation';
  const nights = isHotel ? nightsBetween(f.checkIn, f.checkOut) : 0;
  const hotelTotal = isHotel ? Math.round(nights * Number(f.rooms || 0) * Number(f.pricePerNight || 0)) : 0;

  const submit = () => {
    const x = {};
    if (!f.tripId) x.tripId = 'Choose a trip.';
    if (!f.provider.trim()) x.title = isHotel ? 'Enter the hotel name.' : 'Enter the provider or name.';
    if (isHotel) {
      if (!f.checkIn) x.checkIn = 'Pick check-in.';
      if (!f.checkOut) x.checkOut = 'Pick check-out.';
      if (f.checkIn && f.checkOut && nights < 1) x.checkOut = 'Check-out must be after check-in.';
      if (!(Number(f.rooms) >= 1)) x.rooms = 'At least 1 room.';
      if (!(Number(f.pricePerNight) > 0)) x.pricePerNight = 'Enter the price per night.';
    } else {
      if (!f.date) x.date = 'Pick a date.';
      if (f.cost === '' || !(Number(f.cost) >= 0)) x.cost = 'Enter 0 or more.';
    }
    setErr(x);
    if (Object.keys(x).length) return;
    const provider = f.provider.trim();
    const title = `${isHotel ? 'Stay' : cap(f.type)} – ${provider}`;
    const rec = isHotel
      ? { ...f, title, provider, city: (f.city || '').trim(), stars: Number(f.stars), rooms: Number(f.rooms), pricePerNight: Number(f.pricePerNight), date: f.checkIn, cost: hotelTotal }
      : { ...f, title, provider, cost: Number(f.cost) };
    saveItem('bookings', { ...rec, reference: (f.reference || '').trim() }, `booking "${title}"`);
    notify(`${modal === 'edit' ? 'Booking updated' : 'Booking added'}${rec.status === 'cancelled' ? ' – removed from your budget' : ' – added to Budget & expenses'}`);
    setModal(null);
  };

  const detail = (r) => {
    if (r.type === 'accommodation' && r.checkIn) {
      const n = nightsBetween(r.checkIn, r.checkOut);
      return <small className="muted">{r.city ? `${r.city} · ` : ''}{fmtDate(r.checkIn, { day: 'numeric', month: 'short' })} → {fmtDate(r.checkOut, { day: 'numeric', month: 'short' })} · {n} night{n === 1 ? '' : 's'} · {r.rooms} room{r.rooms > 1 ? 's' : ''}{r.stars ? ` · ${r.stars}★` : ''}</small>;
    }
    return <small className="muted">{r.provider || '—'}</small>;
  };

  return (
    <>
      <PageHead title="Bookings" sub="Flights, hotels and tickets. Every booking is added to your Budget & expenses automatically.">
        <TripSelect trips={myTrips} value={tripId} onChange={setTripId} />
        <button className="btn primary" onClick={() => open()} disabled={!myTrips.length}><Plus size={16} /> Add booking</button>
      </PageHead>

      <div className="tabs">
        {['all', ...STATUS].map((s) => <button key={s} className={status === s ? 'on' : ''} onClick={() => setStatus(s)}>{cap(s)} <span>{s === 'all' ? mine.length : count(s)}</span></button>)}
      </div>

      <div className="chips" style={{ marginBottom: 12 }}>
        {['all', ...Object.keys(TYPES)].map((t) => {
          const I = TYPES[t];
          return <button key={t} className={`fchip ${type === t ? 'on' : ''}`} onClick={() => setType(t)} style={{ display: 'inline-flex', gap: 6, alignItems: 'center' }}>{I && <I size={14} />}{t === 'all' ? 'All types' : t === 'accommodation' ? 'Hotels' : BOOKING_LABEL[t] + 's'} <small>({typeCount(t)})</small></button>;
        })}
      </div>

      <div className="filters">
        <div className="search-box"><Search size={16} /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search hotel, provider, city or reference" aria-label="Search bookings" />{q && <button type="button" onClick={() => setQ('')} aria-label="Clear search"><X size={14} /></button>}</div>
        <label className="field" style={{ margin: 0, minWidth: 150 }}><span>From</span><input type="date" value={from} max={to || undefined} onChange={(e) => setFrom(e.target.value)} /></label>
        <label className="field" style={{ margin: 0, minWidth: 150 }}><span>To</span><input type="date" value={to} min={from || undefined} onChange={(e) => setTo(e.target.value)} /></label>
        <select value={sort} onChange={(e) => setSort(e.target.value)} aria-label="Sort bookings">{Object.entries(SORTS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
        {filtersOn && <button className="btn sm" onClick={clearFilters} style={{ alignSelf: 'flex-end' }}>Clear filters</button>}
      </div>

      {rows.length > 0 && (
        <p className="muted" style={{ marginBottom: 12 }}>
          Showing {rows.length} booking{rows.length > 1 ? 's' : ''}{oneCurrency ? <> · active total <b>{fmtMoney(total, oneCurrency)}</b></> : ' · pick one trip to see a total'}
        </p>
      )}

      <DataTable rows={rows} empty={<Empty icon={CalendarCheck} title="No bookings found" text={filtersOn || status !== 'all' ? 'No booking matches these filters. Try clearing them.' : 'Add flights, hotels and tickets so everything is in one place.'}>
        {filtersOn || status !== 'all' ? <button className="btn" onClick={() => { clearFilters(); setStatus('all'); }}>Clear all filters</button> : <button className="btn primary" onClick={() => open()} disabled={!myTrips.length}><Plus size={16} /> Add booking</button>}</Empty>}
        cols={[
          { h: 'Booking', r: (r) => { const I = TYPES[r.type] || Ticket; return <span style={{ display: 'inline-flex', gap: 8, alignItems: 'center' }}><I size={16} /><span><b>{r.title}</b><br />{detail(r)}</span></span>; } },
          { h: 'Type', r: (r) => <span className="tag">{BOOKING_LABEL[r.type] || cap(r.type)}</span> }, { h: 'Trip', r: (r) => trip(r.tripId)?.title },
          { h: 'Date', r: (r) => fmtDate(r.date) },
          { h: 'Cost', r: (r) => <span style={r.status === 'cancelled' ? { textDecoration: 'line-through', opacity: 0.6 } : undefined}>{fmtMoney(r.cost, trip(r.tripId)?.currency)}</span> },
          { h: 'Status', r: (r) => <span className={`status ${r.status === 'confirmed' ? 'ongoing' : r.status === 'pending' ? 'upcoming' : 'cancelled'}`}>{r.status}</span> },
          { h: '', r: (r) => <IconActions label={r.title} onEdit={() => open(r)} onDelete={() => setDel(r)} /> },
        ]} />

      {modal && (
        <Modal title={modal === 'edit' ? 'Edit booking' : 'Add booking'} onClose={() => setModal(null)} onSubmit={submit} submitLabel={modal === 'edit' ? 'Save changes' : 'Add booking'}>
          <Field label="Trip *" error={err.tripId}><select value={f.tripId} onChange={(e) => set('tripId', e.target.value)}>{myTrips.map((t) => <option key={t.id} value={t.id}>{t.title}</option>)}</select></Field>
          <div className="row2">
            <Field label="Type"><select value={f.type} onChange={(e) => set('type', e.target.value)}>{Object.keys(TYPES).map((t) => <option key={t} value={t}>{BOOKING_LABEL[t]}</option>)}</select></Field>
            <Field label="Status"><select value={f.status} onChange={(e) => set('status', e.target.value)}>{STATUS.map((s) => <option key={s} value={s}>{cap(s)}</option>)}</select></Field>
          </div>

          {isHotel ? (
            <>
              <div className="row2">
                <Field label="Hotel name *" error={err.title}><input value={f.provider} onChange={(e) => set('provider', e.target.value)} placeholder="e.g. Le Marais Hotel" /></Field>
                <Field label="City / area"><input value={f.city || ''} onChange={(e) => set('city', e.target.value)} placeholder="e.g. Ubud, Bali" /></Field>
              </div>
              <div className="row2">
                <Field label="Check-in *" error={err.checkIn}><input type="date" value={f.checkIn} onChange={(e) => set('checkIn', e.target.value)} /></Field>
                <Field label="Check-out *" error={err.checkOut}><input type="date" min={f.checkIn} value={f.checkOut} onChange={(e) => set('checkOut', e.target.value)} /></Field>
              </div>
              <div className="row3">
                <Field label="Rooms *" error={err.rooms}><input type="number" min="1" value={f.rooms} onChange={(e) => set('rooms', e.target.value)} /></Field>
                <Field label="Star rating"><select value={f.stars} onChange={(e) => set('stars', e.target.value)}>{[1, 2, 3, 4, 5].map((n) => <option key={n} value={n}>{n} star{n > 1 ? 's' : ''}</option>)}</select></Field>
                <Field label={`Price / night (${trip(f.tripId)?.currency || ''}) *`} error={err.pricePerNight}><input type="number" min="0" step="any" value={f.pricePerNight} onChange={(e) => set('pricePerNight', e.target.value)} /></Field>
              </div>
              <div className="card" style={{ padding: 14, marginBottom: 12, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10 }}>
                <span className="muted"><Star size={14} style={{ verticalAlign: -2 }} /> {nights} night{nights === 1 ? '' : 's'} × {Number(f.rooms) || 0} room{Number(f.rooms) > 1 ? 's' : ''} × {fmtMoney(Number(f.pricePerNight) || 0, trip(f.tripId)?.currency)}</span>
                <strong>{fmtMoney(hotelTotal, trip(f.tripId)?.currency)}</strong>
              </div>
              <Field label="Booking reference"><input value={f.reference || ''} onChange={(e) => set('reference', e.target.value)} placeholder="Optional" /></Field>
            </>
          ) : (
            <>
              <div className="row2">
                <Field label="Provider / name *" error={err.title}><input value={f.provider} onChange={(e) => set('provider', e.target.value)} placeholder="e.g. IndiGo, Goa Cabs" /></Field>
                <Field label="Date *" error={err.date}><input type="date" value={f.date} onChange={(e) => set('date', e.target.value)} /></Field>
              </div>
              <div className="row2">
                <Field label={`Cost (${trip(f.tripId)?.currency || ''}) *`} error={err.cost}><input type="number" min="0" step="any" placeholder="0" value={f.cost} onChange={(e) => set('cost', e.target.value)} /></Field>
                <Field label="Booking reference"><input value={f.reference || ''} onChange={(e) => set('reference', e.target.value)} placeholder="Optional" /></Field>
              </div>
            </>
          )}
          <p className="note">{f.status === 'cancelled' ? 'Cancelled bookings are not counted in your budget.' : 'This amount will be added to Budget & expenses for the trip.'}</p>
        </Modal>
      )}
      {del && <Confirm title="Delete booking?" text={`"${del.title}" will be removed, and its amount will be taken out of Budget & expenses.`} onClose={() => setDel(null)} onConfirm={() => { removeItem('bookings', del.id, `booking "${del.title}"`); notify('Booking deleted'); }} />}
    </>
  );
}
