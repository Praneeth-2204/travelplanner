import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertCircle, Eye, EyeOff, Lock, Mail, Plane, ShieldCheck, User, UserRound } from 'lucide-react';
import { useApp } from '../context/AppContext.jsx';
import { isEmail } from '../utils/helpers.js';
import { heroScene } from '../assets/scenes.js';

export default function Login() {
  const { login, register, data } = useApp();
  const nav = useNavigate();
  const canRegister = data.appSettings.allowRegistration;
  const [mode, setMode] = useState('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [show, setShow] = useState(false);
  const [error, setError] = useState('');
  const signup = mode === 'signup' && canRegister;

  const submit = (e) => {
    e.preventDefault();
    if (signup) {
      if (name.trim().length < 2) return setError('Please enter your full name.');
      if (!isEmail(email.trim())) return setError('Please enter a valid email address.');
      if (password.length < 6) return setError('Password must be at least 6 characters.');
      if (password !== confirm) return setError('Passwords do not match.');
      const r = register({ name, email, password });
      return r.ok ? nav('/dashboard') : setError(r.error);
    }
    if (!email.trim() || !password) return setError('Please enter your email and password.');
    const res = login(email, password);
    return res.ok ? nav('/dashboard') : setError(res.error);
  };
  const fill = (e, p) => { setMode('login'); setEmail(e); setPassword(p); setError(''); };
  const switchMode = (m) => { setMode(m); setError(''); setPassword(''); setConfirm(''); };

  return (
    <div className="login">
      <section className="login-hero" style={{ backgroundImage: `url("${heroScene('sunset')}")` }}>
        <div className="brand light"><span className="brand-mark"><Plane size={18} /></span><span>{data.appSettings.appName}</span></div>
        <div>
          <h2>Every great trip starts with a plan.</h2>
          <p>Explore destinations, build day-wise itineraries, track budgets and pack smarter — all in one place.</p>
        </div>
        <small>Your data is stored locally in this browser</small>
      </section>
      <section className="login-form-wrap">
        <form className="login-card" onSubmit={submit} noValidate>
          <h1>{signup ? 'Create your account' : 'Welcome back'}</h1>
          <p className="muted">{signup ? 'Start planning your next trip in minutes.' : 'Log in to continue planning.'}</p>
          {error && <div className="alert" role="alert"><AlertCircle size={16} /> {error}</div>}
          {signup && (
            <label className="field"><span>Full name</span>
              <div className="input-icon"><UserRound size={16} /><input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" autoComplete="name" /></div></label>
          )}
          <label className="field"><span>Email</span>
            <div className="input-icon"><Mail size={16} /><input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" autoComplete="username" /></div></label>
          <label className="field"><span>Password</span>
            <div className="input-icon"><Lock size={16} />
              <input type={show ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" autoComplete={signup ? 'new-password' : 'current-password'} />
              <button type="button" className="eye" onClick={() => setShow(!show)} aria-label="Toggle password">{show ? <EyeOff size={16} /> : <Eye size={16} />}</button></div></label>
          {signup && (
            <label className="field"><span>Confirm password</span>
              <div className="input-icon"><Lock size={16} /><input type={show ? 'text' : 'password'} value={confirm} onChange={(e) => setConfirm(e.target.value)} placeholder="••••••••" autoComplete="new-password" /></div></label>
          )}
          <button className="btn primary block" type="submit">{signup ? 'Create account' : 'Log in'}</button>
          {canRegister && (
            <p className="center muted" style={{ marginTop: 14 }}>
              {signup ? 'Already have an account? ' : 'New here? '}
              <button type="button" className="link" onClick={() => switchMode(signup ? 'login' : 'signup')}>{signup ? 'Log in' : 'Create an account'}</button>
            </p>
          )}
          <div className="divider"><span>Demo accounts</span></div>
          <div className="demo-row">
            <button type="button" className="demo" onClick={() => fill('user@travel.com', 'user123')}><User size={16} /><b>Traveller</b><small>user@travel.com</small></button>
            <button type="button" className="demo" onClick={() => fill('admin@travel.com', 'admin123')}><ShieldCheck size={16} /><b>Admin</b><small>admin@travel.com</small></button>
          </div>
        </form>
      </section>
    </div>
  );
}
