import { useRef, useState } from 'react';
import { Download, Moon, RotateCcw, Sun, Upload } from 'lucide-react';
import { useApp } from '../context/AppContext.jsx';
import { Confirm, PageHead } from '../components/ui.jsx';
import { downloadJson } from '../utils/helpers.js';

const MODES = [['light', 'Light', Sun], ['dark', 'Dark', Moon]];
const ACCENTS = [['ocean', 'Lagoon', '#0f2a33', '#0e8a86'], ['indigo', 'Indigo', '#1e1b4b', '#6366f1'], ['emerald', 'Emerald', '#052e2b', '#10b981'], ['rose', 'Rose', '#4c0519', '#f43f5e'], ['amber', 'Amber', '#3b2506', '#f59e0b'], ['violet', 'Violet', '#2e1065', '#8b5cf6'], ['teal', 'Teal', '#042f2e', '#14b8a6'], ['graphite', 'Graphite', '#18181b', '#f97316']];

export default function Settings() {
  const { ui, setUi, patchUser, user, isAdmin, theme, setTheme, accent, setAccent, resetDemo, importData, data, setAppSettings, notify } = useApp();
  const [reset, setReset] = useState(false);
  const [name, setName] = useState(data.appSettings.appName);
  const [ap, setAp] = useState({ tagline: data.appSettings.tagline || '', supportEmail: data.appSettings.supportEmail || '', taxRate: data.appSettings.taxRate ?? 5, serviceFee: data.appSettings.serviceFee ?? 2 });
  const file = useRef(null);

  const onImport = async (e) => {
    const f = e.target.files?.[0]; e.target.value = '';
    if (!f) return;
    try {
      const r = importData(JSON.parse(await f.text()));
      notify(r.ok ? 'Backup restored' : r.error);
    } catch { notify('Could not read that file.'); }
  };

  return (
    <>
      <PageHead title={isAdmin ? 'Application settings' : 'Settings'} sub="Appearance, data and preferences." />
      <div className="set-grid">
        <section className="card"><h3>Appearance</h3>
          <p className="muted" style={{ marginBottom: 14 }}>Choose light or dark. In dark mode the whole app takes its colours from the sidebar colour you pick below.</p>
          <div className="themes">{MODES.map(([k, label, Icon]) => <button key={k} className={theme === k ? 'on' : ''} onClick={() => setTheme(k)}><Icon size={22} />{label}</button>)}</div>
          <h4 style={{ margin: '20px 0 10px' }}>Sidebar colour</h4>
          <div className="accents">{ACCENTS.map(([k, label, sb, ac]) => (
            <button key={k} className={accent === k ? 'on' : ''} onClick={() => setAccent(k)} aria-label={`${label} colour`}>
              <span className="swatch" style={{ background: `linear-gradient(90deg, ${sb} 55%, ${ac} 55%)` }} />{label}
            </button>))}</div>
        </section>

        {isAdmin && (
          <section className="card"><h3>Application</h3>
            <div className="set-row"><span>Application name</span>
              <span style={{ display: 'flex', gap: 8 }}><input className="inline-input" value={name} onChange={(e) => setName(e.target.value)} maxLength={24} />
                <button className="btn sm" disabled={!name.trim() || name.trim() === data.appSettings.appName} onClick={() => { setAppSettings({ appName: name.trim() }); notify('Name updated'); }}>Save</button></span></div>
            <div className="set-row"><span>Allow new sign-ups<br /><small className="muted">Shows “Create account” on the login page.</small></span>
              <label className="switch"><input type="checkbox" checked={data.appSettings.allowRegistration} onChange={(e) => { setAppSettings({ allowRegistration: e.target.checked }); notify(e.target.checked ? 'Sign-ups enabled' : 'Sign-ups disabled'); }} /><i /></label></div>
          </section>
        )}

        <section className="card"><h3>Display</h3>
          <div className="set-row"><span>Density<br /><small className="muted">Spacing of cards, tables and buttons.</small></span>
            <span className="seg">{['comfortable', 'compact'].map((d) => <button key={d} className={ui.density === d ? 'on' : ''} onClick={() => setUi({ ...ui, density: d })}>{d}</button>)}</span></div>
          <div className="set-row"><span>Text size</span>
            <span className="seg">{[['sm', 'Small'], ['md', 'Medium'], ['lg', 'Large']].map(([k, l]) => <button key={k} className={ui.font === k ? 'on' : ''} onClick={() => setUi({ ...ui, font: k })}>{l}</button>)}</span></div>
          <div className="set-row"><span>Photo banners<br /><small className="muted">Show the hero image on each page.</small></span>
            <label className="switch"><input type="checkbox" checked={ui.banners} onChange={(e) => setUi({ ...ui, banners: e.target.checked })} /><i /></label></div>
          {!isAdmin && <div className="set-row"><span>Default currency<br /><small className="muted">Used for new trips.</small></span>
            <select className="inline-input" value={user.currency} onChange={(e) => { patchUser({ currency: e.target.value }); notify('Currency updated'); }}>{['INR', 'USD', 'EUR', 'GBP', 'AED'].map((c) => <option key={c}>{c}</option>)}</select></div>}
        </section>

        {isAdmin && (
          <section className="card"><h3>Billing & branding</h3>
            <div className="set-row"><span>Tagline</span><input className="inline-input" value={ap.tagline} onChange={(e) => setAp({ ...ap, tagline: e.target.value })} /></div>
            <div className="set-row"><span>Support email</span><input className="inline-input" value={ap.supportEmail} onChange={(e) => setAp({ ...ap, supportEmail: e.target.value })} /></div>
            <div className="set-row"><span>GST / tax %</span><input className="inline-input" type="number" min="0" max="40" value={ap.taxRate} onChange={(e) => setAp({ ...ap, taxRate: e.target.value })} /></div>
            <div className="set-row"><span>Service fee %</span><input className="inline-input" type="number" min="0" max="20" value={ap.serviceFee} onChange={(e) => setAp({ ...ap, serviceFee: e.target.value })} /></div>
            <div className="actions"><button className="btn primary sm" onClick={() => { setAppSettings({ ...ap, taxRate: Number(ap.taxRate) || 0, serviceFee: Number(ap.serviceFee) || 0 }); notify('Saved — bills and branding updated'); }}>Save changes</button></div>
          </section>
        )}

        <section className="card"><h3>Account</h3>
          <div className="set-row"><span>Name</span><b>{user.name}</b></div>
          <div className="set-row"><span>Email</span><b>{user.email}</b></div>
          <div className="set-row"><span>Role</span><b style={{ textTransform: 'capitalize' }}>{user.role}</b></div>
          <p className="muted" style={{ marginTop: 10 }}>Edit your name, email, currency and password on the profile page.</p>
        </section>

        <section className="card"><h3>Your data</h3>
          <p className="muted">{data.trips.length} trips · {data.destinations.length} destinations stored in this browser.</p>
          <div className="actions">
            <button className="btn" onClick={() => { downloadJson('wanderly-backup.json', data); notify('Backup downloaded'); }}><Download size={15} /> Export backup</button>
            <button className="btn" onClick={() => file.current?.click()}><Upload size={15} /> Import backup</button>
            <input ref={file} type="file" accept="application/json" hidden onChange={onImport} />
            <button className="btn danger" onClick={() => setReset(true)}><RotateCcw size={15} /> Reset data</button>
          </div>
        </section>
      </div>
      {reset && <Confirm title="Reset all data?" text="Everything returns to the original sample data. This cannot be undone." confirmLabel="Reset" onClose={() => setReset(false)} onConfirm={() => { resetDemo(); notify('Data reset'); }} />}
    </>
  );
}
