import { useState } from 'react';
import { Calendar, MapPin, Plus, Search, Tags, Trash2, UserPlus, Users, ListChecks, BarChart3, Wallet } from 'lucide-react';
import { useApp } from '../context/AppContext.jsx';
import { Confirm, DataTable, Empty, Field, IconActions, ImagePicker, Modal, PageHead } from '../components/ui.jsx';
import { onImgError, photo, scene, SCENE_NAMES } from '../assets/scenes.js';
import { useUrlQuery } from '../utils/useUrlQuery.js';
import { cap, fmtDate, fmtMoney, initials, isEmail, tripStatus } from '../utils/helpers.js';

const Status = ({ s }) => <span className={`status ${s === 'active' ? 'ongoing' : 'cancelled'}`}>{s}</span>;
const SearchBox = ({ q, setQ, ph }) => <div className="filters"><div className="search-box"><Search size={16} /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder={ph} /></div></div>;
const run = (r, notify, ok) => { notify(r.ok ? ok : r.error); return r.ok; };

/* ---------------- Users ---------------- */
export function AdminUsers() {
  const { data, user, saveUser, deleteUser, notify } = useApp();
  const [q, setQ] = useUrlQuery();
  const [role, setRole] = useState('all');
  const [modal, setModal] = useState(null);
  const [del, setDel] = useState(null);
  const [f, setF] = useState({});
  const [err, setErr] = useState({});
  const s = q.trim().toLowerCase();
  const rows = data.users.filter((u) => (role === 'all' || u.role === role) && (!s || (u.name + u.email + u.username).toLowerCase().includes(s)));
  const set = (k, v) => setF((p) => ({ ...p, [k]: v }));
  const open = (u) => { setErr({}); setF(u ? { ...u, password: '' } : { name: '', username: '', email: '', password: '', role: 'user', status: 'active', style: 'Balanced' }); setModal(u ? 'edit' : 'new'); };
  const submit = () => {
    const x = {};
    if (f.name.trim().length < 2) x.name = 'Enter a name.';
    if (!/^[a-z0-9._]{3,}$/i.test(f.username.trim())) x.username = 'At least 3 letters, numbers, dots or underscores.';
    if (!isEmail(f.email.trim())) x.email = 'Enter a valid email.';
    if (modal === 'new' && f.password.length < 6) x.password = 'Use at least 6 characters.';
    if (modal === 'edit' && f.password && f.password.length < 6) x.password = 'Use at least 6 characters, or leave blank.';
    setErr(x);
    if (Object.keys(x).length) return;
    const r = saveUser({ ...f, name: f.name.trim(), username: f.username.trim(), password: f.password || undefined });
    if (!r.ok) return setErr({ email: r.error });
    notify(modal === 'edit' ? 'User updated' : 'User added');
    setModal(null);
  };
  const toggle = (u) => run(saveUser({ ...u, password: undefined, status: u.status === 'active' ? 'inactive' : 'active' }), notify, u.status === 'active' ? 'User deactivated' : 'User activated');

  return (
    <>
      <PageHead title="User management" sub="All registered accounts."><button className="btn primary" onClick={() => open()}><UserPlus size={16} /> Add user</button></PageHead>
      <div className="filters">
        <div className="search-box"><Search size={16} /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name, email or username" /></div>
        <select value={role} onChange={(e) => setRole(e.target.value)} aria-label="Role"><option value="all">All roles</option><option value="user">Travellers</option><option value="admin">Admins</option></select>
      </div>
      <DataTable rows={rows} empty={<Empty icon={Users} title="No users found" text="Try a different search." />}
        cols={[
          { h: 'Name', r: (r) => <span><b>{r.name}</b><br /><small className="muted">@{r.username}</small></span> }, { h: 'Email', r: (r) => r.email },
          { h: 'Role', r: (r) => cap(r.role) }, { h: 'Travel style', r: (r) => r.style },
          { h: 'Trips', r: (r) => data.trips.filter((t) => t.userId === r.id).length }, { h: 'Status', r: (r) => <Status s={r.status} /> },
          { h: '', r: (r) => (
            <span className="row-actions">
              {r.id !== user.id && <button className="btn sm" onClick={() => toggle(r)}>{r.status === 'active' ? 'Deactivate' : 'Activate'}</button>}
              <IconActions label={r.name} onEdit={() => open(r)} onDelete={r.id !== user.id ? () => setDel(r) : undefined} />
            </span>) },
        ]} />
      {modal && (
        <Modal title={modal === 'edit' ? 'Edit user' : 'Add user'} onClose={() => setModal(null)} onSubmit={submit} submitLabel={modal === 'edit' ? 'Save changes' : 'Add user'}>
          <Field label="Full name *" error={err.name}><input value={f.name} onChange={(e) => set('name', e.target.value)} /></Field>
          <div className="row2">
            <Field label="Username *" error={err.username}><input value={f.username} onChange={(e) => set('username', e.target.value)} /></Field>
            <Field label="Email *" error={err.email}><input type="email" value={f.email} onChange={(e) => set('email', e.target.value)} /></Field>
          </div>
          <Field label={modal === 'edit' ? 'New password (leave blank to keep)' : 'Password *'} error={err.password}><input type="password" autoComplete="new-password" value={f.password} onChange={(e) => set('password', e.target.value)} /></Field>
          <div className="row2">
            <Field label="Role"><select value={f.role} disabled={f.id === user.id} onChange={(e) => set('role', e.target.value)}><option value="user">Traveller</option><option value="admin">Admin</option></select></Field>
            <Field label="Status"><select value={f.status} disabled={f.id === user.id} onChange={(e) => set('status', e.target.value)}><option value="active">Active</option><option value="inactive">Inactive</option></select></Field>
          </div>
        </Modal>
      )}
      {del && <Confirm title="Delete user?" text={`${del.name} and all of their trips, bookings, expenses and notes will be permanently removed.`} onClose={() => setDel(null)} onConfirm={() => run(deleteUser(del.id), notify, 'User deleted')} />}
    </>
  );
}

/* ---------------- Destinations ---------------- */
const list = (s) => s.split(',').map((x) => x.trim()).filter(Boolean);
const FALLBACK_IMG = 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&w=1200&q=70';

export function AdminDestinations() {
  const { data, saveDestination, deleteDestination, notify } = useApp();
  const [q, setQ] = useUrlQuery();
  const [modal, setModal] = useState(null);
  const [del, setDel] = useState(null);
  const [f, setF] = useState({});
  const [err, setErr] = useState({});
  const s = q.trim().toLowerCase();
  const rows = data.destinations.filter((d) => !s || (d.name + d.country + d.city).toLowerCase().includes(s));
  const set = (k, v) => setF((p) => ({ ...p, [k]: v }));
  const open = (d) => {
    setErr({});
    setF(d ? { ...d, highlights: d.highlights.join(', '), attractions: d.attractions.join(', '), activities: d.activities.join(', '), tips: d.tips.join('\n') }
      : { name: '', city: '', region: '', country: '', categoryId: data.categories[0]?.id || '', status: 'active', currency: 'USD', dailyCost: '', costUSD: '', bestTime: '', image: '', description: '', highlights: '', attractions: '', activities: '', tips: '', notes: '' });
    setModal(d ? 'edit' : 'new');
  };
  const submit = () => {
    const x = {};
    ['name', 'city', 'country'].forEach((k) => { if (!f[k].trim()) x[k] = 'Required.'; });
    if (!f.categoryId) x.categoryId = 'Create a category first.';
    if (!(Number(f.dailyCost) > 0)) x.dailyCost = 'Enter a cost above 0.';
    if (!(Number(f.costUSD) > 0)) x.costUSD = 'Enter a cost above 0.';
    if (!f.bestTime.trim()) x.bestTime = 'Required.';
    if (f.description.trim().length < 20) x.description = 'Write at least 20 characters.';
    if (f.image.trim() && !/^https?:\/\//i.test(f.image.trim())) x.image = 'Use a full http(s) image link.';
    setErr(x);
    if (Object.keys(x).length) return;
    saveDestination({
      ...f, name: f.name.trim(), city: f.city.trim(), region: f.region.trim() || f.country.trim(), country: f.country.trim(),
      dailyCost: Number(f.dailyCost), costUSD: Number(f.costUSD), bestTime: f.bestTime.trim(), description: f.description.trim(), notes: f.notes.trim(),
      image: f.image.trim() || FALLBACK_IMG, highlights: list(f.highlights), attractions: list(f.attractions), activities: list(f.activities), tips: f.tips.split('\n').map((t) => t.trim()).filter(Boolean),
    });
    notify(modal === 'edit' ? 'Destination updated' : 'Destination added');
    setModal(null);
  };
  const toggle = (d) => { saveDestination({ ...d, status: d.status === 'active' ? 'inactive' : 'active' }); notify(d.status === 'active' ? 'Destination hidden from travellers' : 'Destination is live'); };

  return (
    <>
      <PageHead title="Destination management" sub="Destinations available to travellers."><button className="btn primary" onClick={() => open()}><Plus size={16} /> Add destination</button></PageHead>
      <SearchBox q={q} setQ={setQ} ph="Search destinations" />
      <DataTable rows={rows} empty={<Empty icon={MapPin} title="No destinations found" text="Try a different search or add one." />}
        cols={[
          { h: 'Destination', r: (r) => <span style={{ display: 'inline-flex', gap: 10, alignItems: 'center' }}><img className="thumb" src={r.image} alt="" onError={onImgError(r.id)} /><b>{r.name}</b></span> }, { h: 'Country', r: (r) => r.country },
          { h: 'Category', r: (r) => data.categories.find((c) => c.id === r.categoryId)?.name || '—' }, { h: 'Daily cost', r: (r) => fmtMoney(r.dailyCost, r.currency) },
          { h: 'Trips', r: (r) => data.trips.filter((t) => t.destinationIds.includes(r.id)).length }, { h: 'Status', r: (r) => <Status s={r.status} /> },
          { h: '', r: (r) => <span className="row-actions"><button className="btn sm" onClick={() => toggle(r)}>{r.status === 'active' ? 'Deactivate' : 'Activate'}</button><IconActions label={r.name} onEdit={() => open(r)} onDelete={() => setDel(r)} /></span> },
        ]} />
      {modal && (
        <Modal wide title={modal === 'edit' ? 'Edit destination' : 'Add destination'} onClose={() => setModal(null)} onSubmit={submit} submitLabel={modal === 'edit' ? 'Save changes' : 'Add destination'}>
          <div className="row2">
            <Field label="Name *" error={err.name}><input value={f.name} onChange={(e) => set('name', e.target.value)} /></Field>
            <Field label="Category *" error={err.categoryId}><select value={f.categoryId} onChange={(e) => set('categoryId', e.target.value)}>{data.categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></Field>
          </div>
          <div className="row3">
            <Field label="City *" error={err.city}><input value={f.city} onChange={(e) => set('city', e.target.value)} /></Field>
            <Field label="Region"><input value={f.region} onChange={(e) => set('region', e.target.value)} /></Field>
            <Field label="Country *" error={err.country}><input value={f.country} onChange={(e) => set('country', e.target.value)} /></Field>
          </div>
          <div className="row3">
            <Field label="Currency"><select value={f.currency} onChange={(e) => set('currency', e.target.value)}>{['INR', 'USD', 'EUR', 'JPY', 'CHF', 'GBP'].map((c) => <option key={c}>{c}</option>)}</select></Field>
            <Field label="Daily cost (local) *" error={err.dailyCost}><input type="number" min="0" value={f.dailyCost} onChange={(e) => set('dailyCost', e.target.value)} /></Field>
            <Field label="Daily cost in USD *" error={err.costUSD}><input type="number" min="0" value={f.costUSD} onChange={(e) => set('costUSD', e.target.value)} /></Field>
          </div>
          <Field label="Best time to visit *" error={err.bestTime}><input value={f.bestTime} onChange={(e) => set('bestTime', e.target.value)} placeholder="e.g. November – February" /></Field>
          <Field label="Image link" error={err.image}><input value={f.image} onChange={(e) => set('image', e.target.value)} placeholder="https://… (optional)" /></Field>
          <Field label="Description *" error={err.description}><textarea rows={3} value={f.description} onChange={(e) => set('description', e.target.value)} /></Field>
          <Field label="Highlights (comma separated)"><input value={f.highlights} onChange={(e) => set('highlights', e.target.value)} /></Field>
          <Field label="Attractions (comma separated)"><input value={f.attractions} onChange={(e) => set('attractions', e.target.value)} /></Field>
          <Field label="Activities (comma separated)"><input value={f.activities} onChange={(e) => set('activities', e.target.value)} /></Field>
          <Field label="Travel tips (one per line)"><textarea rows={3} value={f.tips} onChange={(e) => set('tips', e.target.value)} /></Field>
          <Field label="Good to know"><input value={f.notes} onChange={(e) => set('notes', e.target.value)} /></Field>
          <Field label="Status"><select value={f.status} onChange={(e) => set('status', e.target.value)}><option value="active">Active</option><option value="inactive">Inactive</option></select></Field>
        </Modal>
      )}
      {del && <Confirm title="Delete destination?" text={`"${del.name}" will be removed for everyone.`} onClose={() => setDel(null)} onConfirm={() => run(deleteDestination(del.id), notify, 'Destination deleted')} />}
    </>
  );
}

/* ---------------- Destination categories ---------------- */
const COLORS = ['#0e8a86', '#e9a23b', '#2b6f9e', '#d9483b', '#6b5ca5', '#18a06b', '#c77d3a', '#7a8c91'];
const pic = (key) => scene(SCENE_NAMES[[...key].reduce((h, ch) => h + ch.charCodeAt(0), 0) % SCENE_NAMES.length]);

function PicCard({ img, seed, title, sub, badge, color, onEdit, onDelete, label }) {
  return (
    <article className="cat-card">
      <div className="cat-img">
        <img src={img || pic(seed)} alt="" loading="lazy" onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = pic(seed); }} />
        {badge != null && <span className="cat-badge" style={color ? { background: color } : undefined}>{badge}</span>}
      </div>
      <div className="cat-body">
        <div><b>{title}</b><small>{sub}</small></div>
        <IconActions label={label} onEdit={onEdit} onDelete={onDelete} />
      </div>
    </article>
  );
}

export function AdminCategories() {
  const { data, saveCategory, deleteCategory, notify } = useApp();
  const [modal, setModal] = useState(null);
  const [del, setDel] = useState(null);
  const [f, setF] = useState({});
  const [err, setErr] = useState('');
  const open = (c) => { setErr(''); setF(c ? { ...c, image: c.image || '' } : { name: '', color: COLORS[0], image: '' }); setModal(c ? 'edit' : 'new'); };
  const submit = () => {
    if (!f.name.trim()) return setErr('Enter a category name.');
    const r = saveCategory(f);
    if (!r.ok) return setErr(r.error);
    notify(modal === 'edit' ? 'Category updated' : 'Category added');
    setModal(null);
  };
  return (
    <>
      <PageHead title="Destination categories" sub="How destinations are grouped."><button className="btn primary" onClick={() => open()}><Plus size={16} /> Add category</button></PageHead>
      {data.categories.length ? (
        <div className="cat-grid">
          {data.categories.map((c) => {
            const n = data.destinations.filter((d) => d.categoryId === c.id).length;
            return <PicCard key={c.id} img={c.image} seed={c.id} title={c.name} sub={`${n} destination${n === 1 ? '' : 's'}`} badge={c.name} color={c.color} label={c.name} onEdit={() => open(c)} onDelete={() => setDel(c)} />;
          })}
        </div>
      ) : <Empty icon={Tags} title="No categories" text="Add a category to group destinations." />}
      {modal && (
        <Modal title={modal === 'edit' ? 'Edit category' : 'Add category'} onClose={() => setModal(null)} onSubmit={submit} submitLabel={modal === 'edit' ? 'Save changes' : 'Add category'}>
          <Field label="Name *" error={err}><input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
          <ImagePicker value={f.image} onChange={(image) => setF({ ...f, image })} onError={setErr} fallback={pic(f.id || f.name || 'x')} />
          <div className="field"><span>Colour</span><div className="swatches">{COLORS.map((c) => <button type="button" key={c} className={f.color === c ? 'on' : ''} style={{ background: c }} onClick={() => setF({ ...f, color: c })} aria-label={`Colour ${c}`} />)}</div></div>
        </Modal>
      )}
      {del && <Confirm title="Delete category?" text={`"${del.name}" will be removed.`} onClose={() => setDel(null)} onConfirm={() => run(deleteCategory(del.id), notify, 'Category deleted')} />}
    </>
  );
}

/* ---------------- Activity categories ---------------- */
export function AdminActivities() {
  const { data, saveActivityCategory, deleteActivityCategory, notify } = useApp();
  const [modal, setModal] = useState(null); // { old }
  const [name, setName] = useState('');
  const [image, setImage] = useState('');
  const [err, setErr] = useState('');
  const [del, setDel] = useState(null);
  const imgs = data.activityImages || {};
  const open = (old) => { setErr(''); setName(old || ''); setImage(old ? imgs[old] || '' : ''); setModal({ old }); };
  const submit = () => {
    if (!name.trim()) return setErr('Enter a name.');
    const r = saveActivityCategory(modal.old, name, image);
    if (!r.ok) return setErr(r.error);
    notify(modal.old ? 'Category updated' : 'Category added');
    setModal(null);
  };
  return (
    <>
      <PageHead title="Activity categories" sub="Categories used when planning itineraries."><button className="btn primary" onClick={() => open()}><Plus size={16} /> Add category</button></PageHead>
      {data.activityCategories.length ? (
        <div className="cat-grid">
          {data.activityCategories.map((c) => {
            const n = data.itinerary.filter((i) => i.category === c).length;
            return <PicCard key={c} img={imgs[c]} seed={c} title={c} sub={`${n} activit${n === 1 ? 'y' : 'ies'} planned`} label={c} onEdit={() => open(c)} onDelete={() => setDel(c)} />;
          })}
        </div>
      ) : <Empty icon={ListChecks} title="No activity categories" text="Add one so travellers can categorise activities." />}
      {modal && (
        <Modal title={modal.old ? 'Edit activity category' : 'Add activity category'} onClose={() => setModal(null)} onSubmit={submit} submitLabel={modal.old ? 'Save' : 'Add'}>
          <Field label="Name *" error={err}><input value={name} onChange={(e) => setName(e.target.value)} /></Field>
          <ImagePicker value={image} onChange={setImage} onError={setErr} fallback={pic(name || 'x')} />
        </Modal>
      )}
      {del && <Confirm title="Delete category?" text={`"${del}" will be removed.`} onClose={() => setDel(null)} onConfirm={() => run(deleteActivityCategory(del), notify, 'Category deleted')} />}
    </>
  );
}

/* ---------------- Trip overview ---------------- */
export function AdminTrips() {
  const { data, adminDeleteTrip, notify } = useApp();
  const [q, setQ] = useUrlQuery();
  const [st, setSt] = useState('all');
  const [del, setDel] = useState(null);
  const s = q.trim().toLowerCase();
  const destNames = (t) => t.destinationIds.map((i) => data.destinations.find((d) => d.id === i)?.name).filter(Boolean).join(', ');
  const spent = (id) => data.expenses.filter((e) => e.tripId === id).reduce((n, e) => n + e.actual, 0);
  const withStatus = data.trips.map((t) => ({ ...t, status: tripStatus(t), who: data.users.find((u) => u.id === t.userId)?.name || 'Unknown' }));
  const rows = withStatus.filter((t) => (st === 'all' || t.status === st) && (!s || (t.title + t.who + destNames(t)).toLowerCase().includes(s)));
  return (
    <>
      <PageHead title="Trip overview" sub="Every trip across all travellers." />
      <div className="filters">
        <div className="search-box"><Search size={16} /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by trip, traveller or destination" /></div>
        <select value={st} onChange={(e) => setSt(e.target.value)} aria-label="Status"><option value="all">All statuses</option>{['planning', 'upcoming', 'ongoing', 'completed', 'cancelled', 'archived'].map((x) => <option key={x} value={x}>{cap(x)}</option>)}</select>
      </div>
      {rows.length ? (
        <>
          <h3 className="sec-title">Trip cards</h3>
          <div className="grid">
            {rows.map((t) => (
              <article key={t.id} className={`tcard ${t.status === 'cancelled' || t.status === 'archived' ? 'dim' : ''}`}>
                <div className="tcard-img" style={{ backgroundImage: photo(t.image, t.id) }}><span className={`status ${t.status}`}>{t.status}</span></div>
                <div className="tcard-body">
                  <h3>{t.title}</h3>
                  <p className="loc">{destNames(t)}</p>
                  <ul className="meta">
                    <li><Users size={14} /> {t.who} · {t.travellers} traveller{t.travellers > 1 ? 's' : ''}</li>
                    <li><Calendar size={14} /> {fmtDate(t.departureDate, { day: 'numeric', month: 'short' })} – {fmtDate(t.returnDate)}</li>
                    <li><Wallet size={14} /> {fmtMoney(t.budget, t.currency)} · spent {fmtMoney(spent(t.id), t.currency)}</li>
                  </ul>
                  <div className="actions"><button className="btn sm danger" onClick={() => setDel(t)}><Trash2 size={14} /> Remove</button></div>
                </div>
              </article>
            ))}
          </div>
          <h3 className="sec-title">All trips</h3>
        </>
      ) : null}
      <DataTable rows={rows} empty={<Empty icon={BarChart3} title="No trips found" text="Try changing the filters." />}
        cols={[
          { h: 'Trip', r: (r) => <b>{r.title}</b> }, { h: 'Traveller', r: (r) => <span className="who-cell"><span className="avatar sm">{initials(r.who)}</span>{r.who}</span> },
          { h: 'Destinations', r: destNames },
          { h: 'Dates', r: (r) => `${fmtDate(r.departureDate)} – ${fmtDate(r.returnDate)}` }, { h: 'Travellers', r: (r) => r.travellers },
          { h: 'Budget', r: (r) => fmtMoney(r.budget, r.currency) }, { h: 'Spent', r: (r) => fmtMoney(spent(r.id), r.currency) },
          { h: 'Status', r: (r) => <span className={`status ${r.status}`}>{r.status}</span> },
          { h: '', r: (r) => <IconActions label={r.title} onDelete={() => setDel(r)} /> },
        ]} />
      {del && <Confirm title="Remove trip?" text={`"${del.title}" by ${del.who} and all of its plans will be permanently deleted.`} onClose={() => setDel(null)} onConfirm={() => run(adminDeleteTrip(del.id), notify, 'Trip removed')} />}
    </>
  );
}
