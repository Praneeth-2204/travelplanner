import { useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, BedDouble, Briefcase, Calendar, CalendarCheck, CalendarDays, Link2, Luggage, MapPin, NotebookPen, Pencil, Users, Wallet } from 'lucide-react';
import { useApp } from '../context/AppContext.jsx';
import TripFormModal from '../components/TripFormModal.jsx';
import { Empty } from '../components/ui.jsx';
import { photo } from '../assets/scenes.js';
import { BOOKING_LABEL, cap, daysBetween, fmtDate, fmtMoney, nightsBetween, tripStatus } from '../utils/helpers.js';

export default function TripDetails() {
  const { id } = useParams();
  const go = useNavigate();
  const { data, myTrips, saveTrip, notify } = useApp();
  const [edit, setEdit] = useState(false);
  const raw = myTrips.find((t) => t.id === id);

  const mine = (list) => list.filter((x) => x.tripId === id);
  const expenses = useMemo(() => mine(data.expenses).sort((a, b) => b.date.localeCompare(a.date)), [data.expenses, id]); // eslint-disable-line
  const bookings = useMemo(() => mine(data.bookings).sort((a, b) => a.date.localeCompare(b.date)), [data.bookings, id]); // eslint-disable-line
  const plan = useMemo(() => mine(data.itinerary).sort((a, b) => `${a.date}${a.start}`.localeCompare(`${b.date}${b.start}`)), [data.itinerary, id]); // eslint-disable-line
  const packing = mine(data.packing);
  const notes = data.notes.filter((n) => n.tripId === id);

  if (!raw) {
    return <Empty icon={Briefcase} title="Trip not found" text="This trip does not exist or is not yours."><Link className="btn primary" to="/trips"><ArrowLeft size={16} /> Back to My trips</Link></Empty>;
  }

  const t = raw;
  const status = tripStatus(t);
  const cur = t.currency;
  const spent = expenses.reduce((s, e) => s + Number(e.actual || 0), 0);
  const est = expenses.reduce((s, e) => s + Number(e.estimated || 0), 0);
  const left = t.budget - spent;
  const pct = t.budget ? Math.min(100, Math.round((spent / t.budget) * 100)) : 0;
  const over = spent > t.budget;
  const days = daysBetween(t.departureDate, t.returnDate) + 1;
  const packed = packing.filter((p) => p.packed).length;
  const dests = t.destinationIds.map((i) => data.destinations.find((d) => d.id === i)).filter(Boolean);
  const activeBookings = bookings.filter((b) => b.status !== 'cancelled');
  const byDay = plan.reduce((a, i) => ({ ...a, [i.date]: [...(a[i.date] || []), i] }), {});

  return (
    <>
      <div style={{ marginBottom: 12 }}><Link to="/trips" className="btn sm"><ArrowLeft size={14} /> All trips</Link></div>

      <div className="trip-hero" style={{ backgroundImage: photo(t.image, t.id) }}>
        <div>
          <span className={`status ${status}`}>{status}</span>
          <h2>{t.title}</h2>
          <p>{dests.map((d) => d.name).join(' · ')}</p>
          <div className="hero-meta">
            <span><Calendar size={15} /> {fmtDate(t.departureDate)} – {fmtDate(t.returnDate)} ({days} day{days > 1 ? 's' : ''})</span>
            <span><Users size={15} /> {t.travellers} traveller{t.travellers > 1 ? 's' : ''} · {cap(t.type)}</span>
            <span><Wallet size={15} /> Budget {fmtMoney(t.budget, cur)}</span>
          </div>
        </div>
      </div>

      <div className="actions" style={{ margin: '14px 0 0' }}>
        <button className="btn primary" onClick={() => setEdit(true)} disabled={status === 'archived'}><Pencil size={16} /> Edit trip</button>
        <button className="btn" onClick={() => go('/bookings')}><CalendarCheck size={16} /> Bookings</button>
        <button className="btn" onClick={() => go('/budget')}><Wallet size={16} /> Budget & expenses</button>
        <button className="btn" onClick={() => go('/itinerary')}><CalendarDays size={16} /> Itinerary</button>
      </div>

      <div className="stats">
        <div className="stat" style={{ display: 'block' }}><small>Budget</small><strong>{fmtMoney(t.budget, cur)}</strong><em>Estimated {fmtMoney(est, cur)}</em></div>
        <div className="stat" style={{ display: 'block' }}><small>Spent</small><strong>{fmtMoney(spent, cur)}</strong><em>{pct}% of budget used</em></div>
        <div className="stat" style={{ display: 'block' }}><small>{over ? 'Over budget by' : 'Left to spend'}</small><strong className={over ? 'bad' : ''}>{fmtMoney(Math.abs(left), cur)}</strong><em>{over ? 'Time to review expenses' : 'Still available'}</em></div>
        <div className="stat" style={{ display: 'block' }}><small>Bookings</small><strong>{activeBookings.length}</strong><em>{bookings.length - activeBookings.length} cancelled</em></div>
      </div>
      <div className="bar" style={{ marginTop: 14 }}><i className={over ? 'over' : ''} style={{ width: pct + '%' }} /></div>

      <section className="card dsec">
        <h3><MapPin size={17} /> About this trip</h3>
        <p>{t.description || 'No description added.'}</p>
        {t.preferences && <p className="muted" style={{ marginTop: 8 }}><b>Preferences:</b> {t.preferences}</p>}
        <div className="tags">{dests.map((d) => <span className="tag" key={d.id}>{d.name}, {d.country}</span>)}</div>
      </section>

      <div className="dgrid2 dsec">
        <section className="card">
          <div className="dsec-head"><h3><BedDouble size={17} /> Bookings & hotels</h3><Link className="btn sm" to="/bookings">Manage</Link></div>
          {bookings.length ? (
            <div className="dlist">{bookings.map((b) => {
              const n = b.checkIn ? nightsBetween(b.checkIn, b.checkOut) : 0;
              return (
                <div className="dline" key={b.id}>
                  <span><b>{b.title}</b>
                    <small>{BOOKING_LABEL[b.type] || cap(b.type)} · {b.type === 'accommodation' && b.checkIn ? `${fmtDate(b.checkIn, { day: 'numeric', month: 'short' })} → ${fmtDate(b.checkOut, { day: 'numeric', month: 'short' })} · ${n} night${n === 1 ? '' : 's'} · ${b.rooms} room${b.rooms > 1 ? 's' : ''}` : fmtDate(b.date)} · {b.status}</small></span>
                  <b style={b.status === 'cancelled' ? { textDecoration: 'line-through', opacity: 0.6 } : undefined}>{fmtMoney(b.cost, cur)}</b>
                </div>
              );
            })}</div>
          ) : <p className="muted">No bookings yet. Add flights and hotels from the Bookings page.</p>}
        </section>

        <section className="card">
          <div className="dsec-head"><h3><Wallet size={17} /> Budget & expenses</h3><Link className="btn sm" to="/budget">Manage</Link></div>
          {expenses.length ? (
            <div className="dlist">{expenses.map((e) => (
              <div className="dline" key={e.id}>
                <span><b>{e.description}</b><small>{cap(e.category)} · {fmtDate(e.date)}{e.bookingId && <> · <Link2 size={11} style={{ verticalAlign: -1 }} /> from booking</>}</small></span>
                <span style={{ textAlign: 'right' }}><b className={e.actual > e.estimated ? 'bad' : ''}>{fmtMoney(e.actual, cur)}</b><small>est. {fmtMoney(e.estimated, cur)}</small></span>
              </div>
            ))}</div>
          ) : <p className="muted">No expenses yet. Booking amounts appear here automatically.</p>}
        </section>
      </div>

      <div className="dgrid2 dsec">
        <section className="card">
          <div className="dsec-head"><h3><CalendarDays size={17} /> Itinerary</h3><Link className="btn sm" to="/itinerary">Manage</Link></div>
          {plan.length ? Object.entries(byDay).map(([date, list]) => (
            <div key={date}>
              <span className="day-pill">Day {list[0].day} · {fmtDate(date, { weekday: 'short', day: 'numeric', month: 'short' })}</span>
              <div className="dlist">{list.map((i) => (
                <div className="dline" key={i.id}><span><b>{i.title}</b><small>{i.start}–{i.end} · {i.category}{i.location ? ` · ${i.location}` : ''}</small></span><b>{fmtMoney(i.cost, cur)}</b></div>
              ))}</div>
            </div>
          )) : <p className="muted">Nothing planned yet.</p>}
        </section>

        <div style={{ display: 'grid', gap: 18, alignContent: 'start' }}>
          <section className="card">
            <div className="dsec-head"><h3><Luggage size={17} /> Packing list</h3><Link className="btn sm" to="/packing">Manage</Link></div>
            {packing.length ? (
              <>
                <div className="bar-label"><span>{packed} of {packing.length} packed</span><span>{Math.round((packed / packing.length) * 100)}%</span></div>
                <div className="bar"><i style={{ width: (packed / packing.length) * 100 + '%' }} /></div>
                <div className="tags">{packing.map((p) => <span key={p.id} className={`tag ${p.packed ? '' : 'alt'}`}>{p.name}{p.qty > 1 ? ` ×${p.qty}` : ''}</span>)}</div>
              </>
            ) : <p className="muted">No packing items yet.</p>}
          </section>
          <section className="card">
            <div className="dsec-head"><h3><NotebookPen size={17} /> Notes</h3><Link className="btn sm" to="/notes">Manage</Link></div>
            {notes.length ? <div className="dlist">{notes.map((n) => <div className="dline" key={n.id}><span><b>{n.title}</b><small>{n.body}</small></span></div>)}</div> : <p className="muted">No notes for this trip.</p>}
          </section>
        </div>
      </div>

      {edit && <TripFormModal trip={t} onClose={() => setEdit(false)} onSave={(x) => { saveTrip(x); setEdit(false); notify('Trip updated'); }} />}
    </>
  );
}
