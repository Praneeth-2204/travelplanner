import { useState } from 'react';
import { useApp } from '../context/AppContext.jsx';
import { Field, PageHead } from '../components/ui.jsx';
import { initials, isEmail, tripStatus } from '../utils/helpers.js';

const STYLES = ['Balanced', 'Adventure', 'Relaxed', 'Luxury', 'Budget', 'Cultural'];
const CURRENCIES = ['INR', 'USD', 'EUR', 'JPY', 'CHF', 'GBP'];

export default function Profile() {
  const { user, myTrips, data, updateProfile, changePassword, notify } = useApp();
  const [f, setF] = useState({ name: user.name, username: user.username, email: user.email, style: user.style, currency: user.currency });
  const [err, setErr] = useState({});
  const [pw, setPw] = useState({ old: '', next: '', again: '' });
  const [pwErr, setPwErr] = useState({});
  const set = (k, v) => setF((p) => ({ ...p, [k]: v }));
  const done = myTrips.filter((t) => tripStatus(t) === 'completed').length;

  const save = (e) => {
    e.preventDefault();
    const x = {};
    if (f.name.trim().length < 2) x.name = 'Enter your full name.';
    if (!/^[a-z0-9._]{3,}$/i.test(f.username.trim())) x.username = 'At least 3 letters, numbers, dots or underscores.';
    if (!isEmail(f.email.trim())) x.email = 'Enter a valid email.';
    setErr(x);
    if (Object.keys(x).length) return;
    const r = updateProfile(f);
    if (!r.ok) return setErr({ email: r.error });
    notify('Profile updated');
  };
  const savePw = (e) => {
    e.preventDefault();
    const x = {};
    if (!pw.old) x.old = 'Enter your current password.';
    if (pw.next.length < 6) x.next = 'Use at least 6 characters.';
    if (pw.again !== pw.next) x.again = 'Passwords do not match.';
    setPwErr(x);
    if (Object.keys(x).length) return;
    const r = changePassword(pw.old, pw.next);
    if (!r.ok) return setPwErr({ old: r.error });
    setPw({ old: '', next: '', again: '' });
    notify('Password changed');
  };

  const stats = user.role === 'admin'
    ? [['Users managed', data.users.length], ['Destinations', data.destinations.length], ['Trips on platform', data.trips.length]]
    : [['Trips', myTrips.length], ['Completed', done], ['Saved destinations', user.saved.length]];

  return (
    <>
      <PageHead title="My profile" sub="Manage your account details." />
      <div className="two-col">
        <div className="stack">
          <form className="card" onSubmit={save} noValidate>
            <div className="profile-top"><span className="avatar big">{initials(user.name)}</span><div><h3>{user.name}</h3><p className="muted" style={{ textTransform: 'capitalize' }}>{user.role}</p></div></div>
            <Field label="Full name" error={err.name}><input value={f.name} onChange={(e) => set('name', e.target.value)} /></Field>
            <div className="row2">
              <Field label="Username" error={err.username}><input value={f.username} onChange={(e) => set('username', e.target.value)} /></Field>
              <Field label="Email" error={err.email}><input type="email" value={f.email} onChange={(e) => set('email', e.target.value)} /></Field>
            </div>
            {user.role === 'user' && (
              <div className="row2">
                <Field label="Travel style"><select value={f.style} onChange={(e) => set('style', e.target.value)}>{STYLES.map((s) => <option key={s}>{s}</option>)}</select></Field>
                <Field label="Default currency"><select value={f.currency} onChange={(e) => set('currency', e.target.value)}>{CURRENCIES.map((c) => <option key={c}>{c}</option>)}</select></Field>
              </div>
            )}
            <button className="btn primary" type="submit">Save profile</button>
          </form>
          <form className="card" onSubmit={savePw} noValidate>
            <h3>Change password</h3>
            <Field label="Current password" error={pwErr.old}><input type="password" autoComplete="current-password" value={pw.old} onChange={(e) => setPw({ ...pw, old: e.target.value })} /></Field>
            <div className="row2">
              <Field label="New password" error={pwErr.next}><input type="password" autoComplete="new-password" value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} /></Field>
              <Field label="Confirm new password" error={pwErr.again}><input type="password" autoComplete="new-password" value={pw.again} onChange={(e) => setPw({ ...pw, again: e.target.value })} /></Field>
            </div>
            <button className="btn" type="submit">Update password</button>
          </form>
        </div>
        <aside className="stack">
          <section className="card"><h3>At a glance</h3>{stats.map(([k, v]) => <div key={k} className="set-row"><span>{k}</span><b>{v}</b></div>)}</section>
        </aside>
      </div>
    </>
  );
}
