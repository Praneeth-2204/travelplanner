import { BadgePercent, Clock, Copy, Receipt } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useApp } from '../context/AppContext.jsx';
import { Empty, PageHead } from '../components/ui.jsx';
import { fmtDate, daysBetween, today } from '../utils/helpers.js';

export const OfferCard = ({ o, onCopy }) => (
  <div className={`offer ${o.tone || 'ocean'}`}>
    <div className="offer-val">{o.type === 'percent' ? `${o.value}%` : `₹${o.value}`}<small>OFF</small></div>
    <div className="offer-body"><b>{o.title}</b><p>{o.desc}</p><small><Clock size={12} /> {o.expires ? `Valid till ${fmtDate(o.expires)} · ${Math.max(0, daysBetween(today(), o.expires))} days left` : 'No expiry'}</small></div>
    <button className="offer-code" onClick={() => onCopy(o.code)} title="Copy code"><span>{o.code}</span><Copy size={13} /></button>
  </div>
);

export default function Offers() {
  const { data, notify } = useApp();
  const live = data.offers.filter((o) => o.active && (!o.expires || o.expires >= today()));
  const copy = (c) => { navigator.clipboard?.writeText(c); notify(`Code ${c} copied`); };
  return (
    <>
      <PageHead title="Offers & deals" sub="Copy a code and apply it on your trip bill.">
        <Link className="btn primary" to="/bills"><Receipt size={15} /> Go to trip bill</Link>
      </PageHead>
      {live.length ? <div className="offers">{live.map((o) => <OfferCard key={o.id} o={o} onCopy={copy} />)}</div> : <Empty icon={BadgePercent} title="No offers right now" text="Check back soon for new deals." />}
    </>
  );
}
