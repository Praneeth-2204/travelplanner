import { useState } from 'react';
import { NotebookPen, Pin, PinOff, Plus, Search } from 'lucide-react';
import { useApp } from '../context/AppContext.jsx';
import { Confirm, Empty, Field, IconActions, Modal, PageHead, TripSelect } from '../components/ui.jsx';
import { fmtDate } from '../utils/helpers.js';

export default function Notes() {
  const { data, user, myTrips, saveItem, removeItem, notify } = useApp();
  const [tripId, setTripId] = useState('all');
  const [q, setQ] = useState('');
  const [modal, setModal] = useState(null);
  const [del, setDel] = useState(null);
  const [f, setF] = useState({});
  const [err, setErr] = useState({});

  const trip = (id) => myTrips.find((t) => t.id === id);
  const s = q.trim().toLowerCase();
  const rows = data.notes.filter((n) => n.userId === user.id && (tripId === 'all' || n.tripId === tripId) && (!s || (n.title + ' ' + n.body).toLowerCase().includes(s)))
    .sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.updatedAt.localeCompare(a.updatedAt));

  const open = (item) => { setErr({}); setF(item ? { ...item } : { tripId: tripId !== 'all' ? tripId : '', title: '', body: '', pinned: false }); setModal(item ? 'edit' : 'new'); };
  const set = (k, v) => setF((p) => ({ ...p, [k]: v }));
  const submit = () => {
    const x = {};
    if (!f.title.trim()) x.title = 'Give the note a title.';
    if (!f.body.trim()) x.body = 'Write something in the note.';
    setErr(x);
    if (Object.keys(x).length) return;
    saveItem('notes', { ...f, title: f.title.trim(), body: f.body.trim() }, `note "${f.title.trim()}"`);
    notify(modal === 'edit' ? 'Note updated' : 'Note saved');
    setModal(null);
  };
  const pin = (n) => saveItem('notes', { ...n, pinned: !n.pinned }, `note "${n.title}"`);

  return (
    <>
      <PageHead title="Travel notes" sub="Ideas, reminders and details for your trips.">
        <TripSelect trips={myTrips} value={tripId} onChange={setTripId} />
        <button className="btn primary" onClick={() => open()}><Plus size={16} /> New note</button>
      </PageHead>
      <div className="filters"><div className="search-box"><Search size={16} /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search notes" /></div></div>
      {rows.length ? (
        <div className="grid">
          {rows.map((n) => (
            <section key={n.id} className={`card note-card ${n.pinned ? 'pinned' : ''}`}>
              <div className="card-head"><h3>{n.title}</h3>
                <button className="icon-btn sm" onClick={() => pin(n)} aria-label={n.pinned ? 'Unpin note' : 'Pin note'} title={n.pinned ? 'Unpin' : 'Pin'}>{n.pinned ? <PinOff size={14} /> : <Pin size={14} />}</button></div>
              <p style={{ whiteSpace: 'pre-wrap' }}>{n.body}</p>
              <div className="note-foot"><small className="muted">{trip(n.tripId)?.title || 'General'} · {fmtDate(n.updatedAt)}</small><IconActions label={n.title} onEdit={() => open(n)} onDelete={() => setDel(n)} /></div>
            </section>
          ))}
        </div>
      ) : (
        <Empty icon={NotebookPen} title={s ? 'No matching notes' : 'No notes yet'} text={s ? 'Try a different search.' : 'Jot down visa details, restaurant tips or anything you want to remember.'}>
          {!s && <button className="btn primary" onClick={() => open()}><Plus size={16} /> New note</button>}
        </Empty>
      )}
      {modal && (
        <Modal title={modal === 'edit' ? 'Edit note' : 'New note'} onClose={() => setModal(null)} onSubmit={submit} submitLabel={modal === 'edit' ? 'Save changes' : 'Save note'}>
          <Field label="Title *" error={err.title}><input value={f.title} onChange={(e) => set('title', e.target.value)} /></Field>
          <Field label="Trip (optional)"><select value={f.tripId} onChange={(e) => set('tripId', e.target.value)}><option value="">General</option>{myTrips.map((t) => <option key={t.id} value={t.id}>{t.title}</option>)}</select></Field>
          <Field label="Note *" error={err.body}><textarea rows={6} value={f.body} onChange={(e) => set('body', e.target.value)} /></Field>
          <label className="check"><input type="checkbox" checked={!!f.pinned} onChange={(e) => set('pinned', e.target.checked)} /> Pin to top</label>
        </Modal>
      )}
      {del && <Confirm title="Delete note?" text={`"${del.title}" will be permanently removed.`} onClose={() => setDel(null)} onConfirm={() => { removeItem('notes', del.id, `note "${del.title}"`); notify('Note deleted'); }} />}
    </>
  );
}
