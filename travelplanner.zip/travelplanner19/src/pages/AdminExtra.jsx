import { useState } from 'react';
import { BadgePercent, Download, Plus, TrendingUp } from 'lucide-react';
import { useApp } from '../context/AppContext.jsx';
import { Confirm, DataTable, Empty, Field, IconActions, Modal, PageHead } from '../components/ui.jsx';
import StatCard from '../components/StatCard.jsx';
import { buildBill, downloadCsv, fmtDate, fmtMoney, today } from '../utils/helpers.js';

const blank = { code: '', title: '', desc: '', type: 'percent', value: 10, min: 0, max: 0, expires: '', active: true, tone: 'ocean' };

export function AdminOffers() {
  const { data, saveOffer, deleteOffer, notify } = useApp();
  const [f, setF] = useState(null); const [err, setErr] = useState({}); const [del, setDel] = useState(null);
  const set = (k, v) => setF((p) => ({ ...p, [k]: v }));
  const submit = () => {
    const x = {};
    if (f.code.trim().length < 4) x.code = 'At least 4 characters.';
    if (!f.title.trim()) x.title = 'Add a title.';
    if (!(Number(f.value) > 0) || (f.type === 'percent' && Number(f.value) > 90)) x.value = f.type === 'percent' ? 'Enter 1–90.' : 'Enter an amount.';
    setErr(x); if (Object.keys(x).length) return;
    const r = saveOffer({ ...f, value: Number(f.value), min: Number(f.min) || 0, max: Number(f.max) || 0 });
    if (!r.ok) return setErr({ code: r.error });
    notify(f.id ? 'Offer updated' : 'Offer created'); setF(null);
  };
  return (
    <>
      <PageHead title="Offers & coupons" sub="Create deals that travellers can apply on their trip bill."><button className="btn primary" onClick={() => { setErr({}); setF({ ...blank }); }}><Plus size={16} /> New offer</button></PageHead>
      <DataTable rows={data.offers} empty={<Empty icon={BadgePercent} title="No offers" text="Create your first coupon." />}
        cols={[
          { h: 'Code', r: (o) => <b>{o.code}</b> }, { h: 'Offer', r: (o) => <span><b>{o.title}</b><br /><small className="muted">{o.desc}</small></span> },
          { h: 'Discount', r: (o) => (o.type === 'percent' ? `${o.value}%` : `Flat ${o.value}`) }, { h: 'Min bill', r: (o) => o.min || '—' },
          { h: 'Expires', r: (o) => fmtDate(o.expires) },
          { h: 'Status', r: (o) => <label className="switch"><input type="checkbox" checked={o.active} onChange={(e) => saveOffer({ ...o, active: e.target.checked })} /><i /></label> },
          { h: '', r: (o) => <IconActions label={o.code} onEdit={() => { setErr({}); setF({ ...o }); }} onDelete={() => setDel(o)} /> },
        ]} />
      {f && (
        <Modal title={f.id ? 'Edit offer' : 'New offer'} onClose={() => setF(null)} onSubmit={submit}>
          <div className="row2"><Field label="Coupon code *" error={err.code}><input value={f.code} onChange={(e) => set('code', e.target.value.toUpperCase())} placeholder="SUMMER20" /></Field>
            <Field label="Title *" error={err.title}><input value={f.title} onChange={(e) => set('title', e.target.value)} /></Field></div>
          <Field label="Description"><input value={f.desc} onChange={(e) => set('desc', e.target.value)} /></Field>
          <div className="row3"><Field label="Type"><select value={f.type} onChange={(e) => set('type', e.target.value)}><option value="percent">Percent %</option><option value="flat">Flat amount</option></select></Field>
            <Field label="Value *" error={err.value}><input type="number" value={f.value} onChange={(e) => set('value', e.target.value)} /></Field>
            <Field label="Max discount"><input type="number" value={f.max} onChange={(e) => set('max', e.target.value)} /></Field></div>
          <div className="row3"><Field label="Min bill"><input type="number" value={f.min} onChange={(e) => set('min', e.target.value)} /></Field>
            <Field label="Expires"><input type="date" value={f.expires} onChange={(e) => set('expires', e.target.value)} /></Field>
            <Field label="Card colour"><select value={f.tone} onChange={(e) => set('tone', e.target.value)}>{['ocean', 'sunset', 'forest', 'plum'].map((t) => <option key={t}>{t}</option>)}</select></Field></div>
        </Modal>)}
      {del && <Confirm title="Delete offer?" text={`Coupon ${del.code} will stop working everywhere.`} onClose={() => setDel(null)} onConfirm={() => { deleteOffer(del.id); notify('Offer deleted'); }} />}
    </>
  );
}

export function AdminReports() {
  const { data } = useApp();
  const rows = data.trips.map((t) => { const b = buildBill(t, data, data.offers.find((o) => o.code === t.offerCode)); const u = data.users.find((x) => x.id === t.userId); return { id: t.id, trip: t.title, user: u?.name || '—', cur: t.currency, ...b }; });
  const byCur = {}; rows.forEach((r) => { byCur[r.cur] = (byCur[r.cur] || 0) + r.total; });
  const disc = rows.reduce((s, r) => s + (r.discount > 0 ? 1 : 0), 0);
  const csv = () => downloadCsv(`revenue-${today()}.csv`, [['Trip', 'Traveller', 'Currency', 'Subtotal', 'Fee', 'Discount', 'GST', 'Total'], ...rows.map((r) => [r.trip, r.user, r.cur, r.subtotal, r.fee, r.discount, r.tax, r.total])]);
  return (
    <>
      <PageHead title="Revenue reports" sub="Billing across every trip. Currencies are never mixed."><button className="btn" onClick={csv}><Download size={15} /> Export CSV</button></PageHead>
      <div className="stats">
        {Object.entries(byCur).map(([c, v]) => <StatCard key={c} icon={TrendingUp} label={`Billed (${c})`} value={fmtMoney(v, c)} tone="green" />)}
        <StatCard icon={BadgePercent} label="Bills using offers" value={disc} tone="amber" />
      </div>
      <div style={{ height: 18 }} />
      <DataTable rows={rows} empty={null} cols={[
        { h: 'Trip', r: (r) => <b>{r.trip}</b> }, { h: 'Traveller', r: (r) => r.user },
        { h: 'Subtotal', r: (r) => fmtMoney(r.subtotal, r.cur) }, { h: 'Discount', r: (r) => (r.discount ? `− ${fmtMoney(r.discount, r.cur)}` : '—') },
        { h: 'GST', r: (r) => fmtMoney(r.tax, r.cur) }, { h: 'Total', r: (r) => <b>{fmtMoney(r.total, r.cur)}</b> },
      ]} />
    </>
  );
}
