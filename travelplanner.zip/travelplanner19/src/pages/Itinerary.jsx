import { useMemo, useState } from 'react';
import { CalendarDays, MapPin, Plus } from 'lucide-react';
import { useApp } from '../context/AppContext.jsx';
import { Confirm, Empty, Field, IconActions, Modal, PageHead, TripSelect } from '../components/ui.jsx';
import { daysBetween, fmtDate, fmtMoney, tripStatus } from '../utils/helpers.js';

export default function Itinerary() {
  const { data, myTrips, saveItem, removeItem, notify } = useApp();
  const [tripId, setTripId] = useState('all');
  const [modal, setModal] = useState(null);
  const [del, setDel] = useState(null);
  const [f, setF] = useState({});
  const [err, setErr] = useState({});

  const planTrips = myTrips.filter((t) => !['cancelled', 'archived'].includes(tripStatus(t)));
  const trip = (id) => myTrips.find((t) => t.id === id);
  const ids = new Set(myTrips.map((t) => t.id));
  const rows = data.itinerary.filter((i) => ids.has(i.tripId) && (tripId === 'all' || i.tripId === tripId))
    .sort((a, b) => (a.date + a.start).localeCompare(b.date + b.start));
  const days = useMemo(() => {
    const m = new Map();
    rows.forEach((r) => { const k = r.tripId + r.date; m.set(k, [...(m.get(k) || []), r]); });
    return [...m.values()];
  }, [rows]); // eslint-disable-line

  const open = (item) => {
    const first = tripId !== 'all' ? trip(tripId) : planTrips[0];
    setErr({});
    setF(item ? { ...item } : { tripId: first?.id || '', title: '', date: first?.departureDate || '', start: '09:00', end: '11:00', category: data.activityCategories[0] || 'Sightseeing', location: '', cost: 0 });
    setModal(item ? 'edit' : 'new');
  };
  const set = (k, v) => setF((p) => ({ ...p, [k]: v }));

  const submit = () => {
    const t = trip(f.tripId); const x = {};
    if (!t) x.tripId = 'Choose a trip.';
    if (!f.title.trim()) x.title = 'Give the activity a name.';
    if (!f.date) x.date = 'Pick a date.';
    else if (t && (f.date < t.departureDate || f.date > t.returnDate)) x.date = `Must be within the trip (${fmtDate(t.departureDate)} – ${fmtDate(t.returnDate)}).`;
    if (!f.start || !f.end) x.end = 'Enter start and end times.';
    else if (f.end <= f.start) x.end = 'End time must be after the start time.';
    if (!(Number(f.cost) >= 0) || f.cost === '') x.cost = 'Enter 0 or more.';
    setErr(x);
    if (Object.keys(x).length) return;
    saveItem('itinerary', { ...f, title: f.title.trim(), location: f.location.trim(), cost: Number(f.cost), day: daysBetween(t.departureDate, f.date) + 1 }, `activity "${f.title.trim()}"`);
    notify(modal === 'edit' ? 'Activity updated' : 'Activity added');
    setModal(null);
  };

  return (
    <>
      <PageHead title="Itinerary planner" sub="Day-wise activities for your trips.">
        <TripSelect trips={myTrips} value={tripId} onChange={setTripId} />
        <button className="btn primary" onClick={() => open()} disabled={!planTrips.length}><Plus size={16} /> Add activity</button>
      </PageHead>

      {days.length ? (
        <div className="stack">
          {days.map((list) => {
            const t = trip(list[0].tripId);
            const total = list.reduce((s, a) => s + Number(a.cost || 0), 0);
            return (
              <section key={list[0].tripId + list[0].date} className="card">
                <div className="card-head">
                  <h3><CalendarDays size={17} /> Day {daysBetween(t.departureDate, list[0].date) + 1} · {fmtDate(list[0].date, { weekday: 'short', day: 'numeric', month: 'short' })}</h3>
                  <span className="muted">{t.title} · {fmtMoney(total, t.currency)}</span>
                </div>
                <ul className="timeline">
                  {list.map((a) => (
                    <li key={a.id}>
                      <time>{a.start}<small>{a.end}</small></time>
                      <div style={{ flex: 1 }}>
                        <b>{a.title} <span className="tag" style={{ marginLeft: 6, padding: '2px 9px', fontSize: 11.5 }}>{a.category}</span></b>
                        <small><MapPin size={11} style={{ verticalAlign: -1 }} /> {a.location || 'No location'} · {fmtMoney(a.cost, t.currency)}</small>
                      </div>
                      <IconActions label={a.title} onEdit={() => open(a)} onDelete={() => setDel(a)} />
                    </li>
                  ))}
                </ul>
              </section>
            );
          })}
        </div>
      ) : (
        <Empty icon={CalendarDays} title="No activities planned" text={planTrips.length ? 'Add the first activity to start building your day-wise plan.' : 'Create a trip first, then plan its days here.'}>
          {planTrips.length > 0 && <button className="btn primary" onClick={() => open()}><Plus size={16} /> Add activity</button>}
        </Empty>
      )}

      {modal && (
        <Modal title={modal === 'edit' ? 'Edit activity' : 'Add activity'} onClose={() => setModal(null)} onSubmit={submit} submitLabel={modal === 'edit' ? 'Save changes' : 'Add activity'}>
          <Field label="Trip *" error={err.tripId}>
            <select value={f.tripId} onChange={(e) => set('tripId', e.target.value)}>
              {(modal === 'edit' ? myTrips : planTrips).map((t) => <option key={t.id} value={t.id}>{t.title}</option>)}
            </select>
          </Field>
          <Field label="Activity *" error={err.title}><input value={f.title} onChange={(e) => set('title', e.target.value)} placeholder="e.g. Sunset cruise" /></Field>
          <div className="row2">
            <Field label="Date *" error={err.date}><input type="date" value={f.date} min={trip(f.tripId)?.departureDate} max={trip(f.tripId)?.returnDate} onChange={(e) => set('date', e.target.value)} /></Field>
            <Field label="Category"><select value={f.category} onChange={(e) => set('category', e.target.value)}>{data.activityCategories.map((c) => <option key={c}>{c}</option>)}</select></Field>
          </div>
          <div className="row2">
            <Field label="Start *"><input type="time" value={f.start} onChange={(e) => set('start', e.target.value)} /></Field>
            <Field label="End *" error={err.end}><input type="time" value={f.end} onChange={(e) => set('end', e.target.value)} /></Field>
          </div>
          <div className="row2">
            <Field label="Location"><input value={f.location} onChange={(e) => set('location', e.target.value)} placeholder="e.g. Baga Beach" /></Field>
            <Field label={`Cost (${trip(f.tripId)?.currency || ''})`} error={err.cost}><input type="number" min="0" value={f.cost} onChange={(e) => set('cost', e.target.value)} /></Field>
          </div>
        </Modal>
      )}
      {del && <Confirm title="Delete activity?" text={`"${del.title}" will be removed from your itinerary.`} onClose={() => setDel(null)} onConfirm={() => { removeItem('itinerary', del.id, `activity "${del.title}"`); notify('Activity deleted'); }} />}
    </>
  );
}
