import { useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Banknote, CalendarHeart, Camera, Heart, Lightbulb, MapPin, Sparkles, Star, StickyNote } from 'lucide-react';
import { useApp } from '../context/AppContext.jsx';
import { fmtMoney } from '../utils/helpers.js';
import { photo } from '../assets/scenes.js';

export default function DestinationDetails() {
  const { id } = useParams();
  const nav = useNavigate();
  const { data, user, toggleSaved, markViewed } = useApp();
  const d = data.destinations.find((x) => x.id === id && x.status === 'active');
  useEffect(() => { if (d) markViewed(d.id); }, [d?.id]); // eslint-disable-line

  if (!d) {
    return <div className="empty"><h2>Destination not found</h2><p>It may have been removed or deactivated.</p><Link className="btn" to="/explore">Back to explore</Link></div>;
  }
  const cat = data.categories.find((c) => c.id === d.categoryId);
  const saved = user.saved.includes(d.id);
  const planned = data.trips.filter((t) => t.destinationIds.includes(d.id)).length;

  return (
    <>
      <button className="link back" onClick={() => nav(-1)}><ArrowLeft size={15} /> Back</button>
      <section className="hero" style={{ backgroundImage: photo(d.image, d.id, 'linear-gradient(to top, rgba(8,20,40,.8), rgba(8,20,40,.05) 60%)') }}>
        <div>
          {cat && <span className="chip" style={{ background: cat.color }}>{cat.name}</span>}
          <h2>{d.name}</h2>
          <p><MapPin size={15} /> {d.city}, {d.region}, {d.country}</p>
        </div>
        <div className="hero-actions">
          <button className={`btn glass ${saved ? 'on' : ''}`} onClick={() => toggleSaved(d.id)}><Heart size={16} fill={saved ? 'currentColor' : 'none'} /> {saved ? 'Saved' : 'Save'}</button>
          <Link className="btn primary" to={`/trips?new=${d.id}`}><Sparkles size={16} /> Plan a trip here</Link>
        </div>
      </section>

      <div className="facts">
        <div><CalendarHeart size={18} /><small>Best time to visit</small><b>{d.bestTime}</b></div>
        <div><Banknote size={18} /><small>Estimated daily cost</small><b>{fmtMoney(d.dailyCost, d.currency)} <i>per person</i></b></div>
        <div><Star size={18} /><small>Currency</small><b>{d.currency}</b></div>
        <div><Camera size={18} /><small>Planned by travellers</small><b>{planned} trip{planned !== 1 && 's'}</b></div>
      </div>

      <div className="two-col">
        <div className="stack">
          <section className="card"><h3>About {d.name}</h3><p>{d.description}</p>
            <div className="tags">{d.highlights.map((h) => <span key={h} className="tag">{h}</span>)}</div></section>
          <section className="card"><h3>Popular attractions</h3>
            <ol className="attr">{d.attractions.map((a, i) => <li key={a}><span>{i + 1}</span>{a}</li>)}</ol></section>
          <section className="card"><h3>Recommended activities</h3>
            <div className="tags">{d.activities.map((a) => <span key={a} className="tag alt">{a}</span>)}</div></section>
        </div>
        <aside className="stack">
          <section className="card tip"><h3><Lightbulb size={17} /> Travel tips</h3>
            <ul>{d.tips.map((t) => <li key={t}>{t}</li>)}</ul></section>
          <section className="card"><h3><StickyNote size={17} /> Good to know</h3><p>{d.notes}</p></section>
          <Link className="btn primary block" to={`/trips?new=${d.id}`}>Start planning</Link>
        </aside>
      </div>
    </>
  );
}
