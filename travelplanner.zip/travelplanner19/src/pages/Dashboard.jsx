import { Link } from 'react-router-dom';
import { Activity, ArrowRight, Briefcase, Circle, ListChecks, Zap, CalendarClock, CheckCircle2, Compass, Luggage, MapPin, Plane, Tags, Users, UserCheck, UserX, Wallet } from 'lucide-react';
import { useApp } from '../context/AppContext.jsx';
import StatCard from '../components/StatCard.jsx';
import { onImgError, photo } from '../assets/scenes.js';
import { OfferCard } from './Offers.jsx';
import { buildBill, daysBetween, fmtDate, fmtMoney, greeting, today, tripStatus } from '../utils/helpers.js';

const COLORS = ['#0e8a86', '#e9a23b', '#2b6f9e', '#6b5ca5', '#d9483b', '#18a06b'];
const STATUSES = ['planning', 'upcoming', 'ongoing', 'completed', 'cancelled', 'archived'];

function AdminDashboard() {
  const { data } = useApp();
  const users = data.users.filter((u) => u.role === 'user');
  const byStatus = STATUSES.map((s) => ({ s, n: data.trips.filter((t) => tripStatus(t) === s).length }));
  const popular = [...data.destinations].sort((a, b) => b.popularity - a.popularity).slice(0, 5);
  const max = popular[0]?.popularity || 1;
  return (
    <>
      <div className="stats">
        <StatCard icon={Users} label="Registered users" value={users.length} tone="blue" />
        <StatCard icon={UserCheck} label="Active users" value={users.filter((u) => u.status === 'active').length} tone="green" />
        <StatCard icon={UserX} label="Inactive users" value={users.filter((u) => u.status !== 'active').length} tone="red" />
        <StatCard icon={MapPin} label="Destinations" value={data.destinations.length} hint={`${data.categories.length} categories`} tone="amber" />
        <StatCard icon={Briefcase} label="Total trips" value={data.trips.length} tone="purple" />
      </div>
      <section className="card"><div className="card-head"><h3><MapPin size={17} /> Popular destinations</h3><Link to="/admin/destinations" className="link">Manage <ArrowRight size={13} /></Link></div>
        <div className="picks">{popular.map((d) => <Link key={d.id} to="/admin/destinations" className="pick" style={{ backgroundImage: photo(d.image, d.id, 'linear-gradient(to top, rgba(6,30,48,.8), transparent 60%)') }}><b>{d.name}</b><small>{d.country}</small></Link>)}</div>
      </section>
      <div className="two-col">
        <section className="card"><h3>Trip status overview</h3>
          {byStatus.map(({ s, n }) => <div key={s} className="row-bar"><span className={`status ${s}`}>{s}</span><div className="bar"><i style={{ width: (n / Math.max(1, data.trips.length)) * 100 + '%' }} /></div><b>{n}</b></div>)}
        </section>
        <section className="card"><h3>Popular destinations</h3>
          {popular.map((d) => <div key={d.id} className="row-bar"><span>{d.name}</span><div className="bar"><i style={{ width: (d.popularity / max) * 100 + '%' }} /></div><b>{d.popularity}</b></div>)}
        </section>
      </div>
      <div className="two-col">
        <section className="card"><h3>Revenue by trip</h3>
          {data.trips.slice(0, 6).map((t) => { const b = buildBill(t, data, data.offers.find((o) => o.code === t.offerCode)); return <div key={t.id} className="row-bar"><span>{t.title}</span><div className="bar"><i style={{ width: Math.min(100, (b.total / Math.max(1, ...data.trips.map((x) => buildBill(x, data).total))) * 100) + '%' }} /></div><b>{fmtMoney(b.total, t.currency)}</b></div>; })}
        </section>
        <section className="card"><h3>Live offers</h3>
          {data.offers.filter((o) => o.active).slice(0, 4).map((o) => <div key={o.id} className="offer-mini"><div><b>{o.code}</b><small>{o.desc}</small></div></div>)}
          <Link to="/admin/offers" className="link" style={{ marginTop: 8 }}>Manage offers <ArrowRight size={13} /></Link>
        </section>
      </div>
      <section className="card"><h3>Recent application activity</h3>
        <ul className="feed">{data.activity.slice(0, 6).map((a) => <li key={a.id}><Activity size={14} /> {a.text}<small>{fmtDate(a.time)}</small></li>)}</ul>
      </section>
    </>
  );
}

export default function Dashboard() {
  const { user, data, myTrips, notify } = useApp();
  if (user.role === 'admin') return <><Hello name={user.name} sub="Here's how the platform is doing." /><AdminDashboard /></>;

  const trips = myTrips.map((t) => ({ ...t, status: tripStatus(t) }));
  const count = (s) => trips.filter((t) => t.status === s).length;
  const next = trips.filter((t) => t.status === 'upcoming' || t.status === 'planning').sort((a, b) => a.departureDate.localeCompare(b.departureDate))[0];
  const live = trips.filter((t) => t.status === 'ongoing');
  const ids = new Set(trips.map((t) => t.id));
  const acts = data.itinerary.filter((i) => ids.has(i.tripId) && i.date >= today()).sort((a, b) => (a.date + a.start).localeCompare(b.date + b.start)).slice(0, 5);
  const packing = data.packing.filter((p) => ids.has(p.tripId));
  const packed = packing.filter((p) => p.packed).length;
  const pct = packing.length ? Math.round((packed / packing.length) * 100) : 0;
  const budgetTrips = trips.filter((t) => ['planning', 'upcoming', 'ongoing'].includes(t.status));
  const spent = (id) => data.expenses.filter((e) => e.tripId === id).reduce((s, e) => s + e.actual, 0);
  const est = (id) => data.expenses.filter((e) => e.tripId === id).reduce((s, e) => s + e.estimated, 0);
  const dest = (id) => data.destinations.find((d) => d.id === id);
  const recent = user.recent.map(dest).filter(Boolean);
  const saved = user.saved.map(dest).filter(Boolean);
  const myActs = data.activity.filter((a) => a.userId === user.id).slice(0, 5);
  const trending = data.destinations.filter((d) => d.status === 'active').sort((a, b) => b.popularity - a.popularity).slice(0, 4);
  const catTotals = {}; data.expenses.filter((e) => ids.has(e.tripId)).forEach((e) => { catTotals[e.category] = (catTotals[e.category] || 0) + (e.actual || 0); });
  const catSum = Object.values(catTotals).reduce((a, b) => a + b, 0);
  let acc = 0; const spendCats = Object.entries(catTotals).filter(([, v]) => v > 0).map(([k, v]) => { const pct = Math.round((v / catSum) * 100); const from = acc; acc += (v / catSum) * 100; return { k, pct, from: Math.round(from), to: Math.round(acc) }; });
  const tripName = (id) => trips.find((t) => t.id === id)?.title;

  // "Trip readiness": what is still left to do before the next (or current) trip
  const focus = next || live[0];
  const ready = focus ? (() => {
    const its = data.itinerary.filter((i) => i.tripId === focus.id);
    const bks = data.bookings.filter((b) => b.tripId === focus.id && b.status !== 'cancelled');
    const pk = data.packing.filter((p) => p.tripId === focus.id);
    const hasExp = data.expenses.some((e) => e.tripId === focus.id);
    const over = spent(focus.id) > focus.budget || est(focus.id) > focus.budget;
    return [
      { k: 'Itinerary planned', sub: its.length ? `${its.length} activit${its.length > 1 ? 'ies' : 'y'} scheduled` : 'Nothing scheduled yet', ok: its.length > 0, to: '/itinerary' },
      { k: 'Bookings confirmed', sub: bks.length ? `${bks.filter((b) => b.status === 'confirmed').length} of ${bks.length} confirmed` : 'No bookings yet', ok: bks.length > 0 && bks.every((b) => b.status === 'confirmed'), to: '/bookings' },
      { k: 'Packing done', sub: pk.length ? `${pk.filter((p) => p.packed).length} of ${pk.length} packed` : 'No packing list yet', ok: pk.length > 0 && pk.every((p) => p.packed), to: '/packing' },
      { k: 'Budget on track', sub: over ? 'Over the planned budget' : hasExp ? 'Within your plan' : 'No expenses planned yet', ok: hasExp && !over, to: '/budget' },
    ];
  })() : null;
  const readyPct = ready ? Math.round((ready.filter((r) => r.ok).length / ready.length) * 100) : 0;

  return (
    <>
      <Hello name={user.name.split(' ')[0]} sub={live.length ? `You're currently on "${live[0].title}". Enjoy!` : 'Ready to plan your next adventure?'} />

      {next ? (
        <section className="next" style={{ backgroundImage: photo(next.image, next.id, 'linear-gradient(100deg, rgba(8,20,40,.85), rgba(8,20,40,.25))') }}>
          <div>
            <small><Plane size={14} /> Next trip</small>
            <h2>{next.title}</h2>
            <p>{fmtDate(next.departureDate)} – {fmtDate(next.returnDate)} · {next.travellers} traveller{next.travellers > 1 && 's'}</p>
          </div>
          <div className="countdown"><strong>{daysBetween(today(), next.departureDate)}</strong><span>days to go</span></div>
        </section>
      ) : (
        <section className="next empty-next"><div><h2>No upcoming trips</h2><p>Pick a destination and create your first plan.</p></div><Link className="btn primary" to="/explore"><Compass size={16} /> Explore</Link></section>
      )}

      <section className="card"><div className="card-head"><h3><Compass size={17} /> Trending destinations</h3><Link to="/explore" className="link">See all <ArrowRight size={13} /></Link></div>
        <div className="picks">{trending.map((d) => <Link key={d.id} to={`/explore/${d.id}`} className="pick" style={{ backgroundImage: photo(d.image, d.id, 'linear-gradient(to top, rgba(6,30,48,.8), transparent 60%)') }}><b>{d.name}</b><small>{d.country}</small></Link>)}</div>
      </section>
      <div style={{ height: 18 }} />
      <div className="stats">
        <StatCard icon={Briefcase} label="Total trips" value={trips.length} tone="blue" />
        <StatCard icon={CalendarClock} label="Upcoming" value={count('upcoming')} tone="amber" />
        <StatCard icon={Plane} label="Ongoing" value={count('ongoing')} tone="green" />
        <StatCard icon={CheckCircle2} label="Completed" value={count('completed')} tone="purple" />
      </div>

      <section className="card"><div className="card-head"><h3><Zap size={17} /> Offers for you</h3><Link to="/offers" className="link">All offers <ArrowRight size={13} /></Link></div>
        <div className="offers">{data.offers.filter((o) => o.active && o.expires >= today()).slice(0, 2).map((o) => <OfferCard key={o.id} o={o} onCopy={(c) => { navigator.clipboard?.writeText(c); notify(`Code ${c} copied`); }} />)}</div>
      </section>
      <div style={{ height: 18 }} />
      <div className="two-col">
        <div className="stack">
          <section className="card"><h3><Wallet size={17} /> Spending by category</h3>
            {spendCats.length ? <div className="donut-wrap"><div className="donut" style={{ background: `conic-gradient(${spendCats.map((c, i) => `${COLORS[i % 6]} ${c.from}% ${c.to}%`).join(',')})` }}><span>{spendCats.length}<small>types</small></span></div>
              <ul className="legend">{spendCats.map((c, i) => <li key={c.k}><i style={{ background: COLORS[i % 6] }} />{c.k}<b>{c.pct}%</b></li>)}</ul></div> : <p className="muted">No spending recorded yet.</p>}
          </section>
          <section className="card"><div className="card-head"><h3><Wallet size={17} /> Budget & spending</h3><Link to="/budget" className="link">Details <ArrowRight size={13} /></Link></div>
            {budgetTrips.length ? budgetTrips.map((t) => {
              const s = spent(t.id); const p = t.budget ? Math.min(100, Math.round((s / t.budget) * 100)) : 0; const over = s > t.budget || est(t.id) > t.budget;
              return (
                <div key={t.id} className="budget-row">
                  <div className="bar-label"><b>{t.title}</b><span>{fmtMoney(s, t.currency)} / {fmtMoney(t.budget, t.currency)}</span></div>
                  <div className="bar"><i className={over ? 'over' : ''} style={{ width: p + '%' }} /></div>
                  <small className={over ? 'err' : 'muted'}>{over ? 'Budget warning — estimated or actual spend exceeds plan' : `${p}% used · ${fmtMoney(t.budget - s, t.currency)} remaining`}</small>
                </div>
              );
            }) : <p className="muted">No active trips to track.</p>}
            <p className="note">Each trip is shown in its own currency — amounts are never mixed.</p>
          </section>
          <section className="card"><div className="card-head"><h3><CalendarClock size={17} /> Upcoming activities</h3><Link to="/itinerary" className="link">Planner <ArrowRight size={13} /></Link></div>
            {acts.length ? <ul className="timeline">{acts.map((a) => (
              <li key={a.id}><time>{fmtDate(a.date, { day: 'numeric', month: 'short' })}<small>{a.start}</small></time><div><b>{a.title}</b><small>{tripName(a.tripId)} · {a.location}</small></div></li>
            ))}</ul> : <p className="muted">No activities scheduled yet.</p>}
          </section>
        </div>

        <aside className="stack">
          <section className="card"><div className="card-head"><h3><ListChecks size={17} /> Trip readiness</h3>{ready && <b>{readyPct}%</b>}</div>
            {ready ? (
              <>
                <p className="muted ready-trip">{focus.title}</p>
                <div className="bar"><i style={{ width: readyPct + '%' }} /></div>
                <ul className="ready">{ready.map((r) => (
                  <li key={r.k} className={r.ok ? 'done' : ''}><Link to={r.to}>{r.ok ? <CheckCircle2 size={18} /> : <Circle size={18} />}<div><b>{r.k}</b><small>{r.sub}</small></div></Link></li>
                ))}</ul>
              </>
            ) : <p className="muted">Create a trip to see what is left to do before you fly.</p>}
          </section>
          <section className="card"><h3><Luggage size={17} /> Packing progress</h3>
            <div className="ring" style={{ '--p': pct }}><span>{pct}%</span></div>
            <p className="center muted">{packed} of {packing.length} items packed · {packing.length - packed} remaining</p>
          </section>
          <section className="card"><h3>Recently viewed</h3>
            {recent.length ? recent.map((d) => <Link key={d.id} to={`/explore/${d.id}`} className="mini"><img src={d.image} alt="" onError={onImgError(d.id)} /><div><b>{d.name}</b><small>{d.country}</small></div></Link>) : <p className="muted">Nothing viewed yet.</p>}
          </section>
          <section className="card"><h3>Saved destinations</h3>
            {saved.length ? saved.map((d) => <Link key={d.id} to={`/explore/${d.id}`} className="mini"><img src={d.image} alt="" onError={onImgError(d.id)} /><div><b>{d.name}</b><small>{d.country}</small></div></Link>) : <p className="muted">Tap the heart on a destination to save it.</p>}
          </section>
          <section className="card"><h3>Recent activity</h3>
            <ul className="feed">{myActs.map((a) => <li key={a.id}><Activity size={14} /> {a.text}<small>{fmtDate(a.time)}</small></li>)}</ul>
          </section>
        </aside>
      </div>
    </>
  );
}

function Hello({ name, sub }) {
  return <div className="page-head"><div><h2>{greeting()}, {name} 👋</h2><p className="muted">{sub}</p></div></div>;
}
