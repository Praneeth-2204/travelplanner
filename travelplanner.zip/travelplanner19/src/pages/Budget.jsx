import { useState } from 'react';
import { Download, Link2, Pencil, Plus, Wallet } from 'lucide-react';
import { useApp } from '../context/AppContext.jsx';
import { Confirm, DataTable, Empty, Field, IconActions, Modal, PageHead, TripSelect } from '../components/ui.jsx';
import { cap, downloadCsv, fmtDate, fmtMoney, today } from '../utils/helpers.js';

const CATS = ['accommodation', 'transport', 'food', 'activities', 'shopping', 'other'];

export default function Budget() {
  const { data, myTrips, saveItem, removeItem, saveTrip, notify } = useApp();
  const [tripId, setTripId] = useState('all');
  const [cat, setCat] = useState('all');
  const [modal, setModal] = useState(null);
  const [del, setDel] = useState(null);
  const [f, setF] = useState({});
  const [err, setErr] = useState({});
  const [bud, setBud] = useState(null); // trip whose total budget is being changed
  const [budVal, setBudVal] = useState('');

  const trip = (id) => myTrips.find((t) => t.id === id);
  const money = (id, v) => fmtMoney(v, trip(id)?.currency);
  const ids = new Set(myTrips.map((t) => t.id));
  const scoped = data.expenses.filter((e) => ids.has(e.tripId) && (tripId === 'all' || e.tripId === tripId));
  const rows = scoped.filter((e) => cat === 'all' || e.category === cat).sort((a, b) => b.date.localeCompare(a.date));
  const shownTrips = myTrips.filter((t) => tripId === 'all' || t.id === tripId);
  const sum = (list, k) => list.reduce((s, e) => s + Number(e[k] || 0), 0);

  const open = (item) => {
    setErr({});
    setF(item ? { ...item } : { tripId: tripId !== 'all' ? tripId : myTrips[0]?.id || '', category: 'food', description: '', date: today(), estimated: '', actual: 0 });
    setModal(item ? 'edit' : 'new');
  };
  const set = (k, v) => setF((p) => ({ ...p, [k]: v }));
  const submit = () => {
    const x = {};
    if (!f.tripId) x.tripId = 'Choose a trip.';
    if (!f.description.trim()) x.description = 'Describe the expense.';
    if (!f.date) x.date = 'Pick a date.';
    if (f.estimated === '' || !(Number(f.estimated) >= 0)) x.estimated = 'Enter 0 or more.';
    if (f.actual === '' || !(Number(f.actual) >= 0)) x.actual = 'Enter 0 or more.';
    setErr(x);
    if (Object.keys(x).length) return;
    saveItem('expenses', { ...f, description: f.description.trim(), estimated: Number(f.estimated), actual: Number(f.actual) }, `expense "${f.description.trim()}"`);
    notify(modal === 'edit' ? 'Expense updated' : 'Expense added');
    setModal(null);
  };
  const openBudget = (t) => { setBud(t); setBudVal(String(t.budget)); setErr({}); };
  const saveBudget = () => {
    if (!(Number(budVal) > 0)) return setErr({ budget: 'Enter a budget greater than 0.' });
    saveTrip({ ...bud, budget: Number(budVal) });
    notify('Trip budget updated');
    setBud(null);
  };
  const exportCsv = () => {
    downloadCsv('expenses.csv', [['Trip', 'Date', 'Category', 'Description', 'Currency', 'Estimated', 'Actual']]
      .concat(rows.map((r) => [trip(r.tripId)?.title, r.date, r.category, r.description, trip(r.tripId)?.currency, r.estimated, r.actual])));
    notify('Expenses exported');
  };

  const byCat = CATS.map((c) => ({ c, v: sum(scoped.filter((e) => e.category === c), 'actual') })).filter((x) => x.v > 0);
  const singleCurrency = tripId !== 'all' ? trip(tripId)?.currency : null;
  const maxCat = Math.max(1, ...byCat.map((x) => x.v));

  return (
    <>
      <PageHead title="Budget & expenses" sub="Estimated vs actual spend, in each trip's own currency.">
        <TripSelect trips={myTrips} value={tripId} onChange={setTripId} />
        <button className="btn" onClick={exportCsv} disabled={!rows.length}><Download size={16} /> Export CSV</button>
        <button className="btn primary" onClick={() => open()} disabled={!myTrips.length}><Plus size={16} /> Add expense</button>
      </PageHead>

      {shownTrips.length > 0 && (
        <div className="stats">
          {shownTrips.map((t) => {
            const list = data.expenses.filter((e) => e.tripId === t.id);
            const spent = sum(list, 'actual'); const est = sum(list, 'estimated');
            const pct = t.budget ? Math.min(100, Math.round((spent / t.budget) * 100)) : 0;
            const over = spent > t.budget || est > t.budget;
            return (
              <div key={t.id} className="stat" style={{ display: 'block' }}>
                <small style={{ display: 'flex', justifyContent: 'space-between', gap: 8 }}>{t.title}<button className="icon-btn sm" onClick={() => openBudget(t)} aria-label={`Change budget for ${t.title}`} title="Change total budget"><Pencil /></button></small><strong>{fmtMoney(spent, t.currency)}</strong>
                <em>of {fmtMoney(t.budget, t.currency)} · est. {fmtMoney(est, t.currency)}</em>
                <em style={{ display: 'block' }}>Bookings {fmtMoney(sum(list.filter((e) => e.bookingId), 'actual'), t.currency)} · Other {fmtMoney(sum(list.filter((e) => !e.bookingId), 'actual'), t.currency)}</em>
                <div className="bar" style={{ marginTop: 8 }}><i className={over ? 'over' : ''} style={{ width: pct + '%' }} /></div>
                <small className={over ? 'err' : 'muted'}>{over ? `Over budget by ${fmtMoney(Math.max(spent, est) - t.budget, t.currency)}` : `${fmtMoney(t.budget - spent, t.currency)} left`}</small>
              </div>
            );
          })}
        </div>
      )}

      {byCat.length > 0 && (
        <section className="card" style={{ margin: '18px 0' }}>
          <h3>Spending by category</h3>
          {byCat.map(({ c, v }) => (
            <div key={c} className="row-bar"><span>{cap(c)}</span><div className="bar"><i style={{ width: (v / maxCat) * 100 + '%' }} /></div>
              <b>{singleCurrency ? fmtMoney(v, singleCurrency) : v.toLocaleString('en-IN')}</b></div>
          ))}
          {!singleCurrency && <p className="note">Pick a single trip to see amounts with a currency symbol — trips use different currencies.</p>}
        </section>
      )}

      <div className="tabs">
        {['all', ...CATS].map((c) => <button key={c} className={cat === c ? 'on' : ''} onClick={() => setCat(c)}>{cap(c)}</button>)}
      </div>
      <DataTable rows={rows} empty={<Empty icon={Wallet} title="No expenses found" text="Log your first expense to start tracking spend against your budget."><button className="btn primary" onClick={() => open()} disabled={!myTrips.length}><Plus size={16} /> Add expense</button></Empty>}
        cols={[
          { h: 'Date', r: (r) => fmtDate(r.date) }, { h: 'Expense', r: (r) => <span><b>{r.description}</b>{r.bookingId && <><br /><small className="muted" style={{ display: 'inline-flex', gap: 4, alignItems: 'center' }}><Link2 size={12} /> From booking</small></>}</span> },
          { h: 'Category', r: (r) => <span className="tag">{cap(r.category)}</span> }, { h: 'Trip', r: (r) => trip(r.tripId)?.title },
          { h: 'Estimated', r: (r) => money(r.tripId, r.estimated) },
          { h: 'Actual', r: (r) => <span className={r.actual > r.estimated ? 'bad' : ''}>{money(r.tripId, r.actual)}</span> },
          { h: '', r: (r) => <IconActions label={r.description} onEdit={() => open(r)} onDelete={() => setDel(r)} /> },
        ]} />

      {modal && (
        <Modal title={modal === 'edit' ? 'Edit expense' : 'Add expense'} onClose={() => setModal(null)} onSubmit={submit} submitLabel={modal === 'edit' ? 'Save changes' : 'Add expense'}>
          {f.bookingId && <p className="note" style={{ marginBottom: 12 }}>This expense came from a booking. You can correct the amount here; if you edit the booking later, the booking cost will replace it.</p>}
          <Field label="Trip *" error={err.tripId}><select value={f.tripId} disabled={!!f.bookingId} onChange={(e) => set('tripId', e.target.value)}>{myTrips.map((t) => <option key={t.id} value={t.id}>{t.title}</option>)}</select></Field>
          <Field label="Description *" error={err.description}><input value={f.description} onChange={(e) => set('description', e.target.value)} placeholder="e.g. Airport taxi" /></Field>
          <div className="row2">
            <Field label="Category"><select value={f.category} onChange={(e) => set('category', e.target.value)}>{CATS.map((c) => <option key={c} value={c}>{cap(c)}</option>)}</select></Field>
            <Field label="Date *" error={err.date}><input type="date" value={f.date} onChange={(e) => set('date', e.target.value)} /></Field>
          </div>
          <div className="row2">
            <Field label={`Estimated (${trip(f.tripId)?.currency || ''}) *`} error={err.estimated}><input type="number" min="0" value={f.estimated} onChange={(e) => set('estimated', e.target.value)} /></Field>
            <Field label={`Actual (${trip(f.tripId)?.currency || ''})`} error={err.actual}><input type="number" min="0" value={f.actual} onChange={(e) => set('actual', e.target.value)} /></Field>
          </div>
        </Modal>
      )}
      {bud && (
        <Modal title="Change trip budget" onClose={() => setBud(null)} onSubmit={saveBudget} submitLabel="Save budget">
          <p className="muted" style={{ marginBottom: 12 }}>{bud.title} · spent so far {fmtMoney(sum(data.expenses.filter((e) => e.tripId === bud.id), 'actual'), bud.currency)}</p>
          <Field label={`Total budget (${bud.currency}) *`} error={err.budget}><input type="number" min="0" value={budVal} onChange={(e) => setBudVal(e.target.value)} autoFocus /></Field>
        </Modal>
      )}
      {del && <Confirm title="Delete expense?" text={del.bookingId ? `"${del.description}" will be removed from your budget. The booking itself stays in Bookings.` : `"${del.description}" will be removed from your budget.`} onClose={() => setDel(null)} onConfirm={() => { removeItem('expenses', del.id, `expense "${del.description}"`); notify('Expense deleted'); }} />}
    </>
  );
}
