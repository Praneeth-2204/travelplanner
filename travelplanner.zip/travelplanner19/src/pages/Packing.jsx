import { useState } from 'react';
import { CheckCheck, Luggage, Plus, RotateCcw, Sparkles } from 'lucide-react';
import { useApp } from '../context/AppContext.jsx';
import { Confirm, Empty, Field, IconActions, Modal, PageHead, TripSelect } from '../components/ui.jsx';

const CATS = ['Documents', 'Clothing', 'Toiletries', 'Electronics', 'Accessories', 'Medicines', 'Other'];
const ESSENTIALS = [
  { name: 'Passport / ID', category: 'Documents', qty: 1, priority: 'high' }, { name: 'Tickets & bookings', category: 'Documents', qty: 1, priority: 'high' },
  { name: 'Phone charger', category: 'Electronics', qty: 1, priority: 'high' }, { name: 'Power bank', category: 'Electronics', qty: 1, priority: 'medium' },
  { name: 'Travel adapter', category: 'Electronics', qty: 1, priority: 'medium' }, { name: 'Toothbrush & paste', category: 'Toiletries', qty: 1, priority: 'high' },
  { name: 'Prescription medicines', category: 'Medicines', qty: 1, priority: 'high' }, { name: 'First-aid kit', category: 'Medicines', qty: 1, priority: 'medium' },
  { name: 'Comfortable shoes', category: 'Clothing', qty: 1, priority: 'medium' }, { name: 'Reusable water bottle', category: 'Accessories', qty: 1, priority: 'low' },
];

export default function Packing() {
  const { data, myTrips, togglePacked, saveItem, removeItem, setAllPacked, addPackingBatch, notify } = useApp();
  const live = myTrips.filter((t) => !['cancelled', 'archived'].includes(t.statusOverride));
  const [tripId, setTripId] = useState('all');
  const [modal, setModal] = useState(false);
  const [del, setDel] = useState(null);
  const [f, setF] = useState({});
  const [err, setErr] = useState({});

  const trip = (id) => myTrips.find((t) => t.id === id);
  const ids = new Set(myTrips.map((t) => t.id));
  const rows = data.packing.filter((p) => ids.has(p.tripId) && (tripId === 'all' || p.tripId === tripId));
  const packed = rows.filter((p) => p.packed).length;
  const pct = rows.length ? Math.round((packed / rows.length) * 100) : 0;
  const groups = CATS.concat([...new Set(rows.map((r) => r.category))].filter((c) => !CATS.includes(c))).map((c) => [c, rows.filter((r) => r.category === c)]).filter(([, l]) => l.length);
  const target = tripId !== 'all' ? tripId : null;

  const open = (item) => { setErr({}); setF(item ? { ...item } : { tripId: target || live[0]?.id || '', name: '', category: 'Clothing', qty: 1, priority: 'medium', packed: false }); setModal(item ? 'edit' : 'new'); };
  const set = (k, v) => setF((p) => ({ ...p, [k]: v }));
  const submit = () => {
    const x = {};
    if (!f.tripId) x.tripId = 'Choose a trip.';
    if (!f.name.trim()) x.name = 'Enter an item name.';
    if (!Number.isInteger(Number(f.qty)) || Number(f.qty) < 1 || Number(f.qty) > 99) x.qty = 'Enter 1–99.';
    setErr(x);
    if (Object.keys(x).length) return;
    saveItem('packing', { ...f, name: f.name.trim(), qty: Number(f.qty) }, `packing item "${f.name.trim()}"`);
    notify(modal === 'edit' ? 'Item updated' : 'Item added');
    setModal(false);
  };

  return (
    <>
      <PageHead title="Packing lists" sub={`${packed} of ${rows.length} items packed.`}>
        <TripSelect trips={myTrips} value={tripId} onChange={setTripId} />
        <button className="btn primary" onClick={() => open()} disabled={!live.length}><Plus size={16} /> Add item</button>
      </PageHead>

      {rows.length > 0 && (
        <section className="card" style={{ marginBottom: 18 }}>
          <div className="bar-label"><b>{pct}% packed</b><span>{rows.length - packed} left to pack</span></div>
          <div className="bar"><i style={{ width: pct + '%' }} /></div>
        </section>
      )}
      {target && (
        <div className="actions" style={{ marginTop: 0, marginBottom: 16 }}>
          <button className="btn sm" onClick={() => { addPackingBatch(target, ESSENTIALS); notify('Essentials added'); }}><Sparkles size={14} /> Add travel essentials</button>
          <button className="btn sm" onClick={() => setAllPacked(target, true)} disabled={!rows.length}><CheckCheck size={14} /> Mark all packed</button>
          <button className="btn sm" onClick={() => setAllPacked(target, false)} disabled={!rows.length}><RotateCcw size={14} /> Uncheck all</button>
        </div>
      )}

      {groups.length ? (
        <div className="grid">
          {groups.map(([c, list]) => (
            <section key={c} className="card">
              <h3>{c} <span className="muted" style={{ fontWeight: 500 }}>· {list.filter((i) => i.packed).length}/{list.length}</span></h3>
              <ul className="checklist">
                {list.map((p) => (
                  <li key={p.id} className={p.packed ? 'done' : ''}>
                    <input type="checkbox" checked={p.packed} onChange={() => togglePacked(p.id)} aria-label={`Packed ${p.name}`} />
                    <div><b>{p.name}</b><small>{p.qty > 1 ? `× ${p.qty} · ` : ''}{tripId === 'all' ? `${trip(p.tripId)?.title} · ` : ''}<span className={`prio ${p.priority}`}>{p.priority}</span></small></div>
                    <IconActions label={p.name} onEdit={() => open(p)} onDelete={() => setDel(p)} />
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
      ) : (
        <Empty icon={Luggage} title="Nothing to pack yet" text={target ? 'Add items one by one, or start from a ready-made list of travel essentials.' : 'Pick a trip to add the travel essentials, or add your own items.'}>
          {target && <button className="btn primary" onClick={() => { addPackingBatch(target, ESSENTIALS); notify('Essentials added'); }}><Sparkles size={16} /> Add travel essentials</button>}
        </Empty>
      )}

      {modal && (
        <Modal title={modal === 'edit' ? 'Edit item' : 'Add packing item'} onClose={() => setModal(false)} onSubmit={submit} submitLabel={modal === 'edit' ? 'Save changes' : 'Add item'}>
          <Field label="Trip *" error={err.tripId}><select value={f.tripId} onChange={(e) => set('tripId', e.target.value)}>{(modal === 'edit' ? myTrips : live).map((t) => <option key={t.id} value={t.id}>{t.title}</option>)}</select></Field>
          <Field label="Item *" error={err.name}><input value={f.name} onChange={(e) => set('name', e.target.value)} placeholder="e.g. Rain jacket" /></Field>
          <div className="row3">
            <Field label="Category"><select value={f.category} onChange={(e) => set('category', e.target.value)}>{CATS.map((c) => <option key={c}>{c}</option>)}</select></Field>
            <Field label="Quantity" error={err.qty}><input type="number" min="1" max="99" value={f.qty} onChange={(e) => set('qty', e.target.value)} /></Field>
            <Field label="Priority"><select value={f.priority} onChange={(e) => set('priority', e.target.value)}><option value="high">High</option><option value="medium">Medium</option><option value="low">Low</option></select></Field>
          </div>
        </Modal>
      )}
      {del && <Confirm title="Remove item?" text={`"${del.name}" will be removed from the packing list.`} confirmLabel="Remove" onClose={() => setDel(null)} onConfirm={() => { removeItem('packing', del.id, `packing item "${del.name}"`); notify('Item removed'); }} />}
    </>
  );
}
