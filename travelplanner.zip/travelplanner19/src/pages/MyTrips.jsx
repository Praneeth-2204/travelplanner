import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Archive, Ban, Calendar, Eye, Pencil, Plus, RotateCcw, Search, Trash2, Users, Wallet, Briefcase } from 'lucide-react';
import { useApp } from '../context/AppContext.jsx';
import TripFormModal from '../components/TripFormModal.jsx';
import { Confirm } from '../components/ui.jsx';
import { photo } from '../assets/scenes.js';
import { useUrlQuery } from '../utils/useUrlQuery.js';
import { fmtDate, fmtMoney, tripStatus } from '../utils/helpers.js';

const TABS = ['all', 'planning', 'upcoming', 'ongoing', 'completed', 'cancelled', 'archived'];

export default function MyTrips() {
  const { data, myTrips, saveTrip, setTripOverride, deleteTrip, notify } = useApp();
  const [params, setParams] = useSearchParams();
  const go = useNavigate();
  const [tab, setTab] = useState('all');
  const [q, setQ] = useUrlQuery();
  const [modal, setModal] = useState(null); // {trip?, preset?}
  const [cancelId, setCancelId] = useState(null);
  const [delTrip, setDelTrip] = useState(null);

  useEffect(() => {
    const preset = params.get('new');
    if (preset) { setModal({ preset: data.destinations.some((d) => d.id === preset) ? preset : undefined }); setParams({}, { replace: true }); }
  }, []); // eslint-disable-line

  const withStatus = useMemo(() => myTrips.map((t) => ({ ...t, status: tripStatus(t) })), [myTrips]);
  const counts = TABS.reduce((a, s) => ({ ...a, [s]: s === 'all' ? withStatus.filter((t) => t.status !== 'archived').length : withStatus.filter((t) => t.status === s).length }), {});
  const shown = withStatus
    .filter((t) => (tab === 'all' ? t.status !== 'archived' : t.status === tab))
    .filter((t) => !q.trim() || t.title.toLowerCase().includes(q.toLowerCase()))
    .sort((a, b) => a.departureDate.localeCompare(b.departureDate));

  const spent = (id) => data.expenses.filter((e) => e.tripId === id).reduce((s, e) => s + e.actual, 0);
  const destNames = (t) => t.destinationIds.map((i) => data.destinations.find((d) => d.id === i)?.name).filter(Boolean);

  return (
    <>
      <div className="page-head">
        <div><h2>My trips</h2><p className="muted">Create, edit and organise every journey.</p></div>
        <div className="actions" style={{ margin: 0 }}><button className="btn primary" onClick={() => setModal({})}><Plus size={16} /> New trip</button></div>
      </div>
      <div className="filters">
        <div className="search-box"><Search size={16} /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search your trips" /></div>
      </div>
      <div className="tabs">
        {TABS.map((s) => <button key={s} className={tab === s ? 'on' : ''} onClick={() => setTab(s)}>{s[0].toUpperCase() + s.slice(1)} <span>{counts[s]}</span></button>)}
      </div>

      {shown.length ? (
        <div className="grid">
          {shown.map((t) => {
            const pct = t.budget ? Math.min(100, Math.round((spent(t.id) / t.budget) * 100)) : 0;
            const over = spent(t.id) > t.budget;
            const inactive = t.status === 'cancelled' || t.status === 'archived';
            return (
              <article key={t.id} className={`tcard click ${inactive ? 'dim' : ''}`} tabIndex={0} role="link" aria-label={`Open ${t.title}`}
                onClick={() => go(`/trips/${t.id}`)} onKeyDown={(e) => e.key === 'Enter' && e.target === e.currentTarget && go(`/trips/${t.id}`)}>
                <div className="tcard-img" style={{ backgroundImage: photo(t.image, t.id) }}><span className={`status ${t.status}`}>{t.status}</span></div>
                <div className="tcard-body">
                  <h3>{t.title}</h3>
                  <p className="loc">{destNames(t).join(' · ')}</p>
                  <ul className="meta">
                    <li><Calendar size={14} /> {fmtDate(t.departureDate, { day: 'numeric', month: 'short' })} – {fmtDate(t.returnDate)}</li>
                    <li><Users size={14} /> {t.travellers} · {t.type}</li>
                    <li><Wallet size={14} /> {fmtMoney(t.budget, t.currency)}</li>
                  </ul>
                  <div className="bar-label"><span>Spent {fmtMoney(spent(t.id), t.currency)}</span><span className={over ? 'bad' : ''}>{pct}%</span></div>
                  <div className="bar"><i className={over ? 'over' : ''} style={{ width: pct + '%' }} /></div>
                  {over && <small className="err">Over budget</small>}
                  <div className="actions" onClick={(e) => e.stopPropagation()}>
                    <button className="btn sm" onClick={() => go(`/trips/${t.id}`)}><Eye size={14} /> View</button>
                    <button className="btn sm" onClick={() => setModal({ trip: t })} disabled={t.status === 'archived'}><Pencil size={14} /> Edit</button>
                    {t.status === 'archived' || t.status === 'cancelled' ? (
                      <>
                        <button className="btn sm" onClick={() => { setTripOverride(t.id, null); notify('Trip restored'); }}><RotateCcw size={14} /> Restore</button>
                        <button className="btn sm danger" onClick={() => setDelTrip(t)}><Trash2 size={14} /> Delete</button>
                      </>
                    ) : (
                      <>
                        {t.status !== 'completed' && <button className="btn sm" onClick={() => setCancelId(t)}><Ban size={14} /> Cancel</button>}
                        <button className="btn sm" onClick={() => { setTripOverride(t.id, 'archived'); notify('Trip archived'); }}><Archive size={14} /> Archive</button>
                      </>
                    )}
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      ) : (
        <div className="empty"><div className="empty-icon"><Briefcase size={28} /></div><h2>No trips here yet</h2><p>Start a new trip and it will show up in this list.</p><button className="btn primary" onClick={() => setModal({})}><Plus size={16} /> Create a trip</button></div>
      )}

      {modal && (
        <TripFormModal trip={modal.trip} presetDestination={modal.preset} onClose={() => setModal(null)}
          onSave={(t) => { saveTrip(t); setModal(null); notify(modal.trip ? 'Trip updated' : 'Trip created'); }} />
      )}
      {cancelId && <Confirm title="Cancel this trip?" text={`"${cancelId.title}" will be marked as cancelled. You can restore it later.`} confirmLabel="Cancel trip" onClose={() => setCancelId(null)} onConfirm={() => { setTripOverride(cancelId.id, 'cancelled'); notify('Trip cancelled'); }} />}
      {delTrip && <Confirm title="Delete trip permanently?" text={`"${delTrip.title}" and its itinerary, bookings, expenses and packing list will be removed for good.`} onClose={() => setDelTrip(null)} onConfirm={() => { deleteTrip(delTrip.id); notify('Trip deleted'); }} />}
    </>
  );
}
