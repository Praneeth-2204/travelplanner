import { useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, SearchX, X } from 'lucide-react';
import { useApp } from '../context/AppContext.jsx';
import DestinationCard from '../components/DestinationCard.jsx';
import { useUrlQuery } from '../utils/useUrlQuery.js';

const TIERS = {
  any: { label: 'Any cost', test: () => true },
  budget: { label: 'Low cost (under $60/day)', test: (c) => c < 60 },
  mid: { label: 'Mid-range ($60–$150/day)', test: (c) => c >= 60 && c <= 150 },
  premium: { label: 'Premium ($150+/day)', test: (c) => c > 150 },
};

export default function Explore() {
  const { data, user } = useApp();
  const [, setParams] = useSearchParams();
  const [q, setQ] = useUrlQuery();
  const [cat, setCat] = useState('all');
  const [tier, setTier] = useState('any');
  const [sort, setSort] = useState('popular');
  const [savedOnly, setSavedOnly] = useState(false);

  const list = useMemo(() => {
    const s = q.trim().toLowerCase();
    return data.destinations
      .filter((d) => d.status === 'active')
      .filter((d) => !s || [d.name, d.city, d.country, d.region].some((x) => x.toLowerCase().includes(s)))
      .filter((d) => cat === 'all' || d.categoryId === cat)
      .filter((d) => !savedOnly || user.saved.includes(d.id))
      .filter((d) => TIERS[tier].test(d.costUSD))
      .sort((a, b) => (sort === 'popular' ? b.popularity - a.popularity : sort === 'cost' ? a.costUSD - b.costUSD : a.name.localeCompare(b.name)));
  }, [data.destinations, q, cat, tier, sort, savedOnly, user.saved]);

  const reset = () => { setQ(''); setCat('all'); setTier('any'); setSavedOnly(false); setParams({}); };
  const filtered = q || cat !== 'all' || tier !== 'any' || savedOnly;

  return (
    <>
      <div className="page-head">
        <div><h2>Where to next?</h2><p className="muted">Browse curated destinations and start planning in a click.</p></div>
      </div>
      <div className="filters">
        <div className="search-box"><Search size={16} />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by city, country or region" />
          {q && <button onClick={() => setQ('')} aria-label="Clear"><X size={14} /></button>}
        </div>
        <select value={tier} onChange={(e) => setTier(e.target.value)} aria-label="Estimated cost">
          {Object.entries(TIERS).map(([k, t]) => <option key={k} value={k}>{t.label}</option>)}
        </select>
        <select value={sort} onChange={(e) => setSort(e.target.value)} aria-label="Sort">
          <option value="popular">Most popular</option><option value="cost">Lowest cost</option><option value="name">A – Z</option>
        </select>
      </div>
      <div className="chips">
        <button className={`fchip ${cat === 'all' ? 'on' : ''}`} onClick={() => setCat('all')}>All</button>
        <button className={`fchip ${savedOnly ? 'on' : ''}`} onClick={() => setSavedOnly(!savedOnly)}>♥ Saved ({user.saved.length})</button>
        {data.categories.map((c) => (
          <button key={c.id} className={`fchip ${cat === c.id ? 'on' : ''}`} onClick={() => setCat(c.id)}>{c.name}</button>
        ))}
      </div>
      <p className="count">{list.length} destination{list.length !== 1 && 's'} {filtered && <button className="link" onClick={reset}>Clear filters</button>}</p>
      {list.length ? (
        <div className="grid">{list.map((d) => <DestinationCard key={d.id} d={d} />)}</div>
      ) : (
        <div className="empty"><div className="empty-icon"><SearchX size={28} /></div><h2>No destinations found</h2><p>{savedOnly ? 'You have not saved any matching destinations yet.' : 'Try a different keyword or loosen your filters.'}</p><button className="btn" onClick={reset}>Reset filters</button></div>
      )}
    </>
  );
}
